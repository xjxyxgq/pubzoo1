# CMDB Backend V2

基于go-zero框架的配置管理数据库(CMDB)后端服务，采用RPC + API的标准架构模式。

## 项目结构

```
cmdb_backend_v2/
├── rpc/                    # RPC服务（业务逻辑层）
│   ├── proto/             # Protobuf定义文件
│   ├── internal/          # 内部实现
│   │   ├── config/        # 配置管理
│   │   ├── logic/         # 业务逻辑
│   │   ├── server/        # gRPC服务器实现
│   │   ├── svc/          # 服务上下文
│   │   ├── model/        # 数据模型（goctl生成）
│   │   └── datasource/   # 数据源管理
│   ├── etc/              # 配置文件
│   ├── go.mod            # Go模块文件
│   └── cmpool.go         # RPC服务入口
├── api/                   # API服务（HTTP接口层）- go-zero生成
│   ├── cmdb.go           # API服务入口（go-zero生成）
│   ├── cmdb.api          # API定义文件
│   ├── go.mod            # Go模块文件
│   ├── etc/              # 配置文件
│   └── internal/         # 内部实现（go-zero生成）
│       ├── config/       # 配置管理
│       ├── handler/      # HTTP处理器
│       ├── logic/        # 业务逻辑
│       ├── svc/         # 服务上下文
│       └── types/       # 类型定义
├── docs/                 # 文档
├── schema.sql           # 数据库初始化脚本
├── init_database.sh     # 数据库初始化脚本
├── start.sh             # 启动脚本
└── README.md            # 项目说明
```

## 服务架构

### RPC服务 (端口 8080)
- **职责**: 实现核心业务逻辑，数据处理，外部数据源集成
- **功能**:
  - 数据源同步（CSV文件加载、外部API调用）
  - 数据库操作（MySQL）
  - 业务逻辑处理
  - 缓存管理

### API服务 (端口 8888) - **使用go-zero生成**
- **职责**: 提供HTTP接口，作为RPC服务的代理
- **功能**:
  - HTTP路由处理
  - 请求参数验证
  - 调用RPC服务
  - 响应格式化
  - 自动生成的类型安全代码

## 核心功能

### 1. 数据源管理
- **CSV文件加载**: 支持服务器监控指标数据加载
- **外部API集成**: 模拟外部接口获取主机池数据
- **数据同步**: hosts_pool → host_application → cluster_group 的数据同步流程

### 2. 主要接口

#### 主机池管理
- `GET /api/cmdb/v1/get_hosts_pool_detail` - 获取主机池详情
- `GET /api/cmdb/v1/get_host_detail/:id` - 获取指定主机详情
- `POST /api/cmdb/v1/collect_applications` - 收集应用程序信息

#### 集群资源监控
- `GET /api/cmdb/v1/get_cluster_usage` - 获取集群使用情况
- `GET /api/cmdb/v1/cluster-resource-usage` - 获取集群资源使用情况
- `GET /api/cmdb/v1/cluster-resource-summary` - 获取集群资源摘要

#### 资源监控与告警
- `GET /api/cmdb/v1/resource-alerts` - 获取资源告警
- `GET /api/cmdb/v1/disk-full-prediction` - 磁盘满预测
- `GET /api/cmdb/v1/server-resources` - 获取服务器资源数据
- `POST /api/cmdb/v1/insert-server-resource` - 插入服务器资源数据

#### 集群组管理
- `GET /api/cmdb/v1/cluster-groups` - 获取集群组信息

#### 报告与邮件
- `GET /api/cmdb/v1/cluster-group-report` - 生成集群组报告
- `GET /api/cmdb/v1/idc-report` - 生成IDC报告
- `POST /api/cmdb/v1/generate-and-send-report` - 生成并发送报告
- `POST /api/cmdb/v1/trigger-report` - 触发报告
- `POST /api/cmdb/v1/send-email` - 发送邮件

#### 资源分析
- `POST /api/cmdb/v1/analyze_resource_usage` - 分析资源使用情况

#### 备份恢复检查
- `GET /api/cmdb/v1/backup-restore-check-info` - 获取备份恢复检查信息
- `GET /api/cmdb/v1/cluster-confirm-summary` - 获取集群确认摘要

## 数据库设计

### 核心表结构
- **hosts_pool**: 主机资源池
- **hosts_applications**: 主机应用部署信息
- **mysql_cluster_instance/mssql_cluster_instance**: 数据库实例表
- **mysql_cluster/mssql_cluster**: 集群配置表
- **db_line**: 业务线关系表
- **server_resources**: 监控指标数据
- **cluster_groups**: 集群组表
- **cluster_resource_summary**: 集群资源摘要表
- **backup_restore_check_info**: 备份恢复检查信息表
- **plugin_execution_records**: 插件执行记录表
- **resource_usage_data**: 资源使用数据表
- **resource_analysis_reports**: 资源分析报告表

### 数据库模型生成
项目使用goctl工具自动生成数据库访问模型：

```bash
# 为所有表生成模型（已完成）
goctl model mysql ddl -src="./schema.sql" -dir="./rpc/internal/model" -cache=true
```

所有生成的模型都包含：
- 标准CRUD操作
- Redis缓存支持
- 类型安全的Go结构体
- 自动生成的SQL查询

## 快速开始

### 1. 数据库初始化

首先初始化数据库：

```bash
# 修改数据库连接配置
vim init_database.sh

# 执行数据库初始化
./init_database.sh
```

或者手动执行：

```bash
# 创建数据库
mysql -u root -p -e "CREATE DATABASE cmdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 导入表结构
mysql -u root -p cmdb < schema.sql
```

### 2. 使用启动脚本（推荐）
```bash
./start.sh
```

### 3. 手动启动服务

#### 启动RPC服务
```bash
cd rpc
go run cmpool.go -f etc/cmpool.yaml
```

#### 启动API服务
```bash
cd api
go run cmdb.go -f etc/cmdb-api.yaml
```

### 4. 测试接口
```bash
# 获取主机池详情
curl http://localhost:8888/api/cmdb/v1/get_hosts_pool_detail

# 获取集群组信息
curl http://localhost:8888/api/cmdb/v1/cluster-groups

# 获取服务器资源
curl http://localhost:8888/api/cmdb/v1/server-resources
```

## 配置说明

### RPC服务配置 (rpc/etc/cmpool.yaml)
```yaml
Name: cmpool
ListenOn: 0.0.0.0:8080
DataSource: root:password@tcp(localhost:3306)/cmdb?charset=utf8mb4&parseTime=True&loc=Local
Cache:
  - Host: localhost:6379
```

### API服务配置 (api/etc/cmdb-api.yaml)
```yaml
Name: cmdb-api
Host: 0.0.0.0
Port: 8888
RpcConfig:
  Endpoints:
    - 127.0.0.1:8080
DataSource: root:password@tcp(localhost:3306)/cmdb?charset=utf8mb4&parseTime=True&loc=Local
```

## 开发说明

### API服务代码生成
项目使用go-zero的API代码生成功能：

1. 编辑 `api/cmdb.api` 文件定义接口
2. 运行代码生成命令：
   ```bash
   cd api
   goctl api go --api cmdb.api --dir .
   ```
3. 在 `internal/logic/` 中实现具体的业务逻辑

### 数据库模型管理
当需要修改数据库结构时：

1. 更新 `schema.sql` 文件
2. 重新生成模型：
   ```bash
   goctl model mysql ddl -src="./schema.sql" -dir="./rpc/internal/model" -cache=true
   ```
3. 更新服务上下文中的模型初始化代码

### 添加新接口
1. 在 `api/cmdb.api` 中定义新的HTTP接口
2. 重新生成API代码：`goctl api go --api cmdb.api --dir .`
3. 在对应的logic文件中实现业务逻辑
4. （可选）在RPC服务中添加对应的方法

### 数据源扩展
- 在 `rpc/internal/datasource/` 目录下添加新的数据源实现
- 在 `rpc/internal/logic/` 中调用数据源服务
- 更新配置文件和服务上下文

## 依赖项
- Go 1.21+
- MySQL 5.7+
- Redis (可选，用于缓存)
- github.com/zeromicro/go-zero
- google.golang.org/grpc

## 技术特性
- **类型安全**: 使用go-zero生成的类型安全代码
- **自动路由**: 基于API定义自动生成路由和处理器
- **标准架构**: 遵循go-zero的标准项目结构
- **中间件支持**: 内置日志、监控、限流等中间件
- **配置管理**: 支持YAML配置文件
- **数据库模型**: 自动生成的CRUD操作和缓存支持

## 注意事项
1. 确保MySQL数据库已创建并配置正确
2. RPC服务必须先于API服务启动
3. 生产环境请修改默认密码和配置
4. 建议使用Docker进行部署
5. 修改API接口时，需要重新生成代码
6. 修改数据库结构时，需要重新生成模型

## 最新功能特性

### 数据查询优化
- **默认时间范围统一**: 所有数据查询页面默认使用3个月时间范围
- **智能回退机制**: 时间解析失败时自动使用3个月默认值
- **前后端一致性**: 前端和后端时间范围逻辑完全统一

### 前端架构优化  
- **模块化管理页面**: `AdminManagement.js` 重构为导航布局 + 独立子组件
- **子页面组件化**: 
  - `adminManagmentSubPage/ClusterGroupSync.js` - 集群组数据同步
  - `adminManagmentSubPage/ServerMetricsLoader.js` - 监控指标数据加载  
  - `adminManagmentSubPage/MonitoringVerification.js` - 监控数据核对
- **表格功能增强**: 支持文本搜索、筛选、排序、高亮显示

### 接口功能完善
- **监控数据核对**: `POST /api/cmdb/v1/verify-monitoring-data` - 核对主机监控数据覆盖率
- **集群组同步**: `POST /api/cmdb/v1/sync-cluster-groups` - 多数据库集群数据同步
- **CSV数据加载**: `POST /api/cmdb/v1/load-server-metrics-csv` - 带进度的CSV文件处理

## 后续开发计划
1. ✅ 完善数据库模型生成和管理
2. ✅ 统一数据查询时间范围默认值 
3. ✅ 优化前端组件架构和模块化
4. ✅ 增强表格筛选和搜索功能
5. 添加认证和授权机制
6. 完善错误处理和日志记录
7. 添加API文档和测试用例
8. 优化性能和缓存策略
9. 集成链路追踪和监控 