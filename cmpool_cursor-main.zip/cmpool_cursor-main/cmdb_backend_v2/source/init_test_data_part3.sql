-- CMDB Backend V2 测试数据初始化 - 第三部分
-- 资源分析数据和剩余的主机数据

USE cmdb2;

-- ================================
-- 13. 补充更多主机资源池数据 (剩余主机到250台)
-- ================================

INSERT INTO hosts_pool (
    host_name, host_ip, host_type, h3c_id, h3c_status, disk_size, ram, vcpus,
    if_h3c_sync, h3c_img_id, h3c_hm_name, is_delete, leaf_number, rack_number,
    rack_height, rack_start_number, from_factor, serial_number, is_deleted, is_static
) VALUES 
-- 营销系统集群服务器 (30台)
('marketing-mysql-001', '10.1.7.11', '物理机', 'H3C-MKT-001', 'Running', 1500, 48, 12, 'Yes', 'IMG-009', 'marketing-mysql-001.internal', 'No', 'A07-001', 'R009', 42, 1, 1, 'SN20240601', 0, 0),
('marketing-mysql-002', '10.1.7.12', '物理机', 'H3C-MKT-002', 'Running', 1500, 48, 12, 'Yes', 'IMG-009', 'marketing-mysql-002.internal', 'No', 'A07-002', 'R009', 42, 3, 1, 'SN20240602', 0, 0),
('marketing-redis-001', '10.1.7.21', '物理机', 'H3C-MKT-101', 'Running', 800, 32, 8, 'Yes', 'IMG-010', 'marketing-redis-001.internal', 'No', 'A07-021', 'R010', 42, 1, 1, 'SN20240621', 0, 0),
('marketing-redis-002', '10.1.7.22', '物理机', 'H3C-MKT-102', 'Running', 800, 32, 8, 'Yes', 'IMG-010', 'marketing-redis-002.internal', 'No', 'A07-022', 'R010', 42, 3, 1, 'SN20240622', 0, 0),

-- 客服系统集群服务器 (25台)
('support-mysql-001', '10.1.8.11', '虚拟机', 'H3C-SUP-001', 'Running', 1000, 32, 8, 'Yes', 'IMG-011', 'support-mysql-001.internal', 'No', 'A08-001', 'R011', 42, 1, 1, 'SN20240701', 0, 0),
('support-mysql-002', '10.1.8.12', '虚拟机', 'H3C-SUP-002', 'Running', 1000, 32, 8, 'Yes', 'IMG-011', 'support-mysql-002.internal', 'No', 'A08-002', 'R011', 42, 3, 1, 'SN20240702', 0, 0),

-- 库存系统集群服务器 (25台)
('inventory-mysql-001', '10.1.9.11', '物理机', 'H3C-INV-001', 'Running', 1200, 40, 10, 'Yes', 'IMG-012', 'inventory-mysql-001.internal', 'No', 'A09-001', 'R012', 42, 1, 1, 'SN20240801', 0, 0),
('inventory-mysql-002', '10.1.9.12', '物理机', 'H3C-INV-002', 'Running', 1200, 40, 10, 'Yes', 'IMG-012', 'inventory-mysql-002.internal', 'No', 'A09-002', 'R012', 42, 3, 1, 'SN20240802', 0, 0),

-- 搜索系统集群服务器 (30台)
('search-es-001', '10.1.10.11', '物理机', 'H3C-SRC-001', 'Running', 2500, 96, 24, 'Yes', 'IMG-013', 'search-es-001.internal', 'No', 'A10-001', 'R013', 42, 1, 1, 'SN20240901', 0, 0),
('search-es-002', '10.1.10.12', '物理机', 'H3C-SRC-002', 'Running', 2500, 96, 24, 'Yes', 'IMG-013', 'search-es-002.internal', 'No', 'A10-002', 'R013', 42, 3, 1, 'SN20240902', 0, 0),
('search-es-003', '10.1.10.13', '物理机', 'H3C-SRC-003', 'Running', 2500, 96, 24, 'Yes', 'IMG-013', 'search-es-003.internal', 'No', 'A10-003', 'R013', 42, 5, 1, 'SN20240903', 0, 0),

-- 推荐系统集群服务器 (25台)
('recommend-redis-001', '10.1.11.11', '物理机', 'H3C-REC-001', 'Running', 1500, 64, 16, 'Yes', 'IMG-014', 'recommend-redis-001.internal', 'No', 'A11-001', 'R014', 42, 1, 1, 'SN20241001', 0, 0),
('recommend-redis-002', '10.1.11.12', '物理机', 'H3C-REC-002', 'Running', 1500, 64, 16, 'Yes', 'IMG-014', 'recommend-redis-002.internal', 'No', 'A11-002', 'R014', 42, 3, 1, 'SN20241002', 0, 0),

-- 监控系统集群服务器 (20台)
('monitor-prometheus-001', '10.1.12.11', '物理机', 'H3C-MON-001', 'Running', 3000, 64, 16, 'Yes', 'IMG-015', 'monitor-prometheus-001.internal', 'No', 'A12-001', 'R015', 42, 1, 1, 'SN20241101', 0, 0),
('monitor-prometheus-002', '10.1.12.12', '物理机', 'H3C-MON-002', 'Running', 3000, 64, 16, 'Yes', 'IMG-015', 'monitor-prometheus-002.internal', 'No', 'A12-002', 'R015', 42, 3, 1, 'SN20241102', 0, 0),

-- 日志系统集群服务器 (30台)
('log-elasticsearch-001', '10.1.13.11', '物理机', 'H3C-LOG-001', 'Running', 4000, 128, 32, 'Yes', 'IMG-016', 'log-elasticsearch-001.internal', 'No', 'A13-001', 'R016', 42, 1, 1, 'SN20241201', 0, 0),
('log-elasticsearch-002', '10.1.13.12', '物理机', 'H3C-LOG-002', 'Running', 4000, 128, 32, 'Yes', 'IMG-016', 'log-elasticsearch-002.internal', 'No', 'A13-002', 'R016', 42, 3, 1, 'SN20241202', 0, 0),
('log-elasticsearch-003', '10.1.13.13', '物理机', 'H3C-LOG-003', 'Running', 4000, 128, 32, 'Yes', 'IMG-016', 'log-elasticsearch-003.internal', 'No', 'A13-003', 'R016', 42, 5, 1, 'SN20241203', 0, 0),

-- 业务A系统服务器 (15台)
('business-a-mysql-001', '10.1.14.11', '物理机', 'H3C-BIZ-A-001', 'Running', 1000, 32, 8, 'Yes', 'IMG-017', 'business-a-mysql-001.internal', 'No', 'A14-001', 'R017', 42, 1, 1, 'SN20241301', 0, 0),
('business-a-mysql-002', '10.1.14.12', '物理机', 'H3C-BIZ-A-002', 'Running', 1000, 32, 8, 'Yes', 'IMG-017', 'business-a-mysql-002.internal', 'No', 'A14-002', 'R017', 42, 3, 1, 'SN20241302', 0, 0),

-- 业务B系统服务器 (15台)
('business-b-mysql-001', '10.1.15.11', '物理机', 'H3C-BIZ-B-001', 'Running', 1200, 48, 12, 'Yes', 'IMG-018', 'business-b-mysql-001.internal', 'No', 'A15-001', 'R018', 42, 1, 1, 'SN20241401', 0, 0),
('business-b-mysql-002', '10.1.15.12', '物理机', 'H3C-BIZ-B-002', 'Running', 1200, 48, 12, 'Yes', 'IMG-018', 'business-b-mysql-002.internal', 'No', 'A15-002', 'R018', 42, 3, 1, 'SN20241402', 0, 0);

-- ================================
-- 14. 补充更多集群组数据
-- ================================

INSERT INTO cluster_groups (group_name, cluster_name, department_name) VALUES
-- 营销系统集群组
('marketing-mysql-group', 'marketing-mysql-cluster-01', '营销系统'),
('marketing-redis-group', 'marketing-redis-cluster-01', '营销系统'),

-- 客服系统集群组
('support-mysql-group', 'support-mysql-cluster-01', '客服系统'),

-- 库存系统集群组
('inventory-mysql-group', 'inventory-mysql-cluster-01', '库存系统'),

-- 搜索系统集群组
('search-elasticsearch-group', 'search-elasticsearch-cluster-01', '搜索系统'),

-- 推荐系统集群组
('recommend-redis-group', 'recommend-redis-cluster-01', '推荐系统'),

-- 监控系统集群组
('monitor-prometheus-group', 'monitor-prometheus-cluster-01', '监控系统'),

-- 日志系统集群组
('log-elasticsearch-group', 'log-elasticsearch-cluster-01', '日志系统'),

-- 其他业务系统集群组
('business-a-mysql-group', 'business-a-mysql-cluster-01', '业务A系统'),
('business-b-mysql-group', 'business-b-mysql-cluster-01', '业务B系统');

-- ================================
-- 15. 插入资源使用数据
-- ================================

INSERT INTO resource_usage_data (
    group_name, cluster_name, department_name, cpu_peak_usage, memory_peak_usage, disk_peak_usage,
    cpu_threshold, memory_threshold, disk_threshold, analysis_request_id
) VALUES
-- 支付系统资源使用分析
('payment-mysql-group', 'payment-mysql-cluster-01', '支付系统', 78.5, 71.2, 62.3, 80.0, 75.0, 70.0, 'REQ-PAY-001'),
('payment-redis-group', 'payment-redis-cluster-01', '支付系统', 45.8, 58.2, 32.1, 70.0, 65.0, 60.0, 'REQ-PAY-002'),

-- 订单系统资源使用分析
('order-mysql-group', 'order-mysql-cluster-01', '订单系统', 82.3, 67.8, 58.9, 80.0, 75.0, 70.0, 'REQ-ORD-001'),
('order-tidb-group', 'order-tidb-cluster-01', '订单系统', 85.1, 73.5, 65.0, 85.0, 80.0, 75.0, 'REQ-ORD-002'),

-- 用户系统资源使用分析
('user-mysql-group', 'user-mysql-cluster-01', '用户中心', 68.9, 69.8, 55.5, 75.0, 70.0, 65.0, 'REQ-USR-001'),

-- 物流系统资源使用分析
('logistics-mysql-group', 'logistics-mysql-cluster-01', '物流系统', 89.5, 69.6, 66.7, 85.0, 75.0, 70.0, 'REQ-LOG-001'),

-- 财务系统资源使用分析
('finance-mssql-group', 'finance-mssql-cluster-01', '财务系统', 65.8, 66.9, 68.8, 75.0, 70.0, 75.0, 'REQ-FIN-001'),

-- 数据分析资源使用分析
('analytics-mysql-group', 'analytics-mysql-cluster-01', '数据分析', 92.3, 88.4, 70.0, 90.0, 85.0, 75.0, 'REQ-ANA-001'),

-- 营销系统资源使用分析
('marketing-mysql-group', 'marketing-mysql-cluster-01', '营销系统', 65.2, 62.8, 45.3, 75.0, 70.0, 60.0, 'REQ-MKT-001'),

-- 搜索系统资源使用分析
('search-elasticsearch-group', 'search-elasticsearch-cluster-01', '搜索系统', 78.9, 82.3, 75.6, 80.0, 85.0, 80.0, 'REQ-SRC-001'),

-- 推荐系统资源使用分析
('recommend-redis-group', 'recommend-redis-cluster-01', '推荐系统', 72.4, 75.8, 48.9, 75.0, 80.0, 60.0, 'REQ-REC-001'),

-- 监控系统资源使用分析
('monitor-prometheus-group', 'monitor-prometheus-cluster-01', '监控系统', 68.5, 71.2, 82.3, 75.0, 75.0, 85.0, 'REQ-MON-001');

-- ================================
-- 16. 插入资源分析报告
-- ================================

INSERT INTO resource_analysis_reports (
    resource_usage_id, analysis_request_id, analysis_report
) VALUES
(1, 'REQ-PAY-001', '支付系统MySQL集群分析报告：集群整体运行状况良好，CPU峰值使用率78.5%接近阈值，建议监控高峰期性能。内存使用率71.2%，磁盘使用率62.3%均在合理范围内。建议进行性能优化以应对业务增长。'),
(2, 'REQ-PAY-002', '支付系统Redis集群分析报告：集群资源充足，CPU使用率45.8%，内存使用率58.2%，磁盘使用率32.1%均远低于阈值。当前配置可满足未来一段时间的业务需求。'),
(3, 'REQ-ORD-001', '订单系统MySQL集群分析报告：集群负载较高，CPU峰值使用率82.3%已超过阈值，存在性能瓶颈风险。建议增加服务器节点或进行性能调优。内存和磁盘使用正常。'),
(4, 'REQ-ORD-002', '订单系统TiDB集群分析报告：集群负载高，CPU峰值使用率85.1%达到阈值，内存使用率73.5%接近阈值。建议扩容集群以应对业务高峰期需求，同时优化查询性能。'),
(5, 'REQ-USR-001', '用户中心MySQL集群分析报告：集群运行稳定，各项指标均在正常范围内。CPU使用率68.9%，内存使用率69.8%，建议继续监控用户增长对资源的影响。'),
(6, 'REQ-LOG-001', '物流系统MySQL集群分析报告：集群负载过高，CPU峰值使用率89.5%已超过阈值，存在严重性能风险。紧急建议进行集群扩容或架构优化。'),
(7, 'REQ-FIN-001', '财务系统MSSQL集群分析报告：集群整体运行正常，各项资源使用率均在合理范围内。建议定期备份和灾备测试，确保财务数据安全。'),
(8, 'REQ-ANA-001', '数据分析MySQL集群分析报告：集群高负载运行，CPU峰值使用率92.3%、内存使用率88.4%均超过或接近阈值。建议立即进行集群扩容，并考虑数据分片优化。'),
(9, 'REQ-MKT-001', '营销系统MySQL集群分析报告：集群资源使用合理，各项指标均低于阈值。当前配置充足，可支撑营销活动的数据处理需求。'),
(10, 'REQ-SRC-001', '搜索系统Elasticsearch集群分析报告：集群负载适中，内存使用率82.3%接近阈值，建议监控搜索查询复杂度，适时优化索引配置。'),
(11, 'REQ-REC-001', '推荐系统Redis集群分析报告：集群运行良好，内存使用率75.8%接近阈值，建议监控推荐算法的内存消耗，适时进行数据清理。'),
(12, 'REQ-MON-001', '监控系统Prometheus集群分析报告：监控集群磁盘使用率82.3%接近阈值，建议配置数据保留策略，定期清理历史监控数据。');

-- ================================
-- 17. 补充更多MySQL集群数据
-- ================================

INSERT INTO mysql_cluster (cluster_name, cluster_group_name, cluster_type, cluster_status, description) VALUES
('marketing-mysql-cluster-01', 'marketing-mysql-group', 'mysql', 'active', '营销系统MySQL集群'),
('support-mysql-cluster-01', 'support-mysql-group', 'mysql', 'active', '客服系统MySQL集群'),
('inventory-mysql-cluster-01', 'inventory-mysql-group', 'mysql', 'active', '库存系统MySQL集群'),
('business-a-mysql-cluster-01', 'business-a-mysql-group', 'mysql', 'active', '业务A系统MySQL集群'),
('business-b-mysql-cluster-01', 'business-b-mysql-group', 'mysql', 'active', '业务B系统MySQL集群');

-- ================================
-- 18. 补充更多MySQL集群实例数据
-- ================================

INSERT INTO mysql_cluster_instance (cluster_name, ip, port, instance_role, version, instance_status, data_dir) VALUES
-- marketing-mysql-cluster-01 实例
('marketing-mysql-cluster-01', '10.1.7.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('marketing-mysql-cluster-01', '10.1.7.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- support-mysql-cluster-01 实例
('support-mysql-cluster-01', '10.1.8.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('support-mysql-cluster-01', '10.1.8.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- inventory-mysql-cluster-01 实例
('inventory-mysql-cluster-01', '10.1.9.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('inventory-mysql-cluster-01', '10.1.9.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- business-a-mysql-cluster-01 实例
('business-a-mysql-cluster-01', '10.1.14.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('business-a-mysql-cluster-01', '10.1.14.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- business-b-mysql-cluster-01 实例
('business-b-mysql-cluster-01', '10.1.15.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('business-b-mysql-cluster-01', '10.1.15.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql');

-- ================================
-- 19. 补充扩展集群组的业务线关系数据
-- ================================

INSERT INTO db_line (cluster_group_name, department_line_name) VALUES
-- 新增集群组的业务线关系
('marketing-mysql-group', '营销业务线'),
('marketing-redis-group', '营销业务线'),
('support-mysql-group', '客服业务线'),
('inventory-mysql-group', '库存业务线'),
('search-elasticsearch-group', '搜索业务线'),
('recommend-redis-group', '推荐业务线'),
('monitor-prometheus-group', '监控业务线'),
('log-elasticsearch-group', '日志业务线'),
('business-a-mysql-group', '业务A业务线'),
('business-b-mysql-group', '业务B业务线');

-- ================================
-- 数据统计信息
-- ================================

SELECT 
    '数据初始化完成' AS status,
    (SELECT COUNT(*) FROM hosts_pool) AS total_hosts,
    (SELECT COUNT(*) FROM cluster_groups) AS total_cluster_groups,
    (SELECT COUNT(*) FROM mysql_cluster) AS total_mysql_clusters,
    (SELECT COUNT(*) FROM mysql_cluster_instance) AS total_mysql_instances,
    (SELECT COUNT(*) FROM mssql_cluster) AS total_mssql_clusters,
    (SELECT COUNT(*) FROM hosts_applications) AS total_applications,
    (SELECT COUNT(*) FROM server_resources) AS total_monitoring_records,
    (SELECT COUNT(*) FROM resource_usage_data) AS total_usage_data,
    (SELECT COUNT(*) FROM resource_analysis_reports) AS total_analysis_reports,
    (SELECT COUNT(*) FROM db_line) AS total_business_lines; 