-- 为cluster_groups表添加cluster_type字段
ALTER TABLE `cluster_groups` 
ADD COLUMN `cluster_type` varchar(20) NOT NULL DEFAULT 'mysql' COMMENT '集群类型' 
AFTER `group_name`;

-- 更新现有数据，为已有记录设置默认cluster_type
UPDATE `cluster_groups` SET `cluster_type` = 'mysql' WHERE `cluster_type` = 'mysql';

-- 添加复合唯一索引，确保group_name和cluster_type的组合唯一
DROP INDEX `uk_group_cluster` ON `cluster_groups`;
ALTER TABLE `cluster_groups` ADD UNIQUE KEY `uk_group_cluster_type` (`group_name`, `cluster_type`);

-- 更新department_name字段为department_line_name以保持一致性
ALTER TABLE `cluster_groups` 
CHANGE COLUMN `department_name` `department_line_name` varchar(100) NOT NULL COMMENT '部门业务线名称'; 