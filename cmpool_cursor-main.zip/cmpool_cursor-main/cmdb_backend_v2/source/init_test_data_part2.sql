-- CMDB Backend V2 测试数据初始化 - 第二部分
-- 应用部署、监控数据、备份检查等数据

USE cmdb2;

-- ================================
-- 7. 插入主机应用部署数据
-- ================================

INSERT INTO hosts_applications (
    pool_id, server_type, server_version, server_subtitle, cluster_name,
    server_protocol, server_addr, server_port, server_role, server_status, department_name
) VALUES
-- 支付系统应用部署
(1, 'MySQL', '8.0.32', 'MySQL主库', 'payment-mysql-cluster-01', 'TCP', '10.1.1.11:3306', 3306, 'master', 'running', '支付系统'),
(2, 'MySQL', '8.0.32', 'MySQL从库', 'payment-mysql-cluster-01', 'TCP', '10.1.1.12:3306', 3306, 'slave', 'running', '支付系统'),
(3, 'MySQL', '8.0.32', 'MySQL从库', 'payment-mysql-cluster-01', 'TCP', '10.1.1.13:3306', 3306, 'slave', 'running', '支付系统'),
(4, 'Redis', '7.0.4', 'Redis主节点', 'payment-redis-cluster-01', 'TCP', '10.1.1.21:6379', 6379, 'master', 'running', '支付系统'),
(5, 'Redis', '7.0.4', 'Redis从节点', 'payment-redis-cluster-01', 'TCP', '10.1.1.22:6379', 6379, 'slave', 'running', '支付系统'),

-- 订单系统应用部署
(6, 'MySQL', '8.0.32', 'MySQL主库', 'order-mysql-cluster-01', 'TCP', '10.1.2.11:3306', 3306, 'master', 'running', '订单系统'),
(7, 'MySQL', '8.0.32', 'MySQL从库', 'order-mysql-cluster-01', 'TCP', '10.1.2.12:3306', 3306, 'slave', 'running', '订单系统'),
(8, 'TiDB', '6.5.0', 'TiDB节点', 'order-tidb-cluster-01', 'TCP', '10.1.2.21:4000', 4000, 'tidb', 'running', '订单系统'),
(9, 'TiDB', '6.5.0', 'TiDB节点', 'order-tidb-cluster-01', 'TCP', '10.1.2.22:4000', 4000, 'tidb', 'running', '订单系统'),

-- 用户系统应用部署
(10, 'MySQL', '8.0.32', 'MySQL主库', 'user-mysql-cluster-01', 'TCP', '10.1.3.11:3306', 3306, 'master', 'running', '用户中心'),
(11, 'MySQL', '8.0.32', 'MySQL从库', 'user-mysql-cluster-01', 'TCP', '10.1.3.12:3306', 3306, 'slave', 'running', '用户中心'),

-- 物流系统应用部署
(12, 'MySQL', '8.0.32', 'MySQL主库', 'logistics-mysql-cluster-01', 'TCP', '10.1.4.11:3306', 3306, 'master', 'running', '物流系统'),
(13, 'MySQL', '8.0.32', 'MySQL从库', 'logistics-mysql-cluster-01', 'TCP', '10.1.4.12:3306', 3306, 'slave', 'running', '物流系统'),

-- 财务系统应用部署
(14, 'SQL Server', '2019', 'MSSQL主库', 'finance-mssql-cluster-01', 'TCP', '10.1.5.11:1433', 1433, 'primary', 'running', '财务系统'),
(15, 'SQL Server', '2019', 'MSSQL从库', 'finance-mssql-cluster-01', 'TCP', '10.1.5.12:1433', 1433, 'secondary', 'running', '财务系统'),

-- 数据分析应用部署
(16, 'MySQL', '8.0.32', 'MySQL主库', 'analytics-mysql-cluster-01', 'TCP', '10.1.6.11:3306', 3306, 'master', 'running', '数据分析'),
(17, 'MySQL', '8.0.32', 'MySQL从库', 'analytics-mysql-cluster-01', 'TCP', '10.1.6.12:3306', 3306, 'slave', 'running', '数据分析');

-- ================================
-- 8. 插入服务器资源监控数据
-- ================================

INSERT INTO server_resources (
    pool_id, cluster_name, group_name, ip, port, instance_role,
    total_memory, used_memory, total_disk, used_disk, cpu_cores, cpu_load, date_time
) VALUES
-- 支付系统资源监控数据
(1, 'payment-mysql-cluster-01', 'payment-mysql-group', '10.1.1.11', 3306, 'master', 64.0, 45.6, 2000.0, 1200.0, 16, 65.5, '2024-01-15 10:30:00'),
(2, 'payment-mysql-cluster-01', 'payment-mysql-group', '10.1.1.12', 3306, 'slave', 64.0, 38.2, 2000.0, 1100.0, 16, 55.3, '2024-01-15 10:30:00'),
(3, 'payment-mysql-cluster-01', 'payment-mysql-group', '10.1.1.13', 3306, 'slave', 64.0, 42.1, 2000.0, 1150.0, 16, 60.8, '2024-01-15 10:30:00'),
(4, 'payment-redis-cluster-01', 'payment-redis-group', '10.1.1.21', 6379, 'master', 32.0, 18.5, 1000.0, 300.0, 8, 35.2, '2024-01-15 10:30:00'),
(5, 'payment-redis-cluster-01', 'payment-redis-group', '10.1.1.22', 6379, 'slave', 32.0, 16.8, 1000.0, 280.0, 8, 30.5, '2024-01-15 10:30:00'),

-- 订单系统资源监控数据
(6, 'order-mysql-cluster-01', 'order-mysql-group', '10.1.2.11', 3306, 'master', 48.0, 32.4, 1500.0, 900.0, 12, 68.7, '2024-01-15 10:30:00'),
(7, 'order-mysql-cluster-01', 'order-mysql-group', '10.1.2.12', 3306, 'slave', 48.0, 28.9, 1500.0, 850.0, 12, 58.3, '2024-01-15 10:30:00'),
(8, 'order-tidb-cluster-01', 'order-tidb-group', '10.1.2.21', 4000, 'tidb', 64.0, 48.3, 2000.0, 1300.0, 16, 72.1, '2024-01-15 10:30:00'),
(9, 'order-tidb-cluster-01', 'order-tidb-group', '10.1.2.22', 4000, 'tidb', 64.0, 45.7, 2000.0, 1250.0, 16, 69.4, '2024-01-15 10:30:00'),

-- 用户系统资源监控数据
(10, 'user-mysql-cluster-01', 'user-mysql-group', '10.1.3.11', 3306, 'master', 32.0, 22.4, 1000.0, 600.0, 8, 58.9, '2024-01-15 10:30:00'),
(11, 'user-mysql-cluster-01', 'user-mysql-group', '10.1.3.12', 3306, 'slave', 32.0, 19.6, 1000.0, 550.0, 8, 48.3, '2024-01-15 10:30:00'),

-- 物流系统资源监控数据
(12, 'logistics-mysql-cluster-01', 'logistics-mysql-group', '10.1.4.11', 3306, 'master', 48.0, 35.2, 1500.0, 1000.0, 12, 73.5, '2024-01-15 10:30:00'),
(13, 'logistics-mysql-cluster-01', 'logistics-mysql-group', '10.1.4.12', 3306, 'slave', 48.0, 31.8, 1500.0, 950.0, 12, 65.7, '2024-01-15 10:30:00'),

-- 财务系统资源监控数据
(14, 'finance-mssql-cluster-01', 'finance-mssql-group', '10.1.5.11', 1433, 'primary', 64.0, 42.7, 2000.0, 1400.0, 16, 55.8, '2024-01-15 10:30:00'),
(15, 'finance-mssql-cluster-01', 'finance-mssql-group', '10.1.5.12', 1433, 'secondary', 64.0, 38.5, 2000.0, 1350.0, 16, 48.2, '2024-01-15 10:30:00'),

-- 数据分析资源监控数据
(16, 'analytics-mysql-cluster-01', 'analytics-mysql-group', '10.1.6.11', 3306, 'master', 128.0, 89.6, 3000.0, 2100.0, 32, 78.3, '2024-01-15 10:30:00'),
(17, 'analytics-mysql-cluster-01', 'analytics-mysql-group', '10.1.6.12', 3306, 'slave', 128.0, 83.2, 3000.0, 2000.0, 32, 72.8, '2024-01-15 10:30:00');

-- ================================
-- 9. 插入集群资源摘要数据
-- ================================

INSERT INTO cluster_resource_summary (
    department, team, cluster_name, cluster_ips, server_type,
    max_cpu, avg_cpu, max_memory, avg_memory, max_disk, avg_disk
) VALUES
('支付系统', '支付团队', 'payment-mysql-cluster-01', '10.1.1.11,10.1.1.12,10.1.1.13', 'MySQL', 65.5, 60.5, 64.0, 42.0, 2000.0, 1150.0),
('支付系统', '支付团队', 'payment-redis-cluster-01', '10.1.1.21,10.1.1.22', 'Redis', 35.2, 32.9, 32.0, 17.7, 1000.0, 290.0),
('订单系统', '订单团队', 'order-mysql-cluster-01', '10.1.2.11,10.1.2.12', 'MySQL', 68.7, 63.5, 48.0, 30.7, 1500.0, 875.0),
('订单系统', '订单团队', 'order-tidb-cluster-01', '10.1.2.21,10.1.2.22', 'TiDB', 72.1, 70.8, 64.0, 47.0, 2000.0, 1275.0),
('用户中心', '用户团队', 'user-mysql-cluster-01', '10.1.3.11,10.1.3.12', 'MySQL', 58.9, 53.6, 32.0, 21.0, 1000.0, 575.0),
('物流系统', '物流团队', 'logistics-mysql-cluster-01', '10.1.4.11,10.1.4.12', 'MySQL', 73.5, 69.6, 48.0, 33.5, 1500.0, 975.0),
('财务系统', '财务团队', 'finance-mssql-cluster-01', '10.1.5.11,10.1.5.12', 'MSSQL', 55.8, 52.0, 64.0, 40.6, 2000.0, 1375.0),
('数据分析', '分析团队', 'analytics-mysql-cluster-01', '10.1.6.11,10.1.6.12', 'MySQL', 78.3, 75.6, 128.0, 86.4, 3000.0, 2050.0);

-- ================================
-- 10. 插入业务线关系数据
-- ================================

INSERT INTO db_line (cluster_group_name, department_line_name) VALUES
('payment-mysql-group', '支付业务线'),
('payment-redis-group', '支付业务线'),
('order-mysql-group', '订单业务线'),
('order-tidb-group', '订单业务线'),
('user-mysql-group', '用户业务线'),
('logistics-mysql-group', '物流业务线'),
('finance-mssql-group', '财务业务线'),
('analytics-mysql-group', '数据分析业务线');

-- ================================
-- 11. 插入备份恢复检查信息
-- ================================

INSERT INTO backup_restore_check_info (
    check_seq, check_db, check_src_ip, db_backup_time, db_backup_date,
    backup_name, db_restore_begin_time, check_dst_ip, check_app,
    check_db_type, db_app_line, db_restore_end_time, backup_check_result
) VALUES
('CHK-202401-001', 'payment-mysql-cluster-01', '10.1.1.11', '2024-01-15 02:00:00', '2024-01-15', 'payment_mysql_backup_20240115.sql', '2024-01-15 03:00:00', '10.1.1.100', '支付应用', 'MySQL', '支付业务线', '2024-01-15 03:45:00', 'OK'),
('CHK-202401-002', 'order-mysql-cluster-01', '10.1.2.11', '2024-01-15 02:00:00', '2024-01-15', 'order_mysql_backup_20240115.sql', '2024-01-15 03:00:00', '10.1.2.100', '订单应用', 'MySQL', '订单业务线', '2024-01-15 04:20:00', 'OK'),
('CHK-202401-003', 'user-mysql-cluster-01', '10.1.3.11', '2024-01-15 02:00:00', '2024-01-15', 'user_mysql_backup_20240115.sql', '2024-01-15 03:00:00', '10.1.3.100', '用户应用', 'MySQL', '用户业务线', '2024-01-15 03:30:00', 'OK'),
('CHK-202401-004', 'logistics-mysql-cluster-01', '10.1.4.11', '2024-01-15 02:00:00', '2024-01-15', 'logistics_mysql_backup_20240115.sql', '2024-01-15 03:00:00', '10.1.4.100', '物流应用', 'MySQL', '物流业务线', '2024-01-15 04:00:00', 'OK'),
('CHK-202401-005', 'finance-mssql-cluster-01', '10.1.5.11', '2024-01-15 02:00:00', '2024-01-15', 'finance_mssql_backup_20240115.bak', '2024-01-15 03:00:00', '10.1.5.100', '财务应用', 'MSSQL', '财务业务线', '2024-01-15 05:00:00', 'OK');

-- ================================
-- 12. 插入插件执行记录
-- ================================

INSERT INTO plugin_execution_records (
    check_seq, plugin_name, execution_log, result
) VALUES
('CHK-202401-001', 'mysql_backup_checker', '执行MySQL备份检查插件，检查支付系统备份完整性', '{"status": "success", "backup_size": "2.5GB", "consistency_check": "passed"}'),
('CHK-202401-002', 'mysql_backup_checker', '执行MySQL备份检查插件，检查订单系统备份完整性', '{"status": "success", "backup_size": "1.8GB", "consistency_check": "passed"}'),
('CHK-202401-003', 'mysql_backup_checker', '执行MySQL备份检查插件，检查用户系统备份完整性', '{"status": "success", "backup_size": "800MB", "consistency_check": "passed"}'),
('CHK-202401-004', 'mysql_backup_checker', '执行MySQL备份检查插件，检查物流系统备份完整性', '{"status": "success", "backup_size": "1.2GB", "consistency_check": "passed"}'),
('CHK-202401-005', 'mssql_backup_checker', '执行MSSQL备份检查插件，检查财务系统备份完整性', '{"status": "success", "backup_size": "3.0GB", "consistency_check": "passed"}'),
('CHK-202401-001', 'performance_monitor', '执行性能监控插件，监控支付系统性能指标', '{"cpu_avg": 60.5, "memory_avg": 42.0, "disk_io": "normal"}'),
('CHK-202401-002', 'performance_monitor', '执行性能监控插件，监控订单系统性能指标', '{"cpu_avg": 63.5, "memory_avg": 30.7, "disk_io": "high"}'),
('CHK-202401-003', 'security_audit', '执行安全审计插件，检查用户系统安全配置', '{"status": "passed", "vulnerabilities": 0, "security_score": 95}');

SELECT '初始化数据插入完成 - 第二部分' AS status; 