-- CMDB Backend V2 Database Schema
-- Created for go-zero framework with goctl model generation
-- Database: MySQL 5.7+

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 1. 主机资源池表
-- ----------------------------
DROP TABLE IF EXISTS `hosts_pool`;
CREATE TABLE `hosts_pool` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `host_name` varchar(50) NOT NULL COMMENT '主机名',
  `host_ip` varchar(50) NOT NULL COMMENT '主机IP',
  `host_type` varchar(10) DEFAULT NULL COMMENT '主机类型',
  `h3c_id` varchar(50) DEFAULT NULL COMMENT 'H3C ID',
  `h3c_status` varchar(20) DEFAULT NULL COMMENT 'H3C状态',
  `disk_size` int(10) unsigned DEFAULT NULL COMMENT '磁盘大小(GB)',
  `ram` int(10) unsigned DEFAULT NULL COMMENT '内存大小(GB)',
  `vcpus` int(10) unsigned DEFAULT NULL COMMENT 'CPU核数',
  `if_h3c_sync` varchar(10) DEFAULT NULL COMMENT '是否H3C同步',
  `h3c_img_id` varchar(50) DEFAULT NULL COMMENT 'H3C镜像ID',
  `h3c_hm_name` varchar(1000) DEFAULT NULL COMMENT 'H3C主机名',
  `is_delete` varchar(10) DEFAULT NULL COMMENT '是否删除标记',
  `leaf_number` varchar(50) DEFAULT NULL COMMENT '叶子节点编号',
  `rack_number` varchar(10) DEFAULT NULL COMMENT '机架号',
  `rack_height` int(10) unsigned DEFAULT NULL COMMENT '机架高度',
  `rack_start_number` int(10) unsigned DEFAULT NULL COMMENT '机架起始位置',
  `from_factor` int(10) unsigned DEFAULT NULL COMMENT '规格因子',
  `serial_number` varchar(50) DEFAULT NULL COMMENT '序列号',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_static` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否静态',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_host_ip` (`host_ip`),
  KEY `idx_host_name` (`host_name`),
  KEY `idx_host_type` (`host_type`),
  KEY `idx_is_deleted` (`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='主机资源池表';

-- ----------------------------
-- 2. 主机应用部署表
-- ----------------------------
DROP TABLE IF EXISTS `hosts_applications`;
CREATE TABLE `hosts_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `pool_id` int(10) unsigned NOT NULL COMMENT '主机池ID',
  `server_type` varchar(30) DEFAULT NULL COMMENT '服务类型(mysql/mssql/other)',
  `server_version` varchar(30) DEFAULT NULL COMMENT '服务版本',
  `server_subtitle` varchar(30) DEFAULT NULL COMMENT '服务子标题',
  `cluster_name` varchar(64) DEFAULT NULL COMMENT '集群名称',
  `server_protocol` varchar(64) DEFAULT NULL COMMENT '服务协议',
  `server_addr` varchar(100) DEFAULT NULL COMMENT '服务地址',
  `server_port` int(11) NOT NULL COMMENT '服务端口',
  `server_role` varchar(100) DEFAULT NULL COMMENT '服务角色',
  `server_status` varchar(100) DEFAULT NULL COMMENT '服务状态',
  `department_name` varchar(100) DEFAULT NULL COMMENT '部门名称',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`),
  KEY `idx_server_type` (`server_type`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='主机应用部署表';

-- ----------------------------
-- 3. MySQL集群表
-- ----------------------------
DROP TABLE IF EXISTS `mysql_cluster`;
CREATE TABLE `mysql_cluster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `cluster_group_name` varchar(100) NOT NULL COMMENT '集群组名称',
  `cluster_type` varchar(20) DEFAULT 'mysql' COMMENT '集群类型',
  `cluster_status` varchar(20) DEFAULT 'active' COMMENT '集群状态',
  `description` text COMMENT '集群描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_name` (`cluster_name`),
  KEY `idx_cluster_group_name` (`cluster_group_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='MySQL集群表';

-- ----------------------------
-- 4. MySQL集群实例表
-- ----------------------------
DROP TABLE IF EXISTS `mysql_cluster_instance`;
CREATE TABLE `mysql_cluster_instance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `ip` varchar(50) NOT NULL COMMENT '实例IP',
  `port` int(11) NOT NULL DEFAULT '3306' COMMENT '实例端口',
  `instance_role` varchar(20) NOT NULL COMMENT '实例角色(master/slave)',
  `version` varchar(30) DEFAULT NULL COMMENT 'MySQL版本',
  `instance_status` varchar(20) DEFAULT 'running' COMMENT '实例状态',
  `data_dir` varchar(255) DEFAULT NULL COMMENT '数据目录',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_ip_port` (`cluster_name`, `ip`, `port`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_ip` (`ip`),
  KEY `idx_instance_role` (`instance_role`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='MySQL集群实例表';

-- ----------------------------
-- 5. MSSQL集群表
-- ----------------------------
DROP TABLE IF EXISTS `mssql_cluster`;
CREATE TABLE `mssql_cluster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `cluster_group_name` varchar(100) NOT NULL COMMENT '集群组名称',
  `cluster_type` varchar(20) DEFAULT 'mssql' COMMENT '集群类型',
  `cluster_status` varchar(20) DEFAULT 'active' COMMENT '集群状态',
  `description` text COMMENT '集群描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_name` (`cluster_name`),
  KEY `idx_cluster_group_name` (`cluster_group_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='MSSQL集群表';

-- ----------------------------
-- 6. MSSQL集群实例表
-- ----------------------------
DROP TABLE IF EXISTS `mssql_cluster_instance`;
CREATE TABLE `mssql_cluster_instance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `ip` varchar(50) NOT NULL COMMENT '实例IP',
  `instance_port` int(11) NOT NULL DEFAULT '1433' COMMENT '实例端口',
  `instance_role` varchar(20) NOT NULL COMMENT '实例角色(primary/secondary)',
  `version` varchar(30) DEFAULT NULL COMMENT 'MSSQL版本',
  `instance_status` varchar(20) DEFAULT 'running' COMMENT '实例状态',
  `data_dir` varchar(255) DEFAULT NULL COMMENT '数据目录',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_ip_port` (`cluster_name`, `ip`, `instance_port`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_ip` (`ip`),
  KEY `idx_instance_role` (`instance_role`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='MSSQL集群实例表';

-- ----------------------------
-- 7. TiDB集群表
-- ----------------------------
DROP TABLE IF EXISTS `tidb_cluster`;
CREATE TABLE `tidb_cluster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `cluster_group_name` varchar(100) NOT NULL COMMENT '集群组名称',
  `cluster_type` varchar(20) DEFAULT 'tidb' COMMENT '集群类型',
  `cluster_status` varchar(20) DEFAULT 'active' COMMENT '集群状态',
  `description` text COMMENT '集群描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_name` (`cluster_name`),
  KEY `idx_cluster_group_name` (`cluster_group_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='TiDB集群表';

-- ----------------------------
-- 8. TiDB集群实例表
-- ----------------------------
DROP TABLE IF EXISTS `tidb_cluster_instance`;
CREATE TABLE `tidb_cluster_instance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `ip` varchar(50) NOT NULL COMMENT '实例IP',
  `port` int(11) NOT NULL DEFAULT '4000' COMMENT '实例端口',
  `instance_role` varchar(20) NOT NULL COMMENT '实例角色(tidb/tikv/pd)',
  `version` varchar(30) DEFAULT NULL COMMENT 'TiDB版本',
  `instance_status` varchar(20) DEFAULT 'running' COMMENT '实例状态',
  `data_dir` varchar(255) DEFAULT NULL COMMENT '数据目录',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_ip_port` (`cluster_name`, `ip`, `port`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_ip` (`ip`),
  KEY `idx_instance_role` (`instance_role`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='TiDB集群实例表';

-- ----------------------------
-- 9. GoldenDB集群表
-- ----------------------------
DROP TABLE IF EXISTS `goldendb_cluster`;
CREATE TABLE `goldendb_cluster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `cluster_group_name` varchar(100) NOT NULL COMMENT '集群组名称',
  `cluster_type` varchar(20) DEFAULT 'goldendb' COMMENT '集群类型',
  `cluster_status` varchar(20) DEFAULT 'active' COMMENT '集群状态',
  `description` text COMMENT '集群描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_name` (`cluster_name`),
  KEY `idx_cluster_group_name` (`cluster_group_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GoldenDB集群表';

-- ----------------------------
-- 10. GoldenDB集群实例表
-- ----------------------------
DROP TABLE IF EXISTS `goldendb_cluster_instance`;
CREATE TABLE `goldendb_cluster_instance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `ip` varchar(50) NOT NULL COMMENT '实例IP',
  `port` int(11) NOT NULL DEFAULT '3306' COMMENT '实例端口',
  `instance_role` varchar(20) NOT NULL COMMENT '实例角色(primary/secondary)',
  `version` varchar(30) DEFAULT NULL COMMENT 'GoldenDB版本',
  `instance_status` varchar(20) DEFAULT 'running' COMMENT '实例状态',
  `data_dir` varchar(255) DEFAULT NULL COMMENT '数据目录',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_ip_port` (`cluster_name`, `ip`, `port`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_ip` (`ip`),
  KEY `idx_instance_role` (`instance_role`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='GoldenDB集群实例表';

-- ----------------------------
-- 11. 业务线关系表
-- ----------------------------
DROP TABLE IF EXISTS `db_line`;
CREATE TABLE `db_line` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cluster_group_name` varchar(100) NOT NULL COMMENT '集群组名称',
  `department_line_name` varchar(100) NOT NULL COMMENT '部门业务线名称',
  `business_domain` varchar(100) DEFAULT NULL COMMENT '业务域',
  `contact_person` varchar(50) DEFAULT NULL COMMENT '联系人',
  `contact_email` varchar(100) DEFAULT NULL COMMENT '联系邮箱',
  `description` text COMMENT '描述',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_group_department` (`cluster_group_name`, `department_line_name`),
  KEY `idx_cluster_group_name` (`cluster_group_name`),
  KEY `idx_department_line_name` (`department_line_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='集群组与业务线关系表';

-- ----------------------------
-- 12. 服务器资源监控表
-- ----------------------------
DROP TABLE IF EXISTS `server_resources`;
CREATE TABLE `server_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `pool_id` int(10) unsigned NOT NULL COMMENT '主机池ID',
  `cluster_name` varchar(64) DEFAULT NULL COMMENT '集群名称',
  `group_name` varchar(100) DEFAULT NULL COMMENT '组名称',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `port` int(10) unsigned DEFAULT NULL COMMENT '端口',
  `instance_role` varchar(50) DEFAULT NULL COMMENT '实例角色',
  `total_memory` double DEFAULT NULL COMMENT '总内存(GB)',
  `used_memory` double DEFAULT NULL COMMENT '已用内存(GB)',
  `total_disk` double DEFAULT NULL COMMENT '总磁盘(GB)',
  `used_disk` double DEFAULT NULL COMMENT '已用磁盘(GB)',
  `cpu_cores` int(11) DEFAULT NULL COMMENT 'CPU核数',
  `cpu_load` double DEFAULT NULL COMMENT 'CPU负载(%)',
  `date_time` datetime NOT NULL COMMENT '监控时间',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_ip` (`ip`),
  KEY `idx_date_time` (`date_time`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务器资源监控表';

-- ----------------------------
-- 13. 集群组表
-- ----------------------------
DROP TABLE IF EXISTS `cluster_groups`;
CREATE TABLE `cluster_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `group_name` varchar(100) NOT NULL COMMENT '组名称',
  `cluster_type` varchar(20) NOT NULL DEFAULT 'mysql' COMMENT '集群类型',
  `cluster_name` varchar(64) NOT NULL COMMENT '集群名称',
  `department_line_name` varchar(100) NOT NULL COMMENT '部门业务线名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_cluster_type` (`group_name`, `cluster_type`),
  KEY `idx_group_name` (`group_name`),
  KEY `idx_cluster_type` (`cluster_type`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_department_line_name` (`department_line_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='集群组表';

-- ----------------------------
-- 14. 集群资源摘要表
-- ----------------------------
DROP TABLE IF EXISTS `cluster_resource_summary`;
CREATE TABLE `cluster_resource_summary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department` varchar(100) DEFAULT NULL COMMENT '部门',
  `team` varchar(100) DEFAULT NULL COMMENT '团队',
  `cluster_name` varchar(64) DEFAULT NULL COMMENT '集群名称',
  `cluster_ips` text COMMENT '集群IP列表',
  `server_type` varchar(30) DEFAULT NULL COMMENT '服务类型',
  `max_cpu` double DEFAULT NULL COMMENT '最大CPU使用率',
  `avg_cpu` double DEFAULT NULL COMMENT '平均CPU使用率',
  `max_memory` double DEFAULT NULL COMMENT '最大内存使用率',
  `avg_memory` double DEFAULT NULL COMMENT '平均内存使用率',
  `max_disk` double DEFAULT NULL COMMENT '最大磁盘使用率',
  `avg_disk` double DEFAULT NULL COMMENT '平均磁盘使用率',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_department` (`department`),
  KEY `idx_server_type` (`server_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='集群资源摘要表';

-- ----------------------------
-- 15. 备份恢复检查信息表
-- ----------------------------
DROP TABLE IF EXISTS `backup_restore_check_info`;
CREATE TABLE `backup_restore_check_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `check_seq` varchar(20) NOT NULL COMMENT '检查轮次',
  `check_db` varchar(50) NOT NULL COMMENT '检查数据库集群',
  `check_src_ip` varchar(50) NOT NULL COMMENT '备份IP',
  `db_backup_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据库备份时间',
  `db_backup_date` varchar(20) NOT NULL COMMENT '备份日期',
  `backup_name` varchar(200) NOT NULL COMMENT '备份文件名',
  `db_restore_begin_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '恢复开始时间',
  `check_dst_ip` varchar(50) NOT NULL COMMENT '恢复IP',
  `check_app` varchar(50) NOT NULL COMMENT '恢复业务',
  `check_db_type` varchar(20) NOT NULL COMMENT '数据库架构',
  `db_app_line` varchar(50) NOT NULL COMMENT '数据库应用团队',
  `db_restore_end_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '恢复结束时间',
  `backup_check_result` varchar(10) NOT NULL DEFAULT 'OK' COMMENT '备份检查结果',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_check_seq` (`check_seq`),
  KEY `idx_check_db` (`check_db`),
  KEY `idx_check_src_ip` (`check_src_ip`),
  KEY `idx_db_backup_date` (`db_backup_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='备份恢复检查信息表';

-- ----------------------------
-- 16. 插件执行记录表
-- ----------------------------
DROP TABLE IF EXISTS `plugin_execution_records`;
CREATE TABLE `plugin_execution_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `check_seq` varchar(20) NOT NULL COMMENT '检查轮次',
  `plugin_name` varchar(100) NOT NULL COMMENT '插件名称',
  `execution_log` text COMMENT '执行日志',
  `result` text COMMENT '执行结果',
  PRIMARY KEY (`id`),
  KEY `idx_check_seq` (`check_seq`),
  KEY `idx_plugin_name` (`plugin_name`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='插件执行记录表';

-- ----------------------------
-- 17. 资源使用数据表
-- ----------------------------
DROP TABLE IF EXISTS `resource_usage_data`;
CREATE TABLE `resource_usage_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `group_name` varchar(100) NOT NULL COMMENT '组名称',
  `cluster_name` varchar(100) NOT NULL COMMENT '集群名称',
  `department_name` varchar(100) NOT NULL COMMENT '部门名称',
  `cpu_peak_usage` double DEFAULT NULL COMMENT 'CPU峰值使用率',
  `memory_peak_usage` double DEFAULT NULL COMMENT '内存峰值使用率',
  `disk_peak_usage` double DEFAULT NULL COMMENT '磁盘峰值使用率',
  `cpu_threshold` double DEFAULT NULL COMMENT 'CPU阈值',
  `memory_threshold` double DEFAULT NULL COMMENT '内存阈值',
  `disk_threshold` double DEFAULT NULL COMMENT '磁盘阈值',
  `analysis_request_id` varchar(100) DEFAULT NULL COMMENT '分析请求ID',
  PRIMARY KEY (`id`),
  KEY `idx_group_name` (`group_name`),
  KEY `idx_cluster_name` (`cluster_name`),
  KEY `idx_department_name` (`department_name`),
  KEY `idx_analysis_request_id` (`analysis_request_id`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资源使用数据表';

-- ----------------------------
-- 18. 资源分析报告表
-- ----------------------------
DROP TABLE IF EXISTS `resource_analysis_reports`;
CREATE TABLE `resource_analysis_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `resource_usage_id` int(10) unsigned NOT NULL COMMENT '资源使用数据ID',
  `analysis_request_id` varchar(100) NOT NULL COMMENT '分析请求ID',
  `analysis_report` text NOT NULL COMMENT '分析报告内容',
  PRIMARY KEY (`id`),
  KEY `idx_resource_usage_id` (`resource_usage_id`),
  KEY `idx_analysis_request_id` (`analysis_request_id`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资源分析报告表';

-- ----------------------------
-- 初始化数据
-- ----------------------------

-- 插入示例集群组数据
INSERT INTO `cluster_groups` (`group_name`, `cluster_type`, `cluster_name`, `department_line_name`) VALUES
('payment-mysql-group', 'mysql', 'payment-mysql-cluster', '支付系统'),
('order-mysql-group', 'mysql', 'order-mysql-cluster', '订单系统'),
('user-mysql-group', 'mysql', 'user-mysql-cluster', '用户中心'),
('logistics-mysql-group', 'mysql', 'logistics-mysql-cluster', '物流系统'),
('financial-mssql-group', 'mssql', 'financial-mssql-cluster', '财务系统'),
('crm-mssql-group', 'mssql', 'crm-mssql-cluster', '客户关系管理'),
('analytics-mysql-group', 'mysql', 'analytics-mysql-cluster', '数据分析'),
('content-mysql-group', 'mysql', 'content-mysql-cluster', '内容管理');

-- 插入示例MySQL集群数据
INSERT INTO `mysql_cluster` (`cluster_name`, `cluster_group_name`) VALUES
('payment-mysql-cluster', 'payment-mysql-group'),
('order-mysql-cluster', 'order-mysql-group'),
('user-mysql-cluster', 'user-mysql-group'),
('logistics-mysql-cluster', 'logistics-mysql-group'),
('analytics-mysql-cluster', 'analytics-mysql-group'),
('content-mysql-cluster', 'content-mysql-group');

-- 插入示例MSSQL集群数据
INSERT INTO `mssql_cluster` (`cluster_name`, `cluster_group_name`) VALUES
('financial-mssql-cluster', 'financial-mssql-group'),
('crm-mssql-cluster', 'crm-mssql-group');

-- 插入示例业务线关系数据
INSERT INTO `db_line` (`cluster_group_name`, `department_line_name`, `business_domain`) VALUES
('payment-mysql-group', '支付系统', '金融支付'),
('order-mysql-group', '订单系统', '电商业务'),
('user-mysql-group', '用户中心', '用户管理'),
('logistics-mysql-group', '物流系统', '供应链'),
('financial-mssql-group', '财务系统', '企业财务'),
('crm-mssql-group', '客户关系管理', '客户服务'),
('analytics-mysql-group', '数据分析', '商业智能'),
('content-mysql-group', '内容管理', '内容运营');

SET FOREIGN_KEY_CHECKS = 1; 