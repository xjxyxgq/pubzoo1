#!/bin/bash

# CMDB Backend V2 数据库初始化脚本

echo "开始初始化 CMDB 数据库..."

# 数据库配置
DB_HOST="localhost"
DB_PORT="3306" 
DB_USER="root"
DB_PASSWORD="password"
DB_NAME="cmdb"

# 检查MySQL是否运行
echo "检查MySQL服务状态..."
if ! command -v mysql &> /dev/null; then
    echo "错误: MySQL 命令未找到，请确保已安装MySQL"
    exit 1
fi

# 测试数据库连接
echo "测试数据库连接..."
mysql -h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASSWORD} -e "SELECT 1;" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "错误: 无法连接到MySQL数据库，请检查连接配置"
    echo "请确保:"
    echo "1. MySQL服务正在运行"
    echo "2. 用户名和密码正确"
    echo "3. 主机和端口配置正确"
    exit 1
fi

# 创建数据库
echo "创建数据库 ${DB_NAME}..."
mysql -h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASSWORD} -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

if [ $? -eq 0 ]; then
    echo "数据库 ${DB_NAME} 创建成功"
else
    echo "错误: 数据库创建失败"
    exit 1
fi

# 导入数据库结构
echo "导入数据库表结构..."
mysql -h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASSWORD} ${DB_NAME} < schema.sql

if [ $? -eq 0 ]; then
    echo "数据库表结构导入成功"
else
    echo "错误: 数据库表结构导入失败"
    exit 1
fi

# 验证表是否创建成功
echo "验证表创建状态..."
TABLES=$(mysql -h${DB_HOST} -P${DB_PORT} -u${DB_USER} -p${DB_PASSWORD} ${DB_NAME} -e "SHOW TABLES;" 2>/dev/null | wc -l)
EXPECTED_TABLES=15  # 预期的表数量（包括标题行）

if [ $TABLES -ge $EXPECTED_TABLES ]; then
    echo "✅ 数据库初始化完成！"
    echo "创建的主要表包括:"
    echo "  - hosts_pool (主机资源池)"
    echo "  - hosts_applications (主机应用部署)"
    echo "  - mysql_cluster & mysql_cluster_instance (MySQL集群)"
    echo "  - mssql_cluster & mssql_cluster_instance (MSSQL集群)"
    echo "  - db_line (业务线关系)"
    echo "  - server_resources (资源监控)"
    echo "  - cluster_groups (集群组)"
    echo "  - backup_restore_check_info (备份恢复检查)"
    echo "  - 以及其他辅助表..."
    echo ""
    echo "数据库连接信息:"
    echo "  主机: ${DB_HOST}:${DB_PORT}"
    echo "  数据库: ${DB_NAME}"
    echo "  用户: ${DB_USER}"
else
    echo "⚠️  警告: 表创建可能不完整，请检查SQL脚本"
fi

echo ""
echo "接下来可以："
echo "1. 修改配置文件中的数据库连接信息"
echo "2. 启动RPC和API服务"
echo "3. 使用 ./start.sh 启动完整系统" 