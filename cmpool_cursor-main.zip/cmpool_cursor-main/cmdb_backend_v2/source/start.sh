#!/bin/bash

echo "Starting CMDB Backend V2 Services..."

# 检查是否有MySQL数据库连接
echo "Checking MySQL connection..."

# 启动RPC服务
echo "Starting RPC service..."
cd rpc
go run cmpool.go -f etc/cmpool.yaml &
RPC_PID=$!
echo "RPC service started with PID: $RPC_PID"

# 等待RPC服务启动
sleep 3

# 启动API服务 (使用新的go-zero生成的代码)
echo "Starting API service..."
cd ../api
go run cmdb.go -f etc/cmdb-api.yaml &
API_PID=$!
echo "API service started with PID: $API_PID"

echo "Both services are running:"
echo "  RPC service: localhost:8080"
echo "  API service: localhost:8888"
echo ""
echo "Available API endpoints:"
echo "  GET  http://localhost:8888/api/cmdb/v1/get_hosts_pool_detail"
echo "  GET  http://localhost:8888/api/cmdb/v1/get_host_detail/:id"
echo "  POST http://localhost:8888/api/cmdb/v1/collect_applications"
echo "  GET  http://localhost:8888/api/cmdb/v1/cluster-groups"
echo "  GET  http://localhost:8888/api/cmdb/v1/server-resources"
echo "  ... and more (see README.md for full list)"
echo ""
echo "Press Ctrl+C to stop all services"

# 等待用户中断
trap "echo 'Stopping services...'; kill $RPC_PID $API_PID; exit" INT
wait 