#!/bin/bash

echo "=== 启动 CMDB Backend V2 服务测试 ==="

# 清理旧进程
echo "清理旧进程..."
pkill -f "go run.*cmpool" >/dev/null 2>&1
pkill -f "go run.*cmdb" >/dev/null 2>&1

# 启动RPC服务
echo "启动RPC服务..."
cd rpc
go run . -f etc/cmpool.yaml &
RPC_PID=$!
echo "RPC服务PID: $RPC_PID"

# 等待RPC服务启动
sleep 5

# 检查RPC服务是否启动成功
if ! lsof -i :8080 >/dev/null 2>&1; then
    echo "错误: RPC服务未能在8080端口启动"
    kill $RPC_PID >/dev/null 2>&1
    exit 1
fi
echo "✓ RPC服务在8080端口启动成功"

# 启动API服务
echo "启动API服务..."
cd ../api
go run . -f etc/cmdb-api.yaml &
API_PID=$!
echo "API服务PID: $API_PID"

# 等待API服务启动
sleep 5

# 检查API服务是否启动成功
if ! lsof -i :8888 >/dev/null 2>&1; then
    echo "错误: API服务未能在8888端口启动"
    kill $RPC_PID $API_PID >/dev/null 2>&1
    exit 1
fi
echo "✓ API服务在8888端口启动成功"

# 测试API接口
echo "测试API接口..."
cd ..

echo "测试 get_hosts_pool_detail 接口:"
curl -s -X GET "http://localhost:8888/api/cmdb/v1/get_hosts_pool_detail" \
     -H "Content-Type: application/json" | jq . || echo "API调用失败"

echo ""
echo "=== 服务测试完成 ==="
echo "RPC服务运行在: http://localhost:8080"
echo "API服务运行在: http://localhost:8888"
echo ""
echo "要停止服务，请运行:"
echo "kill $RPC_PID $API_PID"

# 保持脚本运行，不自动退出
echo "按 Ctrl+C 停止所有服务"
wait 