-- 硬件资源验证相关表结构

-- ----------------------------
-- 硬件资源验证执行记录表
-- ----------------------------
DROP TABLE IF EXISTS `hardware_resource_verification`;
CREATE TABLE `hardware_resource_verification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  `task_id` varchar(64) NOT NULL COMMENT '任务ID，用于关联同一批次的多个主机验证',
  `host_ip` varchar(50) NOT NULL COMMENT '目标主机IP',
  `resource_type` enum('cpu', 'memory', 'disk') NOT NULL COMMENT '资源类型',
  `target_percent` int(10) unsigned NOT NULL COMMENT '目标资源占用百分比',
  `duration` int(10) unsigned NOT NULL DEFAULT '300' COMMENT '执行持续时间（秒）',
  `script_params` text COMMENT '脚本执行参数（JSON格式）',
  `execution_status` enum('pending', 'running', 'completed', 'failed') NOT NULL DEFAULT 'pending' COMMENT '执行状态',
  `start_time` datetime DEFAULT NULL COMMENT '执行开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '执行结束时间',
  `exit_code` int(11) DEFAULT NULL COMMENT '脚本退出代码',
  `stdout_log` longtext COMMENT '标准输出日志',
  `stderr_log` longtext COMMENT '错误输出日志',
  `result_summary` text COMMENT '执行结果摘要（JSON格式）',
  `ssh_error` text COMMENT 'SSH连接错误信息',
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_host_ip` (`host_ip`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_execution_status` (`execution_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='硬件资源验证执行记录表';

-- 添加索引优化查询性能
CREATE INDEX `idx_host_resource_status` ON `hardware_resource_verification` (`host_ip`, `resource_type`, `execution_status`);
CREATE INDEX `idx_task_resource_time` ON `hardware_resource_verification` (`task_id`, `resource_type`, `created_at`);