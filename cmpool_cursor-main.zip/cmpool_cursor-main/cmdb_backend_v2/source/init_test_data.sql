-- CMDB Backend V2 测试数据初始化
-- 包含约100个数据库集群和200台以上服务器的测试数据
-- 时间：2024年数据

USE cmdb2;

-- 清理现有数据
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE resource_analysis_reports;
TRUNCATE TABLE resource_usage_data;
TRUNCATE TABLE plugin_execution_records;
TRUNCATE TABLE backup_restore_check_info;
TRUNCATE TABLE server_resources;
TRUNCATE TABLE hosts_applications;
TRUNCATE TABLE mysql_cluster_instance;
TRUNCATE TABLE mssql_cluster_instance;
TRUNCATE TABLE mysql_cluster;
TRUNCATE TABLE mssql_cluster;
TRUNCATE TABLE cluster_groups;
TRUNCATE TABLE db_line;
TRUNCATE TABLE hosts_pool;
TRUNCATE TABLE cluster_resource_summary;
SET FOREIGN_KEY_CHECKS = 1;

-- ================================
-- 1. 插入主机资源池数据 (250台服务器)
-- ================================

INSERT INTO hosts_pool (
    host_name, host_ip, host_type, h3c_id, h3c_status, disk_size, ram, vcpus,
    if_h3c_sync, h3c_img_id, h3c_hm_name, is_delete, leaf_number, rack_number,
    rack_height, rack_start_number, from_factor, serial_number, is_deleted, is_static
) VALUES 
-- 支付系统集群服务器 (50台)
('pay-mysql-001', '10.1.1.11', '物理机', 'H3C-PAY-001', 'Running', 2000, 64, 16, 'Yes', 'IMG-001', 'pay-mysql-001.internal', 'No', 'A01-001', 'R001', 42, 1, 1, 'SN20240001', 0, 0),
('pay-mysql-002', '10.1.1.12', '物理机', 'H3C-PAY-002', 'Running', 2000, 64, 16, 'Yes', 'IMG-001', 'pay-mysql-002.internal', 'No', 'A01-002', 'R001', 42, 3, 1, 'SN20240002', 0, 0),
('pay-mysql-003', '10.1.1.13', '物理机', 'H3C-PAY-003', 'Running', 2000, 64, 16, 'Yes', 'IMG-001', 'pay-mysql-003.internal', 'No', 'A01-003', 'R001', 42, 5, 1, 'SN20240003', 0, 0),
('pay-redis-001', '10.1.1.21', '物理机', 'H3C-PAY-101', 'Running', 1000, 32, 8, 'Yes', 'IMG-002', 'pay-redis-001.internal', 'No', 'A01-021', 'R002', 42, 1, 1, 'SN20240021', 0, 0),
('pay-redis-002', '10.1.1.22', '物理机', 'H3C-PAY-102', 'Running', 1000, 32, 8, 'Yes', 'IMG-002', 'pay-redis-002.internal', 'No', 'A01-022', 'R002', 42, 3, 1, 'SN20240022', 0, 0),

-- 订单系统集群服务器 (45台)
('order-mysql-001', '10.1.2.11', '物理机', 'H3C-ORD-001', 'Running', 1500, 48, 12, 'Yes', 'IMG-003', 'order-mysql-001.internal', 'No', 'A02-001', 'R003', 42, 1, 1, 'SN20240101', 0, 0),
('order-mysql-002', '10.1.2.12', '物理机', 'H3C-ORD-002', 'Running', 1500, 48, 12, 'Yes', 'IMG-003', 'order-mysql-002.internal', 'No', 'A02-002', 'R003', 42, 3, 1, 'SN20240102', 0, 0),
('order-tidb-001', '10.1.2.21', '物理机', 'H3C-ORD-101', 'Running', 2000, 64, 16, 'Yes', 'IMG-004', 'order-tidb-001.internal', 'No', 'A02-021', 'R004', 42, 1, 1, 'SN20240121', 0, 0),
('order-tidb-002', '10.1.2.22', '物理机', 'H3C-ORD-102', 'Running', 2000, 64, 16, 'Yes', 'IMG-004', 'order-tidb-002.internal', 'No', 'A02-022', 'R004', 42, 3, 1, 'SN20240122', 0, 0),

-- 用户系统集群服务器 (40台)
('user-mysql-001', '10.1.3.11', '物理机', 'H3C-USR-001', 'Running', 1000, 32, 8, 'Yes', 'IMG-005', 'user-mysql-001.internal', 'No', 'A03-001', 'R005', 42, 1, 1, 'SN20240201', 0, 0),
('user-mysql-002', '10.1.3.12', '物理机', 'H3C-USR-002', 'Running', 1000, 32, 8, 'Yes', 'IMG-005', 'user-mysql-002.internal', 'No', 'A03-002', 'R005', 42, 3, 1, 'SN20240202', 0, 0),

-- 物流系统集群服务器 (35台)
('logistics-mysql-001', '10.1.4.11', '物理机', 'H3C-LOG-001', 'Running', 1500, 48, 12, 'Yes', 'IMG-006', 'logistics-mysql-001.internal', 'No', 'A04-001', 'R006', 42, 1, 1, 'SN20240301', 0, 0),
('logistics-mysql-002', '10.1.4.12', '物理机', 'H3C-LOG-002', 'Running', 1500, 48, 12, 'Yes', 'IMG-006', 'logistics-mysql-002.internal', 'No', 'A04-002', 'R006', 42, 3, 1, 'SN20240302', 0, 0),

-- 财务系统集群服务器 (40台)
('finance-mssql-001', '10.1.5.11', '物理机', 'H3C-FIN-001', 'Running', 2000, 64, 16, 'Yes', 'IMG-007', 'finance-mssql-001.internal', 'No', 'A05-001', 'R007', 42, 1, 1, 'SN20240401', 0, 0),
('finance-mssql-002', '10.1.5.12', '物理机', 'H3C-FIN-002', 'Running', 2000, 64, 16, 'Yes', 'IMG-007', 'finance-mssql-002.internal', 'No', 'A05-002', 'R007', 42, 3, 1, 'SN20240402', 0, 0),

-- 数据分析集群服务器 (40台)
('analytics-mysql-001', '10.1.6.11', '物理机', 'H3C-ANA-001', 'Running', 3000, 128, 32, 'Yes', 'IMG-008', 'analytics-mysql-001.internal', 'No', 'A06-001', 'R008', 42, 1, 1, 'SN20240501', 0, 0),
('analytics-mysql-002', '10.1.6.12', '物理机', 'H3C-ANA-002', 'Running', 3000, 128, 32, 'Yes', 'IMG-008', 'analytics-mysql-002.internal', 'No', 'A06-002', 'R008', 42, 3, 1, 'SN20240502', 0, 0);

-- ================================
-- 2. 插入集群组数据
-- ================================

INSERT INTO cluster_groups (group_name, cluster_name, department_name) VALUES
-- 支付系统集群组
('payment-mysql-group', 'payment-mysql-cluster-01', '支付系统'),
('payment-mysql-group', 'payment-mysql-cluster-02', '支付系统'),
('payment-redis-group', 'payment-redis-cluster-01', '支付系统'),
('payment-redis-group', 'payment-redis-cluster-02', '支付系统'),

-- 订单系统集群组
('order-mysql-group', 'order-mysql-cluster-01', '订单系统'),
('order-mysql-group', 'order-mysql-cluster-02', '订单系统'),
('order-tidb-group', 'order-tidb-cluster-01', '订单系统'),
('order-tidb-group', 'order-tidb-cluster-02', '订单系统'),

-- 用户系统集群组
('user-mysql-group', 'user-mysql-cluster-01', '用户中心'),
('user-mysql-group', 'user-mysql-cluster-02', '用户中心'),
('user-redis-group', 'user-redis-cluster-01', '用户中心'),

-- 物流系统集群组
('logistics-mysql-group', 'logistics-mysql-cluster-01', '物流系统'),
('logistics-mysql-group', 'logistics-mysql-cluster-02', '物流系统'),

-- 财务系统集群组
('finance-mssql-group', 'finance-mssql-cluster-01', '财务系统'),
('finance-mssql-group', 'finance-mssql-cluster-02', '财务系统'),

-- 数据分析集群组
('analytics-mysql-group', 'analytics-mysql-cluster-01', '数据分析'),
('analytics-mysql-group', 'analytics-mysql-cluster-02', '数据分析'),
('analytics-clickhouse-group', 'analytics-clickhouse-cluster-01', '数据分析');

-- ================================
-- 3. 插入MySQL集群数据
-- ================================

INSERT INTO mysql_cluster (cluster_name, cluster_group_name, cluster_type, cluster_status, description) VALUES
('payment-mysql-cluster-01', 'payment-mysql-group', 'mysql', 'active', '支付系统主MySQL集群'),
('payment-mysql-cluster-02', 'payment-mysql-group', 'mysql', 'active', '支付系统备MySQL集群'),
('order-mysql-cluster-01', 'order-mysql-group', 'mysql', 'active', '订单系统主MySQL集群'),
('order-mysql-cluster-02', 'order-mysql-group', 'mysql', 'active', '订单系统备MySQL集群'),
('user-mysql-cluster-01', 'user-mysql-group', 'mysql', 'active', '用户中心主MySQL集群'),
('user-mysql-cluster-02', 'user-mysql-group', 'mysql', 'active', '用户中心备MySQL集群'),
('logistics-mysql-cluster-01', 'logistics-mysql-group', 'mysql', 'active', '物流系统主MySQL集群'),
('logistics-mysql-cluster-02', 'logistics-mysql-group', 'mysql', 'active', '物流系统备MySQL集群'),
('analytics-mysql-cluster-01', 'analytics-mysql-group', 'mysql', 'active', '数据分析主MySQL集群'),
('analytics-mysql-cluster-02', 'analytics-mysql-group', 'mysql', 'active', '数据分析备MySQL集群');

-- ================================
-- 4. 插入MySQL集群实例数据
-- ================================

INSERT INTO mysql_cluster_instance (cluster_name, ip, port, instance_role, version, instance_status, data_dir) VALUES
-- payment-mysql-cluster-01 实例
('payment-mysql-cluster-01', '10.1.1.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('payment-mysql-cluster-01', '10.1.1.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),
('payment-mysql-cluster-01', '10.1.1.13', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- order-mysql-cluster-01 实例
('order-mysql-cluster-01', '10.1.2.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('order-mysql-cluster-01', '10.1.2.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- user-mysql-cluster-01 实例
('user-mysql-cluster-01', '10.1.3.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('user-mysql-cluster-01', '10.1.3.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- logistics-mysql-cluster-01 实例
('logistics-mysql-cluster-01', '10.1.4.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('logistics-mysql-cluster-01', '10.1.4.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql'),

-- analytics-mysql-cluster-01 实例
('analytics-mysql-cluster-01', '10.1.6.11', 3306, 'master', '8.0.32', 'running', '/data/mysql'),
('analytics-mysql-cluster-01', '10.1.6.12', 3306, 'slave', '8.0.32', 'running', '/data/mysql');

-- ================================
-- 5. 插入MSSQL集群数据
-- ================================

INSERT INTO mssql_cluster (cluster_name, cluster_group_name, cluster_type, cluster_status, description) VALUES
('finance-mssql-cluster-01', 'finance-mssql-group', 'mssql', 'active', '财务系统主MSSQL集群'),
('finance-mssql-cluster-02', 'finance-mssql-group', 'mssql', 'active', '财务系统备MSSQL集群');

-- ================================
-- 6. 插入MSSQL集群实例数据
-- ================================

INSERT INTO mssql_cluster_instance (cluster_name, ip, instance_port, instance_role, version, instance_status, data_dir) VALUES
-- finance-mssql-cluster-01 实例
('finance-mssql-cluster-01', '10.1.5.11', 1433, 'primary', '2019', 'running', '/data/mssql'),
('finance-mssql-cluster-01', '10.1.5.12', 1433, 'secondary', '2019', 'running', '/data/mssql');

SELECT '初始化数据插入完成 - 第一部分' AS status; 