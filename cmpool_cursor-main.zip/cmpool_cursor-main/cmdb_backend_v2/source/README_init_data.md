# CMDB Backend V2 初始化测试数据

## 概述

本目录包含了完整的 CMDB 测试数据，用于演示和测试系统功能。数据包含：

- **250+ 台服务器主机** - 涵盖物理机和虚拟机
- **100+ 个数据库集群** - 包括 MySQL、MSSQL、TiDB、Redis、Elasticsearch 等
- **完整的业务系统** - 支付、订单、用户、物流、财务、数据分析等
- **监控和分析数据** - 资源使用情况、性能分析报告等

## 文件说明

```
cmdb_backend_v2/
├── init_test_data.sql          # 第一部分：主机资源池和集群基础数据
├── init_test_data_part2.sql    # 第二部分：应用部署和监控数据  
├── init_test_data_part3.sql    # 第三部分：资源分析和扩展数据
├── run_init_data.sh           # 自动化执行脚本
└── README_init_data.md        # 使用说明（本文件）
```

## 使用方法

### 方法一：使用自动化脚本（推荐）

```bash
# 确保在 cmdb_backend_v2 目录下
cd cmdb_backend_v2

# 执行初始化脚本
./run_init_data.sh
```

脚本会自动：
1. 检查 MySQL 连接
2. 按顺序导入三个 SQL 文件
3. 验证数据导入结果
4. 显示数据统计信息

### 方法二：手动执行 SQL 文件

```bash
# 第一部分：基础数据
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data.sql

# 第二部分：应用和监控数据
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data_part2.sql

# 第三部分：分析和扩展数据
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data_part3.sql
```

## 数据结构概览

### 业务系统分布

| 系统名称 | 集群类型 | 主机数量 | 描述 |
|---------|---------|---------|------|
| 支付系统 | MySQL + Redis | 50台 | 核心支付业务，高可用配置 |
| 订单系统 | MySQL + TiDB | 45台 | 订单处理，分布式架构 |
| 用户中心 | MySQL + Redis | 40台 | 用户管理和认证 |
| 物流系统 | MySQL | 35台 | 物流跟踪和配送 |
| 财务系统 | MSSQL | 40台 | 财务核算，高安全性 |
| 数据分析 | MySQL | 40台 | 大数据分析，高性能配置 |
| 营销系统 | MySQL + Redis | 30台 | 营销活动和推广 |
| 搜索系统 | Elasticsearch | 30台 | 全文搜索服务 |
| 其他系统 | 各种类型 | 35台 | 客服、库存、推荐等 |

### IP 地址分配

- **支付系统**: `10.1.1.x` 网段
- **订单系统**: `10.1.2.x` 网段  
- **用户中心**: `10.1.3.x` 网段
- **物流系统**: `10.1.4.x` 网段
- **财务系统**: `10.1.5.x` 网段
- **数据分析**: `10.1.6.x` 网段
- **营销系统**: `10.1.7.x` 网段
- **其他系统**: `10.1.8.x` - `10.1.15.x` 网段

### 硬件配置

| 服务器类型 | CPU核数 | 内存(GB) | 磁盘(GB) | 用途 |
|-----------|---------|----------|----------|------|
| 高性能型 | 32 | 128 | 3000 | 数据分析、日志系统 |
| 标准型 | 16 | 64 | 2000 | 核心业务系统 |
| 经济型 | 12 | 48 | 1500 | 一般业务系统 |
| 轻量型 | 8 | 32 | 1000 | 缓存、轻量服务 |

## 测试 API 接口

初始化数据后，可以测试以下接口：

```bash
# 获取集群组信息
curl "http://localhost:8888/cluster_groups"

# 获取服务器资源信息
curl "http://localhost:8888/server_resource?cluster_name=payment-mysql-cluster-01"

# 获取主机池详情
curl "http://localhost:8888/hosts_pool_detail?pool_id=1"
```

## 数据特点

1. **真实性**: 数据模拟真实生产环境的配置和负载情况
2. **关联性**: 各表数据之间保持完整的外键关联关系
3. **多样性**: 涵盖多种数据库类型和业务场景
4. **层次性**: 从基础设施到应用部署的完整层次结构
5. **监控性**: 包含完整的监控数据和分析报告

## 注意事项

1. **数据库连接**: 确保 MySQL 服务运行在 `127.0.0.1:3311`
2. **权限要求**: 需要 `myuser` 用户具有完整的数据库操作权限
3. **数据清理**: 脚本会自动清理现有数据，请注意备份重要数据
4. **顺序执行**: 必须按照 part1 → part2 → part3 的顺序执行
5. **编码格式**: SQL 文件使用 UTF-8 编码，支持中文字符

## 故障排除

### 连接失败
```bash
# 检查 MySQL 服务状态
sudo service mysql status

# 检查端口监听
netstat -tlnp | grep 3311
```

### 权限错误
```bash
# 重新授权用户
mysql -uroot -p -e "GRANT ALL PRIVILEGES ON cmdb2.* TO 'myuser'@'%'; FLUSH PRIVILEGES;"
```

### 编码问题
```bash
# 设置 MySQL 客户端编码
mysql --default-character-set=utf8mb4 -h127.0.0.1 -P3311 -umyuser -pmyuser
```

---

**初始化完成后，您就可以开始测试 CMDB 系统的各项功能了！** 🎉 