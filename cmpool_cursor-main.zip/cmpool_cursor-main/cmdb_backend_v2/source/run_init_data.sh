#!/bin/bash

# CMDB Backend V2 初始化测试数据执行脚本
# 执行顺序：先清理数据，然后按顺序导入测试数据

echo "开始初始化 CMDB 测试数据..."

# 检查MySQL连接
echo "检查MySQL连接..."
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser -e "SELECT 'MySQL连接成功' as status;" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ MySQL连接失败，请检查数据库配置"
    echo "连接信息: host=127.0.0.1 port=3311 user=myuser password=myuser database=cmdb2"
    exit 1
fi

echo "✅ MySQL连接成功"

# 执行第一部分初始化数据
echo ""
echo "🚀 执行第一部分：主机资源池和集群基础数据..."
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data.sql
if [ $? -ne 0 ]; then
    echo "❌ 第一部分数据导入失败"
    exit 1
fi
echo "✅ 第一部分数据导入成功"

# 执行第二部分初始化数据
echo ""
echo "🚀 执行第二部分：应用部署和监控数据..."
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data_part2.sql
if [ $? -ne 0 ]; then
    echo "❌ 第二部分数据导入失败"
    exit 1
fi
echo "✅ 第二部分数据导入成功"

# 执行第三部分初始化数据
echo ""
echo "🚀 执行第三部分：资源分析和扩展数据..."
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser < init_test_data_part3.sql
if [ $? -ne 0 ]; then
    echo "❌ 第三部分数据导入失败"
    exit 1
fi
echo "✅ 第三部分数据导入成功"

# 验证数据导入
echo ""
echo "📊 验证数据导入结果..."
mysql -h127.0.0.1 -P3311 -umyuser -pmyuser -e "
USE cmdb2;
SELECT 
    '=== 数据统计 ===' as info,
    '' as separator;
SELECT 
    '主机总数' as item,
    COUNT(*) as count 
FROM hosts_pool;
SELECT 
    '集群组总数' as item,
    COUNT(*) as count 
FROM cluster_groups;
SELECT 
    'MySQL集群总数' as item,
    COUNT(*) as count 
FROM mysql_cluster;
SELECT 
    'MySQL实例总数' as item,
    COUNT(*) as count 
FROM mysql_cluster_instance;
SELECT 
    'MSSQL集群总数' as item,
    COUNT(*) as count 
FROM mssql_cluster;
SELECT 
    '应用部署总数' as item,
    COUNT(*) as count 
FROM hosts_applications;
SELECT 
    '监控记录总数' as item,
    COUNT(*) as count 
FROM server_resources;
SELECT 
    '资源分析数据总数' as item,
    COUNT(*) as count 
FROM resource_usage_data;
SELECT 
    '分析报告总数' as item,
    COUNT(*) as count 
FROM resource_analysis_reports;
"

echo ""
echo "🎉 所有测试数据初始化完成！"
echo ""
echo "📝 数据概览："
echo "   - 250+ 台服务器主机"
echo "   - 100+ 个数据库集群"
echo "   - 涵盖 MySQL、MSSQL、TiDB、Redis、Elasticsearch 等多种数据库类型"
echo "   - 包含支付、订单、用户、物流、财务、数据分析等业务系统"
echo "   - 完整的监控数据、备份检查记录、资源分析报告"
echo ""
echo "✨ 现在可以启动 RPC 和 API 服务进行测试了！" 