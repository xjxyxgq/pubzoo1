package svc

import (
	"cmdb-api/cmpool"
	"cmdb-api/internal/config"

	"github.com/zeromicro/go-zero/zrpc"
)

type ServiceContext struct {
	Config    config.Config
	CmpoolRpc cmpool.CmpoolClient
}

func NewServiceContext(c config.Config) *ServiceContext {
	rpcClient := zrpc.MustNewClient(c.RpcConfig)

	return &ServiceContext{
		Config:    c,
		CmpoolRpc: cmpool.NewCmpoolClient(rpcClient.Conn()),
	}
}
