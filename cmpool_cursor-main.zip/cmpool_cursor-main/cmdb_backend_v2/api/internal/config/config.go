package config

import (
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
)

type Config struct {
	rest.RestConf
	RpcConfig  zrpc.RpcClientConf
	DataSource string
	CorsConf   CorsConfig
}

type CorsConfig struct {
	AccessControlAllowOrigin  string `json:",optional"`
	AccessControlAllowMethods string `json:",optional"`
	AccessControlAllowHeaders string `json:",optional"`
	AccessControlExposeHeaders string `json:",optional"`
	AccessControlMaxAge       int    `json:",optional"`
}
