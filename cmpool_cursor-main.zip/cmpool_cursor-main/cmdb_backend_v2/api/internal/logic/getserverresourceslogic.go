package logic

import (
	"context"
	"fmt"
	"time"

	"cmdb-api/cmpool"
	"cmdb-api/internal/svc"
	"cmdb-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetServerResourcesLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetServerResourcesLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetServerResourcesLogic {
	return &GetServerResourcesLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetServerResourcesLogic) GetServerResources(req *types.ServerResourceRequest) (resp *types.ServerResourceListResponse, err error) {
	l.Logger.Info("开始调用RPC获取服务器资源信息")

	// 设置时间范围
	var beginTime, endTime time.Time

	// 如果请求中有时间参数，则使用请求的时间
	if req.StartDate != "" && req.EndDate != "" {
		beginTime, err = time.Parse("2006-01-02", req.StartDate)
		if err != nil {
			l.Logger.Errorf("解析开始时间失败: %v", err)
			// 如果解析失败，使用默认时间范围（最近3个月）
			endTime = time.Now()
			beginTime = endTime.AddDate(0, -3, 0)
		} else {
			endTime, err = time.Parse("2006-01-02", req.EndDate)
			if err != nil {
				l.Logger.Errorf("解析结束时间失败: %v", err)
				// 如果解析失败，使用默认时间范围（最近3个月）
				endTime = time.Now()
				beginTime = endTime.AddDate(0, -3, 0)
			}
		}
	} else {
		// 如果没有时间参数，使用默认时间范围（最近3个月）
		endTime = time.Now().AddDate(0, 0, 1)
		beginTime = endTime.AddDate(0, -3, 0)
	}

	l.Logger.Infof("查询时间范围: %s 到 %s", beginTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05"))

	// 调用RPC服务获取服务器资源信息
	rpcReq := &cmpool.ServerResourceReq{
		BeginTime: beginTime.Format("2006-01-02 15:04:05"),
		EndTime:   endTime.Format("2006-01-02 15:04:05"),
		IpList:    []string{}, // 空列表表示获取所有服务器
	}

	rpcResp, err := l.svcCtx.CmpoolRpc.GetServerResource(l.ctx, rpcReq)
	if err != nil {
		l.Logger.Errorf("调用RPC获取服务器资源信息失败: %v", err)
		return &types.ServerResourceListResponse{
			Success: false,
			Message: fmt.Sprintf("调用RPC服务失败: %v", err),
			List:    []types.ServerResource{},
		}, nil
	}

	if !rpcResp.Success {
		l.Logger.Errorf("RPC返回失败: %s", rpcResp.Message)
		return &types.ServerResourceListResponse{
			Success: false,
			Message: rpcResp.Message,
			List:    []types.ServerResource{},
		}, nil
	}

	// 转换RPC响应为API响应格式
	serverResources := make([]types.ServerResource, 0, len(rpcResp.ServerResource))
	for _, rpcResource := range rpcResp.ServerResource {
		resource := types.ServerResource{
			ID:             int(rpcResource.Id),
			CreateAt:       rpcResource.CreateAt,
			UpdateAt:       rpcResource.UpdateAt,
			PoolID:         int(rpcResource.PoolId),
			ClusterName:    rpcResource.ClusterName,
			GroupName:      rpcResource.GroupName,
			Ip:             rpcResource.Ip,
			Port:           int(rpcResource.Port),
			InstanceRole:   rpcResource.InstanceRole,
			TotalMemory:    float64(rpcResource.TotalMemory),
			UsedMemory:     float64(rpcResource.UsedMemory),
			TotalDisk:      float64(rpcResource.TotalDisk),
			UsedDisk:       float64(rpcResource.UsedDisk),
			CPUCores:       int(rpcResource.CPUCores),
			CPULoad:        float64(rpcResource.CPULoad),
			DateTime:       rpcResource.Datetime,
			DepartmentName: rpcResource.DepartmentName,
		}
		serverResources = append(serverResources, resource)
	}

	l.Logger.Infof("成功获取%d条服务器资源信息", len(serverResources))
	return &types.ServerResourceListResponse{
		Success: true,
		Message: "查询成功",
		List:    serverResources,
	}, nil
}
