package logic

import (
	"context"

	"cmdb-api/internal/svc"
	"cmdb-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CollectApplicationsLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCollectApplicationsLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CollectApplicationsLogic {
	return &CollectApplicationsLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CollectApplicationsLogic) CollectApplications() (resp *types.BaseResponse, err error) {
	// todo: add your logic here and delete this line

	return
}
