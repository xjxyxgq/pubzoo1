package svc

import (
	"cmdb-rpc/internal/config"
	"cmdb-rpc/internal/datasource"
	"cmdb-rpc/internal/model"

	_ "github.com/go-sql-driver/mysql"
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

type ServiceContext struct {
	Config      config.Config
	DB          sqlx.SqlConn
	CSVLoader   *datasource.CSVLoader
	ExternalAPI *datasource.ExternalAPI
	DataSync    *datasource.DataSync

	// 数据库模型
	HostsPoolModel               model.HostsPoolModel
	HostsApplicationsModel       model.HostsApplicationsModel
	MysqlClusterModel            model.MysqlClusterModel
	MysqlClusterInstanceModel    model.MysqlClusterInstanceModel
	MssqlClusterModel            model.MssqlClusterModel
	MssqlClusterInstanceModel    model.MssqlClusterInstanceModel
	TidbClusterModel             model.TidbClusterModel
	TidbClusterInstanceModel     model.TidbClusterInstanceModel
	GoldendbClusterModel         model.GoldendbClusterModel
	GoldendbClusterInstanceModel model.GoldendbClusterInstanceModel
	DbLineModel                  model.DbLineModel
	ServerResourcesModel         model.ServerResourcesModel
	ClusterGroupsModel           model.ClusterGroupsModel
	ClusterResourceSummaryModel  model.ClusterResourceSummaryModel
	BackupRestoreCheckInfoModel  model.BackupRestoreCheckInfoModel
	PluginExecutionRecordsModel       model.PluginExecutionRecordsModel
	ResourceUsageDataModel            model.ResourceUsageDataModel
	ResourceAnalysisReportsModel      model.ResourceAnalysisReportsModel
	HardwareResourceVerificationModel model.HardwareResourceVerificationModel
}

func NewServiceContext(c config.Config) *ServiceContext {
	db := sqlx.NewMysql(c.DataSource)

	// 配置缓存
	// cacheConf := cache.CacheConf{
	// 	{
	// 		RedisConf: redis.RedisConf{
	// 			Host: "localhost:6379",
	// 		},
	// 	},
	// }
	cacheConf := cache.CacheConf{
		{
			RedisConf: redis.RedisConf{
				Host: c.Redis.Host,
				Type: c.Redis.Type,
				Pass: c.Redis.Pass,
			},
			Weight: 100,
		},
	}

	return &ServiceContext{
		Config:      c,
		DB:          db,
		CSVLoader:   datasource.NewCSVLoader(db, cacheConf),
		ExternalAPI: datasource.NewExternalAPI(db, cacheConf),
		DataSync:    datasource.NewDataSync(db, cacheConf),

		// 初始化所有数据库模型
		HostsPoolModel:               model.NewHostsPoolModel(db, cacheConf),
		HostsApplicationsModel:       model.NewHostsApplicationsModel(db, cacheConf),
		MysqlClusterModel:            model.NewMysqlClusterModel(db, cacheConf),
		MysqlClusterInstanceModel:    model.NewMysqlClusterInstanceModel(db, cacheConf),
		MssqlClusterModel:            model.NewMssqlClusterModel(db, cacheConf),
		MssqlClusterInstanceModel:    model.NewMssqlClusterInstanceModel(db, cacheConf),
		TidbClusterModel:             model.NewTidbClusterModel(db, cacheConf),
		TidbClusterInstanceModel:     model.NewTidbClusterInstanceModel(db, cacheConf),
		GoldendbClusterModel:         model.NewGoldendbClusterModel(db, cacheConf),
		GoldendbClusterInstanceModel: model.NewGoldendbClusterInstanceModel(db, cacheConf),
		DbLineModel:                  model.NewDbLineModel(db, cacheConf),
		ServerResourcesModel:         model.NewServerResourcesModel(db, cacheConf),
		ClusterGroupsModel:           model.NewClusterGroupsModel(db, cacheConf),
		ClusterResourceSummaryModel:  model.NewClusterResourceSummaryModel(db, cacheConf),
		BackupRestoreCheckInfoModel:  model.NewBackupRestoreCheckInfoModel(db, cacheConf),
		PluginExecutionRecordsModel:       model.NewPluginExecutionRecordsModel(db, cacheConf),
		ResourceUsageDataModel:            model.NewResourceUsageDataModel(db, cacheConf),
		ResourceAnalysisReportsModel:      model.NewResourceAnalysisReportsModel(db, cacheConf),
		HardwareResourceVerificationModel: model.NewHardwareResourceVerificationModel(db, cacheConf),
	}
}
