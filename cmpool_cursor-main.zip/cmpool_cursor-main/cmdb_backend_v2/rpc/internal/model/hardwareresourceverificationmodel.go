package model

import (
	"database/sql"
	"fmt"
	"strings"

	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ HardwareResourceVerificationModel = (*customHardwareResourceVerificationModel)(nil)

type (
	// HardwareResourceVerificationModel is an interface to be customized, add more methods here,
	// and implement the added methods in customHardwareResourceVerificationModel.
	HardwareResourceVerificationModel interface {
		hardwareResourceVerificationModel
		InsertVerification(data *HardwareResourceVerification) (sql.Result, error)
		FindByTaskId(taskId string) ([]*HardwareResourceVerification, error)
		FindByHostIp(hostIp string, resourceType string, limit int32) ([]*HardwareResourceVerification, error)
		FindByHostIpList(hostIpList []string, resourceType string) ([]*HardwareResourceVerification, error)
		UpdateVerificationStatus(id int64, status, startTime, endTime string, exitCode sql.NullInt64, stdoutLog, stderrLog, resultSummary, sshError sql.NullString) error
	}

	customHardwareResourceVerificationModel struct {
		*defaultHardwareResourceVerificationModel
	}

	HardwareResourceVerification struct {
		Id             int64          `db:"id"`
		CreatedAt      string         `db:"created_at"`
		UpdatedAt      string         `db:"updated_at"`
		DeletedAt      sql.NullString `db:"deleted_at"`
		TaskId         string         `db:"task_id"`
		HostIp         string         `db:"host_ip"`
		ResourceType   string         `db:"resource_type"`
		TargetPercent  int32          `db:"target_percent"`
		Duration       int32          `db:"duration"`
		ScriptParams   sql.NullString `db:"script_params"`
		ExecutionStatus string        `db:"execution_status"`
		StartTime      sql.NullString `db:"start_time"`
		EndTime        sql.NullString `db:"end_time"`
		ExitCode       sql.NullInt64  `db:"exit_code"`
		StdoutLog      sql.NullString `db:"stdout_log"`
		StderrLog      sql.NullString `db:"stderr_log"`
		ResultSummary  sql.NullString `db:"result_summary"`
		SshError       sql.NullString `db:"ssh_error"`
	}
)

// NewHardwareResourceVerificationModel returns a model for the database table.
func NewHardwareResourceVerificationModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) HardwareResourceVerificationModel {
	return &customHardwareResourceVerificationModel{
		defaultHardwareResourceVerificationModel: newHardwareResourceVerificationModel(conn, c, opts...),
	}
}

// InsertVerification 插入硬件资源验证记录
func (m *customHardwareResourceVerificationModel) InsertVerification(data *HardwareResourceVerification) (sql.Result, error) {
	query := `INSERT INTO hardware_resource_verification 
		(task_id, host_ip, resource_type, target_percent, duration, script_params, execution_status) 
		VALUES (?, ?, ?, ?, ?, ?, ?)`
	return m.conn.Exec(query, data.TaskId, data.HostIp, data.ResourceType, data.TargetPercent, 
		data.Duration, data.ScriptParams, data.ExecutionStatus)
}

// FindByTaskId 根据任务ID查询验证记录
func (m *customHardwareResourceVerificationModel) FindByTaskId(taskId string) ([]*HardwareResourceVerification, error) {
	query := `SELECT id, created_at, updated_at, deleted_at, task_id, host_ip, resource_type, 
		target_percent, duration, script_params, execution_status, start_time, end_time, 
		exit_code, stdout_log, stderr_log, result_summary, ssh_error 
		FROM hardware_resource_verification 
		WHERE task_id = ? AND deleted_at IS NULL 
		ORDER BY created_at DESC`
	
	var resp []*HardwareResourceVerification
	err := m.conn.QueryRows(&resp, query, taskId)
	return resp, err
}

// FindByHostIp 根据主机IP查询历史记录
func (m *customHardwareResourceVerificationModel) FindByHostIp(hostIp string, resourceType string, limit int32) ([]*HardwareResourceVerification, error) {
	var args []interface{}
	var conditions []string
	
	conditions = append(conditions, "host_ip = ?")
	args = append(args, hostIp)
	
	if resourceType != "" {
		conditions = append(conditions, "resource_type = ?")
		args = append(args, resourceType)
	}
	
	conditions = append(conditions, "deleted_at IS NULL")
	
	limitClause := ""
	if limit > 0 {
		limitClause = fmt.Sprintf(" LIMIT %d", limit)
	} else {
		limitClause = " LIMIT 50" // 默认限制50条
	}
	
	query := fmt.Sprintf(`SELECT id, created_at, updated_at, deleted_at, task_id, host_ip, resource_type, 
		target_percent, duration, script_params, execution_status, start_time, end_time, 
		exit_code, stdout_log, stderr_log, result_summary, ssh_error 
		FROM hardware_resource_verification 
		WHERE %s 
		ORDER BY created_at DESC%s`, strings.Join(conditions, " AND "), limitClause)
	
	var resp []*HardwareResourceVerification
	err := m.conn.QueryRows(&resp, query, args...)
	return resp, err
}

// FindByHostIpList 根据主机IP列表查询最新状态
func (m *customHardwareResourceVerificationModel) FindByHostIpList(hostIpList []string, resourceType string) ([]*HardwareResourceVerification, error) {
	if len(hostIpList) == 0 {
		// 如果没有指定IP列表，返回所有记录的最新状态
		var conditions []string
		var args []interface{}
		
		if resourceType != "" {
			conditions = append(conditions, "resource_type = ?")
			args = append(args, resourceType)
		}
		
		conditions = append(conditions, "deleted_at IS NULL")
		
		whereClause := ""
		if len(conditions) > 0 {
			whereClause = "WHERE " + strings.Join(conditions, " AND ")
		}
		
		query := fmt.Sprintf(`SELECT v1.id, v1.created_at, v1.updated_at, v1.deleted_at, v1.task_id, 
			v1.host_ip, v1.resource_type, v1.target_percent, v1.duration, v1.script_params, 
			v1.execution_status, v1.start_time, v1.end_time, v1.exit_code, v1.stdout_log, 
			v1.stderr_log, v1.result_summary, v1.ssh_error 
			FROM hardware_resource_verification v1
			INNER JOIN (
				SELECT host_ip, resource_type, MAX(created_at) as max_created_at
				FROM hardware_resource_verification 
				%s
				GROUP BY host_ip, resource_type
			) v2 ON v1.host_ip = v2.host_ip AND v1.resource_type = v2.resource_type 
			AND v1.created_at = v2.max_created_at
			ORDER BY v1.created_at DESC`, whereClause)
		
		var resp []*HardwareResourceVerification
		err := m.conn.QueryRows(&resp, query, args...)
		return resp, err
	}
	
	// 构建IN子句的占位符
	placeholders := make([]string, len(hostIpList))
	args := make([]interface{}, 0, len(hostIpList)+1)
	
	for i, ip := range hostIpList {
		placeholders[i] = "?"
		args = append(args, ip)
	}
	
	var conditions []string
	conditions = append(conditions, fmt.Sprintf("host_ip IN (%s)", strings.Join(placeholders, ",")))
	
	if resourceType != "" {
		conditions = append(conditions, "resource_type = ?")
		args = append(args, resourceType)
	}
	
	conditions = append(conditions, "deleted_at IS NULL")
	
	query := fmt.Sprintf(`SELECT v1.id, v1.created_at, v1.updated_at, v1.deleted_at, v1.task_id, 
		v1.host_ip, v1.resource_type, v1.target_percent, v1.duration, v1.script_params, 
		v1.execution_status, v1.start_time, v1.end_time, v1.exit_code, v1.stdout_log, 
		v1.stderr_log, v1.result_summary, v1.ssh_error 
		FROM hardware_resource_verification v1
		INNER JOIN (
			SELECT host_ip, resource_type, MAX(created_at) as max_created_at
			FROM hardware_resource_verification 
			WHERE %s
			GROUP BY host_ip, resource_type
		) v2 ON v1.host_ip = v2.host_ip AND v1.resource_type = v2.resource_type 
		AND v1.created_at = v2.max_created_at
		ORDER BY v1.created_at DESC`, strings.Join(conditions, " AND "))
	
	var resp []*HardwareResourceVerification
	err := m.conn.QueryRows(&resp, query, args...)
	return resp, err
}

// UpdateVerificationStatus 更新验证状态
func (m *customHardwareResourceVerificationModel) UpdateVerificationStatus(id int64, status, startTime, endTime string, 
	exitCode sql.NullInt64, stdoutLog, stderrLog, resultSummary, sshError sql.NullString) error {
	
	// 处理endTime为空字符串的情况，转换为NULL
	var endTimeVal sql.NullString
	if endTime != "" {
		endTimeVal = sql.NullString{String: endTime, Valid: true}
	} else {
		endTimeVal = sql.NullString{Valid: false}
	}
	
	// 处理startTime为空字符串的情况，转换为NULL
	var startTimeVal sql.NullString
	if startTime != "" {
		startTimeVal = sql.NullString{String: startTime, Valid: true}
	} else {
		startTimeVal = sql.NullString{Valid: false}
	}
	
	query := `UPDATE hardware_resource_verification 
		SET execution_status = ?, start_time = ?, end_time = ?, exit_code = ?, 
		stdout_log = ?, stderr_log = ?, result_summary = ?, ssh_error = ?, 
		updated_at = CURRENT_TIMESTAMP 
		WHERE id = ?`
	_, err := m.conn.Exec(query, status, startTimeVal, endTimeVal, exitCode, stdoutLog, stderrLog, resultSummary, sshError, id)
	return err
}

// 以下是生成的默认模型代码的占位符实现
type hardwareResourceVerificationModel interface {
	// 这里会由goctl model工具生成基本的CRUD方法
}

type defaultHardwareResourceVerificationModel struct {
	conn  sqlx.SqlConn
	cache cache.CacheConf
}

func newHardwareResourceVerificationModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) *defaultHardwareResourceVerificationModel {
	return &defaultHardwareResourceVerificationModel{
		conn:  conn,
		cache: c,
	}
}