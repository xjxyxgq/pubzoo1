package model

import (
	"context"
	"fmt"

	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ ClusterGroupsModel = (*customClusterGroupsModel)(nil)

type (
	// ClusterGroupsModel is an interface to be customized, add more methods here,
	// and implement the added methods in customClusterGroupsModel.
	ClusterGroupsModel interface {
		clusterGroupsModel
		FindByClusterName(ctx context.Context, clusterName string) (*ClusterGroups, error)
	}

	customClusterGroupsModel struct {
		*defaultClusterGroupsModel
	}
)

// NewClusterGroupsModel returns a model for the database table.
func NewClusterGroupsModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) ClusterGroupsModel {
	return &customClusterGroupsModel{
		defaultClusterGroupsModel: newClusterGroupsModel(conn, c, opts...),
	}
}

// FindByClusterName 根据集群名称查找集群组信息
func (m *customClusterGroupsModel) FindByClusterName(ctx context.Context, clusterName string) (*ClusterGroups, error) {
	var resp ClusterGroups
	query := fmt.Sprintf("select %s from %s where `cluster_name` = ? limit 1", clusterGroupsRows, m.table)
	err := m.QueryRowNoCacheCtx(ctx, &resp, query, clusterName)
	switch err {
	case nil:
		return &resp, nil
	case sqlx.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
