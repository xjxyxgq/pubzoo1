package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ TidbClusterInstanceModel = (*customTidbClusterInstanceModel)(nil)

type (
	// TidbClusterInstanceModel is an interface to be customized, add more methods here,
	// and implement the added methods in customTidbClusterInstanceModel.
	TidbClusterInstanceModel interface {
		tidbClusterInstanceModel
	}

	customTidbClusterInstanceModel struct {
		*defaultTidbClusterInstanceModel
	}
)

// NewTidbClusterInstanceModel returns a model for the database table.
func NewTidbClusterInstanceModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) TidbClusterInstanceModel {
	return &customTidbClusterInstanceModel{
		defaultTidbClusterInstanceModel: newTidbClusterInstanceModel(conn, c, opts...),
	}
}
