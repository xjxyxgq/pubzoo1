package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ MysqlClusterInstanceModel = (*customMysqlClusterInstanceModel)(nil)

type (
	// MysqlClusterInstanceModel is an interface to be customized, add more methods here,
	// and implement the added methods in customMysqlClusterInstanceModel.
	MysqlClusterInstanceModel interface {
		mysqlClusterInstanceModel
	}

	customMysqlClusterInstanceModel struct {
		*defaultMysqlClusterInstanceModel
	}
)

// NewMysqlClusterInstanceModel returns a model for the database table.
func NewMysqlClusterInstanceModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) MysqlClusterInstanceModel {
	return &customMysqlClusterInstanceModel{
		defaultMysqlClusterInstanceModel: newMysqlClusterInstanceModel(conn, c, opts...),
	}
}
