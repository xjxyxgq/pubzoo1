package model

import (
	"context"
	"fmt"

	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ HostsApplicationsModel = (*customHostsApplicationsModel)(nil)

type (
	// HostsApplicationsModel is an interface to be customized, add more methods here,
	// and implement the added methods in customHostsApplicationsModel.
	HostsApplicationsModel interface {
		hostsApplicationsModel
		FindByPoolId(ctx context.Context, poolId uint64) ([]*HostsApplications, error)
	}

	customHostsApplicationsModel struct {
		*defaultHostsApplicationsModel
	}
)

// NewHostsApplicationsModel returns a model for the database table.
func NewHostsApplicationsModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) HostsApplicationsModel {
	return &customHostsApplicationsModel{
		defaultHostsApplicationsModel: newHostsApplicationsModel(conn, c, opts...),
	}
}

// FindByPoolId 根据主机池ID查找关联的应用
func (m *customHostsApplicationsModel) FindByPoolId(ctx context.Context, poolId uint64) ([]*HostsApplications, error) {
	var resp []*HostsApplications
	query := fmt.Sprintf("select %s from %s where `pool_id` = ?", hostsApplicationsRows, m.table)
	err := m.QueryRowsNoCacheCtx(ctx, &resp, query, poolId)
	return resp, err
}
