package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ ServerResourcesModel = (*customServerResourcesModel)(nil)

type (
	// ServerResourcesModel is an interface to be customized, add more methods here,
	// and implement the added methods in customServerResourcesModel.
	ServerResourcesModel interface {
		serverResourcesModel
	}

	customServerResourcesModel struct {
		*defaultServerResourcesModel
	}
)

// NewServerResourcesModel returns a model for the database table.
func NewServerResourcesModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) ServerResourcesModel {
	return &customServerResourcesModel{
		defaultServerResourcesModel: newServerResourcesModel(conn, c, opts...),
	}
}
