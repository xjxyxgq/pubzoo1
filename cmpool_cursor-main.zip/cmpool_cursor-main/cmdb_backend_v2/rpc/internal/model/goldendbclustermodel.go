package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ GoldendbClusterModel = (*customGoldendbClusterModel)(nil)

type (
	// GoldendbClusterModel is an interface to be customized, add more methods here,
	// and implement the added methods in customGoldendbClusterModel.
	GoldendbClusterModel interface {
		goldendbClusterModel
	}

	customGoldendbClusterModel struct {
		*defaultGoldendbClusterModel
	}
)

// NewGoldendbClusterModel returns a model for the database table.
func NewGoldendbClusterModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) GoldendbClusterModel {
	return &customGoldendbClusterModel{
		defaultGoldendbClusterModel: newGoldendbClusterModel(conn, c, opts...),
	}
}
