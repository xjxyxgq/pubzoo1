package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ TidbClusterModel = (*customTidbClusterModel)(nil)

type (
	// TidbClusterModel is an interface to be customized, add more methods here,
	// and implement the added methods in customTidbClusterModel.
	TidbClusterModel interface {
		tidbClusterModel
	}

	customTidbClusterModel struct {
		*defaultTidbClusterModel
	}
)

// NewTidbClusterModel returns a model for the database table.
func NewTidbClusterModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) TidbClusterModel {
	return &customTidbClusterModel{
		defaultTidbClusterModel: newTidbClusterModel(conn, c, opts...),
	}
}
