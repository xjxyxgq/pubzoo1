package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ MssqlClusterInstanceModel = (*customMssqlClusterInstanceModel)(nil)

type (
	// MssqlClusterInstanceModel is an interface to be customized, add more methods here,
	// and implement the added methods in customMssqlClusterInstanceModel.
	MssqlClusterInstanceModel interface {
		mssqlClusterInstanceModel
	}

	customMssqlClusterInstanceModel struct {
		*defaultMssqlClusterInstanceModel
	}
)

// NewMssqlClusterInstanceModel returns a model for the database table.
func NewMssqlClusterInstanceModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) MssqlClusterInstanceModel {
	return &customMssqlClusterInstanceModel{
		defaultMssqlClusterInstanceModel: newMssqlClusterInstanceModel(conn, c, opts...),
	}
}
