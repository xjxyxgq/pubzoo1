package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ DbLineModel = (*customDbLineModel)(nil)

type (
	// DbLineModel is an interface to be customized, add more methods here,
	// and implement the added methods in customDbLineModel.
	DbLineModel interface {
		dbLineModel
	}

	customDbLineModel struct {
		*defaultDbLineModel
	}
)

// NewDbLineModel returns a model for the database table.
func NewDbLineModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) DbLineModel {
	return &customDbLineModel{
		defaultDbLineModel: newDbLineModel(conn, c, opts...),
	}
}
