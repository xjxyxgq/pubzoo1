package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ MssqlClusterModel = (*customMssqlClusterModel)(nil)

type (
	// MssqlClusterModel is an interface to be customized, add more methods here,
	// and implement the added methods in customMssqlClusterModel.
	MssqlClusterModel interface {
		mssqlClusterModel
	}

	customMssqlClusterModel struct {
		*defaultMssqlClusterModel
	}
)

// NewMssqlClusterModel returns a model for the database table.
func NewMssqlClusterModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) MssqlClusterModel {
	return &customMssqlClusterModel{
		defaultMssqlClusterModel: newMssqlClusterModel(conn, c, opts...),
	}
}
