package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ ResourceUsageDataModel = (*customResourceUsageDataModel)(nil)

type (
	// ResourceUsageDataModel is an interface to be customized, add more methods here,
	// and implement the added methods in customResourceUsageDataModel.
	ResourceUsageDataModel interface {
		resourceUsageDataModel
	}

	customResourceUsageDataModel struct {
		*defaultResourceUsageDataModel
	}
)

// NewResourceUsageDataModel returns a model for the database table.
func NewResourceUsageDataModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) ResourceUsageDataModel {
	return &customResourceUsageDataModel{
		defaultResourceUsageDataModel: newResourceUsageDataModel(conn, c, opts...),
	}
}
