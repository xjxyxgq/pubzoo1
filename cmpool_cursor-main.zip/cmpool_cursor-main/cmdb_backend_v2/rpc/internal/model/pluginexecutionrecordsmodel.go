package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ PluginExecutionRecordsModel = (*customPluginExecutionRecordsModel)(nil)

type (
	// PluginExecutionRecordsModel is an interface to be customized, add more methods here,
	// and implement the added methods in customPluginExecutionRecordsModel.
	PluginExecutionRecordsModel interface {
		pluginExecutionRecordsModel
	}

	customPluginExecutionRecordsModel struct {
		*defaultPluginExecutionRecordsModel
	}
)

// NewPluginExecutionRecordsModel returns a model for the database table.
func NewPluginExecutionRecordsModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) PluginExecutionRecordsModel {
	return &customPluginExecutionRecordsModel{
		defaultPluginExecutionRecordsModel: newPluginExecutionRecordsModel(conn, c, opts...),
	}
}
