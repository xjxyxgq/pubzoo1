package model

import (
	"github.com/zeromicro/go-zero/core/stores/cache"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
)

var _ GoldendbClusterInstanceModel = (*customGoldendbClusterInstanceModel)(nil)

type (
	// GoldendbClusterInstanceModel is an interface to be customized, add more methods here,
	// and implement the added methods in customGoldendbClusterInstanceModel.
	GoldendbClusterInstanceModel interface {
		goldendbClusterInstanceModel
	}

	customGoldendbClusterInstanceModel struct {
		*defaultGoldendbClusterInstanceModel
	}
)

// NewGoldendbClusterInstanceModel returns a model for the database table.
func NewGoldendbClusterInstanceModel(conn sqlx.SqlConn, c cache.CacheConf, opts ...cache.Option) GoldendbClusterInstanceModel {
	return &customGoldendbClusterInstanceModel{
		defaultGoldendbClusterInstanceModel: newGoldendbClusterInstanceModel(conn, c, opts...),
	}
}
