package logic

import (
	"context"
	"database/sql"
	"fmt"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetClusterGroupsLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetClusterGroupsLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetClusterGroupsLogic {
	return &GetClusterGroupsLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// ClusterGroupRow 用于接收数据库查询结果
type ClusterGroupRow struct {
	Id                 int64          `db:"id"`
	CreatedAt          string         `db:"created_at"`
	UpdatedAt          string         `db:"updated_at"`
	GroupName          sql.NullString `db:"group_name"`
	ClusterType        sql.NullString `db:"cluster_type"`
	ClusterName        sql.NullString `db:"cluster_name"`
	DepartmentLineName sql.NullString `db:"department_line_name"`
}

// 查询所有集群组及对应业务线
func (l *GetClusterGroupsLogic) GetClusterGroups(in *cmpool.ClusterGroupsReq) (*cmpool.ClusterGroupsResp, error) {
	l.Logger.Info("查询集群组信息")

	// 从数据库查询集群组数据
	clusterGroups, err := l.getClusterGroupsFromDB()
	if err != nil {
		l.Logger.Errorf("查询集群组失败: %v", err)
		return &cmpool.ClusterGroupsResp{
			Success: false,
			Message: fmt.Sprintf("查询集群组失败: %v", err),
		}, nil
	}

	l.Logger.Infof("查询到%d个集群组", len(clusterGroups))
	return &cmpool.ClusterGroupsResp{
		Success:      true,
		Message:      "查询成功",
		ClusterGroup: clusterGroups,
	}, nil
}

// getClusterGroupsFromDB 从数据库查询集群组数据
func (l *GetClusterGroupsLogic) getClusterGroupsFromDB() ([]*cmpool.ClusterGroup, error) {
	// 查询所有有效的集群组
	query := `SELECT id, created_at, updated_at, group_name, cluster_type, cluster_name, department_line_name 
			  FROM cluster_groups 
			  WHERE deleted_at IS NULL 
			  ORDER BY id`

	var rows []ClusterGroupRow
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &rows, query)
	if err != nil {
		return nil, fmt.Errorf("执行查询失败: %w", err)
	}

	// 将数据库结果转换为protobuf结构
	var clusterGroups []*cmpool.ClusterGroup
	for _, row := range rows {
		// 处理 NULL 值，设置默认值为 "未知"
		groupName := "未知"
		if row.GroupName.Valid {
			groupName = row.GroupName.String
		}
		
		clusterName := "未知"
		if row.ClusterName.Valid {
			clusterName = row.ClusterName.String
		}
		
		departmentName := "未知"
		if row.DepartmentLineName.Valid {
			departmentName = row.DepartmentLineName.String
		}
		
		group := &cmpool.ClusterGroup{
			Id:             row.Id,
			CreateAt:       row.CreatedAt,
			UpdateAt:       row.UpdatedAt,
			GroupName:      groupName,
			ClusterName:    clusterName,
			DepartmentName: departmentName,
		}
		clusterGroups = append(clusterGroups, group)
	}

	return clusterGroups, nil
}
