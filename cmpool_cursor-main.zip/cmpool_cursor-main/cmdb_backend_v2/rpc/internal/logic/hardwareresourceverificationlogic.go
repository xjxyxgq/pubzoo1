package logic

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/model"
	"cmdb-rpc/internal/svc"

	"github.com/google/uuid"
	"github.com/zeromicro/go-zero/core/logx"
)

type HardwareResourceVerificationLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewHardwareResourceVerificationLogic(ctx context.Context, svcCtx *svc.ServiceContext) *HardwareResourceVerificationLogic {
	return &HardwareResourceVerificationLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 硬件资源验证
func (l *HardwareResourceVerificationLogic) HardwareResourceVerification(in *cmpool.HardwareResourceVerificationReq) (*cmpool.HardwareResourceVerificationResp, error) {
	// 生成唯一任务ID
	taskId := uuid.New().String()

	// 验证参数
	if len(in.HostIpList) == 0 {
		return &cmpool.HardwareResourceVerificationResp{
			Success: false,
			Message: "主机IP列表不能为空",
		}, nil
	}

	if in.ResourceType == "" {
		return &cmpool.HardwareResourceVerificationResp{
			Success: false,
			Message: "资源类型不能为空",
		}, nil
	}

	if in.ResourceType != "cpu" && in.ResourceType != "memory" && in.ResourceType != "disk" {
		return &cmpool.HardwareResourceVerificationResp{
			Success: false,
			Message: "资源类型必须是 cpu、memory 或 disk",
		}, nil
	}

	if in.TargetPercent <= 0 || in.TargetPercent > 100 {
		return &cmpool.HardwareResourceVerificationResp{
			Success: false,
			Message: "目标百分比必须在1-100之间",
		}, nil
	}

	duration := in.Duration
	if duration <= 0 {
		duration = 300 // 默认5分钟
	}

	// 批量插入数据库记录
	for _, hostIp := range in.HostIpList {
		verification := &model.HardwareResourceVerification{
			TaskId:          taskId,
			HostIp:          hostIp,
			ResourceType:    in.ResourceType,
			TargetPercent:   in.TargetPercent,
			Duration:        duration,
			ScriptParams:    sql.NullString{String: in.ScriptParams, Valid: in.ScriptParams != ""},
			ExecutionStatus: "pending",
		}

		_, err := l.svcCtx.HardwareResourceVerificationModel.InsertVerification(verification)
		if err != nil {
			l.Errorf("插入验证记录失败: %v", err)
			continue
		}
	}

	// 启动异步执行
	go l.executeVerificationTask(taskId, in.HostIpList, in.ResourceType, in.TargetPercent, duration, in.ScriptParams)

	return &cmpool.HardwareResourceVerificationResp{
		Success: true,
		Message: fmt.Sprintf("硬件资源验证任务已创建，任务ID: %s", taskId),
		TaskId:  taskId,
	}, nil
}

// executeVerificationTask 执行验证任务
func (l *HardwareResourceVerificationLogic) executeVerificationTask(taskId string, hostIpList []string, resourceType string, targetPercent, duration int32, scriptParams string) {
	var wg sync.WaitGroup

	// 并发执行验证，但限制并发数量
	semaphore := make(chan struct{}, 5) // 最多同时执行5个

	for _, hostIp := range hostIpList {
		wg.Add(1)
		go func(ip string) {
			defer wg.Done()
			semaphore <- struct{}{}        // 获取信号量
			defer func() { <-semaphore }() // 释放信号量

			l.executeHostVerification(taskId, ip, resourceType, targetPercent, duration, scriptParams)
		}(hostIp)
	}

	wg.Wait()
	l.Infof("任务 %s 的所有验证已完成", taskId)
}

// executeHostVerification 执行单个主机的验证
func (l *HardwareResourceVerificationLogic) executeHostVerification(taskId, hostIp, resourceType string, targetPercent, duration int32, scriptParams string) {
	// 查找对应的数据库记录
	records, err := l.svcCtx.HardwareResourceVerificationModel.FindByTaskId(taskId)
	if err != nil {
		l.Errorf("查找验证记录失败: %v", err)
		return
	}

	var record *model.HardwareResourceVerification
	for _, r := range records {
		if r.HostIp == hostIp && r.ResourceType == resourceType {
			record = r
			break
		}
	}

	if record == nil {
		l.Errorf("未找到主机 %s 的验证记录", hostIp)
		return
	}

	startTime := time.Now().Format("2006-01-02 15:04:05")

	// 更新状态为running
	err = l.svcCtx.HardwareResourceVerificationModel.UpdateVerificationStatus(
		record.Id, "running", startTime, "", sql.NullInt64{},
		sql.NullString{}, sql.NullString{}, sql.NullString{}, sql.NullString{})
	if err != nil {
		l.Errorf("更新验证状态失败: %v", err)
		return
	}

	// 执行SSH命令
	exitCode, stdout, stderr, sshError := l.executeSSHCommand(hostIp, resourceType, targetPercent, duration, scriptParams)

	endTime := time.Now().Format("2006-01-02 15:04:05")
	executionStatus := "completed"
	if exitCode != 0 || sshError != "" {
		executionStatus = "failed"
	}

	// 解析结果摘要
	resultSummary := l.parseResultSummary(stdout, stderr, exitCode)

	// 更新最终状态
	err = l.svcCtx.HardwareResourceVerificationModel.UpdateVerificationStatus(
		record.Id, executionStatus, startTime, endTime,
		sql.NullInt64{Int64: int64(exitCode), Valid: true},
		sql.NullString{String: stdout, Valid: true},
		sql.NullString{String: stderr, Valid: true},
		sql.NullString{String: resultSummary, Valid: true},
		sql.NullString{String: sshError, Valid: sshError != ""})

	if err != nil {
		l.Errorf("更新最终验证状态失败: %v", err)
	}

	l.Infof("主机 %s 的 %s 资源验证已完成，状态: %s", hostIp, resourceType, executionStatus)
}

// executeSSHCommand 执行SSH命令
func (l *HardwareResourceVerificationLogic) executeSSHCommand(hostIp, resourceType string, targetPercent, duration int32, scriptParams string) (int, string, string, string) {
	// 确定脚本名称
	var scriptName string
	switch resourceType {
	case "cpu":
		scriptName = "cpu_load_limit.sh"
	case "memory":
		scriptName = "memory_usage_limit.sh"
	case "disk":
		scriptName = "disk_usage_limit.sh"
	default:
		return -1, "", fmt.Sprintf("不支持的资源类型: %s", resourceType), "参数错误"
	}

	// 从配置文件获取脚本路径
	scriptBasePath := l.svcCtx.Config.HardwareVerification.ScriptBasePath
	if scriptBasePath == "" {
		scriptBasePath = "/tmp/scripts" // 默认路径
	}
	localScriptPath := filepath.Join(scriptBasePath, scriptName)
	remoteScriptPath := fmt.Sprintf("/tmp/%s", scriptName)

	// 获取远程用户配置
	remoteUser := l.svcCtx.Config.HardwareVerification.RemoteUser
	if remoteUser == "" {
		remoteUser = "root" // 默认用户
	}

	// 构建SSH目标地址
	sshTarget := fmt.Sprintf("%s@%s", remoteUser, hostIp)

	// 1. 复制脚本到远程主机
	scpCmd := exec.Command("scp", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
		localScriptPath, fmt.Sprintf("%s:%s", sshTarget, remoteScriptPath))
	scpOutput, scpErr := scpCmd.CombinedOutput()
	if scpErr != nil {
		sshError := fmt.Sprintf("SCP复制脚本失败: %v, 输出: %s", scpErr, string(scpOutput))
		return -1, "", string(scpOutput), sshError
	}

	// 2. 设置脚本执行权限
	chmodCmd := exec.Command("ssh", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
		sshTarget, fmt.Sprintf("chmod +x %s", remoteScriptPath))
	chmodOutput, chmodErr := chmodCmd.CombinedOutput()
	if chmodErr != nil {
		sshError := fmt.Sprintf("设置脚本权限失败: %v, 输出: %s", chmodErr, string(chmodOutput))
		return -1, "", string(chmodOutput), sshError
	}

	// 3. 构建执行命令
	var cmdArgs []string
	switch resourceType {
	case "cpu":
		cmdArgs = []string{fmt.Sprintf("%d", targetPercent), fmt.Sprintf("%d", duration), "auto", "19"}
	case "memory":
		cmdArgs = []string{fmt.Sprintf("%d", targetPercent), fmt.Sprintf("%d", duration), "19"}
	case "disk":
		cmdArgs = []string{fmt.Sprintf("%d", targetPercent), fmt.Sprintf("%d", duration), "/tmp", "19"}
	}

	// 解析额外参数
	if scriptParams != "" {
		var params map[string]interface{}
		if err := json.Unmarshal([]byte(scriptParams), &params); err == nil {
			// 根据参数覆盖默认值
			if val, ok := params["nice_level"]; ok {
				if strVal, ok := val.(string); ok && len(cmdArgs) > 3 {
					cmdArgs[3] = strVal
				}
			}
			// 可以根据需要添加更多参数处理
		}
	}

	// 根据配置决定是否使用sudo
	useSudo := l.svcCtx.Config.HardwareVerification.UseSudo
	var execCommand string
	if useSudo {
		// 使用sudo -n (non-interactive)避免密码提示，要求配置NOPASSWD
		execCommand = fmt.Sprintf("sudo -n %s %s", remoteScriptPath, strings.Join(cmdArgs, " "))
	} else {
		execCommand = fmt.Sprintf("%s %s", remoteScriptPath, strings.Join(cmdArgs, " "))
	}

	// 4. 执行脚本
	sshCmd := exec.Command("ssh", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
		sshTarget, execCommand)
	output, err := sshCmd.CombinedOutput()

	exitCode := 0
	if err != nil {
		if exitError, ok := err.(*exec.ExitError); ok {
			exitCode = exitError.ExitCode()
		} else {
			// SSH连接错误
			sshError := fmt.Sprintf("SSH连接失败: %v", err)
			return -1, "", string(output), sshError
		}
	}

	// 5. 清理远程脚本
	cleanupCmd := exec.Command("ssh", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
		sshTarget, fmt.Sprintf("rm -f %s", remoteScriptPath))
	cleanupCmd.Run() // 忽略清理错误

	// 分离标准输出和标准错误（这里简化处理，实际可能需要更复杂的解析）
	outputStr := string(output)
	stdout := outputStr
	stderr := ""

	if exitCode != 0 {
		// 如果有错误，将输出作为stderr
		stderr = outputStr
		stdout = ""
	}

	return exitCode, stdout, stderr, ""
}

// parseResultSummary 解析执行结果摘要
func (l *HardwareResourceVerificationLogic) parseResultSummary(stdout, stderr string, exitCode int) string {
	summary := map[string]interface{}{
		"exit_code": exitCode,
		"success":   exitCode == 0,
		"timestamp": time.Now().Format("2006-01-02 15:04:05"),
	}

	// 尝试从输出中提取关键信息
	if exitCode == 0 && stdout != "" {
		// 解析成功的执行结果
		lines := strings.Split(stdout, "\n")
		for _, line := range lines {
			if strings.Contains(line, "已达标") {
				summary["target_achieved"] = true
			}
			if strings.Contains(line, "压测成功完成") || strings.Contains(line, "程序成功完成") {
				summary["test_completed"] = true
			}
		}
	}

	if stderr != "" {
		summary["has_error"] = true
		summary["error_summary"] = stderr[:min(200, len(stderr))] // 截取前200字符作为错误摘要
	}

	jsonBytes, _ := json.Marshal(summary)
	return string(jsonBytes)
}

// min 辅助函数
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
