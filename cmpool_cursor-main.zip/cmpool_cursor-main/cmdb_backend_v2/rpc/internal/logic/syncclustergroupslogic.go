package logic

import (
	"context"
	"fmt"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

// ClusterInfo 集群信息结构体
type ClusterInfo struct {
	ClusterName      string `db:"cluster_name"`
	ClusterGroupName string `db:"cluster_group_name"`
}

type SyncClusterGroupsLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewSyncClusterGroupsLogic(ctx context.Context, svcCtx *svc.ServiceContext) *SyncClusterGroupsLogic {
	return &SyncClusterGroupsLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 同步集群组数据
func (l *SyncClusterGroupsLogic) SyncClusterGroups(in *cmpool.SyncClusterGroupsReq) (*cmpool.SyncClusterGroupsResp, error) {
	l.Logger.Info("开始同步集群组数据")

	var details []*cmpool.DatabaseSyncDetail
	totalSyncedCount := 0

	// 1. 同步MySQL集群数据
	mysqlDetail, err := l.syncMysqlClusters()
	if err != nil {
		l.Logger.Errorf("同步MySQL集群失败: %v", err)
		return &cmpool.SyncClusterGroupsResp{
			Success:     false,
			Message:     fmt.Sprintf("同步MySQL集群失败: %v", err),
			SyncedCount: int32(totalSyncedCount),
			Details:     details,
		}, nil
	}
	details = append(details, mysqlDetail)
	totalSyncedCount += int(mysqlDetail.SyncedCount)

	// 2. 同步MSSQL集群数据
	mssqlDetail, err := l.syncMssqlClusters()
	if err != nil {
		l.Logger.Errorf("同步MSSQL集群失败: %v", err)
		return &cmpool.SyncClusterGroupsResp{
			Success:     false,
			Message:     fmt.Sprintf("同步MSSQL集群失败: %v", err),
			SyncedCount: int32(totalSyncedCount),
			Details:     details,
		}, nil
	}
	details = append(details, mssqlDetail)
	totalSyncedCount += int(mssqlDetail.SyncedCount)

	// 3. 同步TiDB集群数据
	tidbDetail, err := l.syncTidbClusters()
	if err != nil {
		l.Logger.Errorf("同步TiDB集群失败: %v", err)
		return &cmpool.SyncClusterGroupsResp{
			Success:     false,
			Message:     fmt.Sprintf("同步TiDB集群失败: %v", err),
			SyncedCount: int32(totalSyncedCount),
			Details:     details,
		}, nil
	}
	details = append(details, tidbDetail)
	totalSyncedCount += int(tidbDetail.SyncedCount)

	// 4. 同步GoldenDB集群数据
	goldendbDetail, err := l.syncGoldendbClusters()
	if err != nil {
		l.Logger.Errorf("同步GoldenDB集群失败: %v", err)
		return &cmpool.SyncClusterGroupsResp{
			Success:     false,
			Message:     fmt.Sprintf("同步GoldenDB集群失败: %v", err),
			SyncedCount: int32(totalSyncedCount),
			Details:     details,
		}, nil
	}
	details = append(details, goldendbDetail)
	totalSyncedCount += int(goldendbDetail.SyncedCount)

	// 记录汇总日志
	l.Logger.Infof("集群组数据同步完成 - 总计同步: %d 个记录", totalSyncedCount)
	for _, detail := range details {
		if detail.SyncedCount > 0 {
			l.Logger.Infof("  - %s: %d 个集群组 (%v)", detail.DatabaseType, detail.SyncedCount, detail.ClusterGroups)
		}
	}

	return &cmpool.SyncClusterGroupsResp{
		Success:     true,
		Message:     fmt.Sprintf("同步成功，共同步 %d 个集群组", totalSyncedCount),
		SyncedCount: int32(totalSyncedCount),
		Details:     details,
	}, nil
}

// syncMysqlClusters 同步MySQL集群数据
func (l *SyncClusterGroupsLogic) syncMysqlClusters() (*cmpool.DatabaseSyncDetail, error) {
	// 查询MySQL集群数据
	query := `SELECT cluster_name, cluster_group_name FROM mysql_cluster WHERE deleted_at IS NULL`

	var clusters []ClusterInfo
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &clusters, query)
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "mysql",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, fmt.Errorf("查询MySQL集群失败: %w", err)
	}

	syncedCount, clusterGroups, err := l.syncClustersToGroup(clusters, "mysql")
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "mysql",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, err
	}

	l.Logger.Infof("MySQL集群同步完成: %d 个集群组 - %v", syncedCount, clusterGroups)

	return &cmpool.DatabaseSyncDetail{
		DatabaseType:  "mysql",
		SyncedCount:   int32(syncedCount),
		ClusterGroups: clusterGroups,
	}, nil
}

// syncMssqlClusters 同步MSSQL集群数据
func (l *SyncClusterGroupsLogic) syncMssqlClusters() (*cmpool.DatabaseSyncDetail, error) {
	// 查询MSSQL集群数据
	query := `SELECT cluster_name, cluster_group_name FROM mssql_cluster WHERE deleted_at IS NULL`

	var clusters []ClusterInfo
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &clusters, query)
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "mssql",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, fmt.Errorf("查询MSSQL集群失败: %w", err)
	}

	syncedCount, clusterGroups, err := l.syncClustersToGroup(clusters, "mssql")
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "mssql",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, err
	}

	l.Logger.Infof("MSSQL集群同步完成: %d 个集群组 - %v", syncedCount, clusterGroups)

	return &cmpool.DatabaseSyncDetail{
		DatabaseType:  "mssql",
		SyncedCount:   int32(syncedCount),
		ClusterGroups: clusterGroups,
	}, nil
}

// syncTidbClusters 同步TiDB集群数据
func (l *SyncClusterGroupsLogic) syncTidbClusters() (*cmpool.DatabaseSyncDetail, error) {
	// 查询TiDB集群数据
	query := `SELECT cluster_name, cluster_group_name FROM tidb_cluster WHERE deleted_at IS NULL`

	var clusters []ClusterInfo
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &clusters, query)
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "tidb",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, fmt.Errorf("查询TiDB集群失败: %w", err)
	}

	syncedCount, clusterGroups, err := l.syncClustersToGroup(clusters, "tidb")
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "tidb",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, err
	}

	l.Logger.Infof("TiDB集群同步完成: %d 个集群组 - %v", syncedCount, clusterGroups)

	return &cmpool.DatabaseSyncDetail{
		DatabaseType:  "tidb",
		SyncedCount:   int32(syncedCount),
		ClusterGroups: clusterGroups,
	}, nil
}

// syncGoldendbClusters 同步GoldenDB集群数据
func (l *SyncClusterGroupsLogic) syncGoldendbClusters() (*cmpool.DatabaseSyncDetail, error) {
	// 查询GoldenDB集群数据
	query := `SELECT cluster_name, cluster_group_name FROM goldendb_cluster WHERE deleted_at IS NULL`

	var clusters []ClusterInfo
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &clusters, query)
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "goldendb",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, fmt.Errorf("查询GoldenDB集群失败: %w", err)
	}

	syncedCount, clusterGroups, err := l.syncClustersToGroup(clusters, "goldendb")
	if err != nil {
		return &cmpool.DatabaseSyncDetail{
			DatabaseType:  "goldendb",
			SyncedCount:   0,
			ClusterGroups: []string{},
		}, err
	}

	l.Logger.Infof("GoldenDB集群同步完成: %d 个集群组 - %v", syncedCount, clusterGroups)

	return &cmpool.DatabaseSyncDetail{
		DatabaseType:  "goldendb",
		SyncedCount:   int32(syncedCount),
		ClusterGroups: clusterGroups,
	}, nil
}

// syncClustersToGroup 将集群数据同步到cluster_groups表
func (l *SyncClusterGroupsLogic) syncClustersToGroup(clusters []ClusterInfo, clusterType string) (int, []string, error) {
	clusterSlice := clusters

	syncedCount := 0
	var clusterGroups []string
	groupsMap := make(map[string]bool) // 用于去重

	for _, cluster := range clusterSlice {
		// 记录详细的同步信息
		l.Logger.Infof("正在同步 %s 集群: %s -> 集群组: %s", clusterType, cluster.ClusterName, cluster.ClusterGroupName)

		// 查询department_line_name
		departmentLineName, err := l.getDepartmentByGroupName(cluster.ClusterGroupName)
		if err != nil {
			l.Logger.Errorf("获取部门信息失败，集群组: %s, 错误: %v", cluster.ClusterGroupName, err)
			continue
		}

		// 检查记录是否已存在
		exists, err := l.checkClusterGroupExists(cluster.ClusterGroupName, cluster.ClusterName, clusterType)
		if err != nil {
			l.Logger.Errorf("检查集群组记录失败: %v", err)
			continue
		}

		if exists {
			// 更新记录
			err = l.updateClusterGroup(cluster.ClusterGroupName, clusterType, cluster.ClusterName, departmentLineName)
			if err != nil {
				l.Logger.Errorf("更新集群组记录失败: %v", err)
				continue
			}
			l.Logger.Infof("更新集群组记录: %s (%s), 集群名: %s", cluster.ClusterGroupName, clusterType, cluster.ClusterName)
		} else {
			// 插入新记录
			err = l.insertClusterGroup(cluster.ClusterGroupName, clusterType, cluster.ClusterName, departmentLineName)
			if err != nil {
				l.Logger.Errorf("插入集群组记录失败: %v", err)
				continue
			}
			l.Logger.Infof("新增集群组记录: %s (%s), 集群名: %s", cluster.ClusterGroupName, clusterType, cluster.ClusterName)
		}

		syncedCount++

		// 添加到集群组列表（去重）
		if !groupsMap[cluster.ClusterGroupName] {
			clusterGroups = append(clusterGroups, cluster.ClusterGroupName)
			groupsMap[cluster.ClusterGroupName] = true
		}
	}

	return syncedCount, clusterGroups, nil
}

// getDepartmentByGroupName 根据集群组名获取部门名称
func (l *SyncClusterGroupsLogic) getDepartmentByGroupName(groupName string) (string, error) {
	query := `SELECT department_line_name FROM db_line WHERE cluster_group_name = ? AND deleted_at IS NULL LIMIT 1`

	var departmentName string
	err := l.svcCtx.DB.QueryRowCtx(l.ctx, &departmentName, query, groupName)
	if err != nil {
		return "", fmt.Errorf("查询部门名称失败: %w", err)
	}

	return departmentName, nil
}

// checkClusterGroupExists 检查cluster_groups表中是否已存在指定记录
func (l *SyncClusterGroupsLogic) checkClusterGroupExists(groupName, clusterName, clusterType string) (bool, error) {
	query := `SELECT COUNT(*) FROM cluster_groups WHERE group_name = ? AND cluster_name = ? AND cluster_type = ? AND deleted_at IS NULL`

	var count int
	err := l.svcCtx.DB.QueryRowCtx(l.ctx, &count, query, groupName, clusterName, clusterType)
	if err != nil {
		return false, fmt.Errorf("检查记录存在性失败: %w", err)
	}

	return count > 0, nil
}

// insertClusterGroup 向cluster_groups表插入新记录
func (l *SyncClusterGroupsLogic) insertClusterGroup(groupName, clusterType, clusterName, departmentName string) error {
	insertQuery := `INSERT INTO cluster_groups (group_name, cluster_type, cluster_name, department_line_name, created_at, updated_at) 
		VALUES (?, ?, ?, ?, NOW(), NOW())`

	_, err := l.svcCtx.DB.ExecCtx(l.ctx, insertQuery, groupName, clusterType, clusterName, departmentName)
	if err != nil {
		return fmt.Errorf("插入记录失败: %w", err)
	}

	return nil
}

// updateClusterGroup 更新cluster_groups表中的记录
func (l *SyncClusterGroupsLogic) updateClusterGroup(groupName, clusterType, clusterName, departmentName string) error {
	updateQuery := `UPDATE cluster_groups SET cluster_name = ?, department_line_name = ?, updated_at = NOW() 
		WHERE group_name = ? AND cluster_name = ? AND cluster_type = ? AND deleted_at IS NULL`

	_, err := l.svcCtx.DB.ExecCtx(l.ctx, updateQuery, clusterName, departmentName, groupName, clusterName, clusterType)
	if err != nil {
		return fmt.Errorf("更新记录失败: %w", err)
	}

	return nil
}
