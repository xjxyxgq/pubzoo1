package logic

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetServerResourceLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetServerResourceLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetServerResourceLogic {
	return &GetServerResourceLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// ServerResourceRow 用于接收数据库查询结果
type ServerResourceRow struct {
	Id             int64           `db:"id"`
	CreatedAt      string          `db:"created_at"`
	UpdatedAt      string          `db:"updated_at"`
	PoolId         sql.NullInt64   `db:"pool_id"`
	ClusterName    sql.NullString  `db:"cluster_name"`
	GroupName      sql.NullString  `db:"group_name"`
	Ip             sql.NullString  `db:"ip"`
	Port           sql.NullInt32   `db:"port"`
	InstanceRole   sql.NullString  `db:"instance_role"`
	TotalMemory    sql.NullFloat64 `db:"total_memory"`
	UsedMemory     sql.NullFloat64 `db:"used_memory"`
	TotalDisk      sql.NullFloat64 `db:"total_disk"`
	UsedDisk       sql.NullFloat64 `db:"used_disk"`
	CPUCores       sql.NullInt32   `db:"cpu_cores"`
	CPULoad        sql.NullFloat64 `db:"cpu_load"`
	DateTime       string          `db:"date_time"`
	DepartmentName sql.NullString  `db:"department_name"`
}

// 查询主机资源使用率数据
func (l *GetServerResourceLogic) GetServerResource(in *cmpool.ServerResourceReq) (*cmpool.ServerResourceResp, error) {
	l.Logger.Infof("查询服务器资源数据，时间范围: %s - %s, IP列表: %v", in.BeginTime, in.EndTime, in.IpList)

	// 从数据库查询服务器资源数据
	serverResources, err := l.getServerResourcesFromDB(in)
	if err != nil {
		l.Logger.Errorf("查询服务器资源数据失败: %v", err)
		return &cmpool.ServerResourceResp{
			Success: false,
			Message: fmt.Sprintf("查询服务器资源数据失败: %v", err),
		}, nil
	}

	l.Logger.Infof("查询到%d条服务器资源数据", len(serverResources))
	return &cmpool.ServerResourceResp{
		Success:        true,
		Message:        "查询成功",
		ServerResource: serverResources,
	}, nil
}

// getServerResourcesFromDB 从数据库查询服务器资源数据
func (l *GetServerResourceLogic) getServerResourcesFromDB(req *cmpool.ServerResourceReq) ([]*cmpool.ServerResource, error) {
	// 构建基础查询语句
	query := `SELECT sr.id, sr.created_at, sr.updated_at, sr.pool_id, 
			  COALESCE(sr.cluster_name, '未分配集群') as cluster_name, 
			  COALESCE(sr.group_name, '未分配集群组') as group_name, 
			  COALESCE(sr.ip, '') as ip, 
			  sr.port, 
			  COALESCE(sr.instance_role, '') as instance_role, 
			  sr.total_memory, sr.used_memory, sr.total_disk, 
			  sr.used_disk, sr.cpu_cores, sr.cpu_load, sr.date_time,
			  COALESCE(cg.department_line_name, '无业务线归属') as department_name
			  FROM server_resources sr
			  LEFT JOIN cluster_groups cg ON sr.cluster_name = cg.cluster_name
			  WHERE sr.deleted_at IS NULL`

	args := []interface{}{}

	// 添加时间范围过滤
	if req.BeginTime != "" && req.EndTime != "" {
		query += " AND sr.date_time BETWEEN ? AND ?"
		args = append(args, req.BeginTime, req.EndTime)
	} else if req.BeginTime != "" {
		query += " AND sr.date_time >= ?"
		args = append(args, req.BeginTime)
	} else if req.EndTime != "" {
		query += " AND sr.date_time <= ?"
		args = append(args, req.EndTime)
	}

	// 添加IP过滤
	if len(req.IpList) > 0 {
		placeholders := make([]string, len(req.IpList))
		for i, ip := range req.IpList {
			placeholders[i] = "?"
			args = append(args, ip)
		}
		query += fmt.Sprintf(" AND sr.ip IN (%s)", strings.Join(placeholders, ","))
	}

	// 添加排序
	query += " ORDER BY sr.date_time DESC, sr.ip"

	l.Logger.Infof("执行查询: %s, 参数: %v", query, args)

	var rows []ServerResourceRow
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &rows, query, args...)
	if err != nil {
		return nil, fmt.Errorf("执行查询失败: %w", err)
	}

	// 将数据库结果转换为protobuf结构
	var resources []*cmpool.ServerResource
	for _, row := range rows {
		resource := &cmpool.ServerResource{
			Id:             row.Id,
			CreateAt:       row.CreatedAt,
			UpdateAt:       row.UpdatedAt,
			Datetime:       row.DateTime,
			DepartmentName: row.DepartmentName.String,
		}

		// 处理可为空的字段
		if row.PoolId.Valid {
			resource.PoolId = row.PoolId.Int64
		}
		if row.ClusterName.Valid {
			resource.ClusterName = row.ClusterName.String
		}
		if row.GroupName.Valid {
			resource.GroupName = row.GroupName.String
		}
		if row.Ip.Valid {
			resource.Ip = row.Ip.String
		}
		if row.Port.Valid {
			resource.Port = row.Port.Int32
		}
		if row.InstanceRole.Valid {
			resource.InstanceRole = row.InstanceRole.String
		}
		if row.TotalMemory.Valid {
			resource.TotalMemory = float32(row.TotalMemory.Float64)
		}
		if row.UsedMemory.Valid {
			resource.UsedMemory = float32(row.UsedMemory.Float64)
		}
		if row.TotalDisk.Valid {
			resource.TotalDisk = float32(row.TotalDisk.Float64)
		}
		if row.UsedDisk.Valid {
			resource.UsedDisk = float32(row.UsedDisk.Float64)
		}
		if row.CPUCores.Valid {
			resource.CPUCores = row.CPUCores.Int32
		}
		if row.CPULoad.Valid {
			resource.CPULoad = float32(row.CPULoad.Float64)
		}

		resources = append(resources, resource)
	}

	// 如果没有查询到数据，生成一些示例数据用于测试
	if len(resources) == 0 {
		l.Logger.Info("数据库中暂无监控数据，生成示例数据")
		resources = l.generateSampleData(req.IpList)
	}

	return resources, nil
}

// generateSampleData 生成示例监控数据
func (l *GetServerResourceLogic) generateSampleData(ipList []string) []*cmpool.ServerResource {
	if len(ipList) == 0 {
		ipList = []string{"192.168.1.10", "192.168.1.11", "192.168.1.12"}
	}

	now := time.Now()
	var resources []*cmpool.ServerResource

	for i, ip := range ipList {
		resource := &cmpool.ServerResource{
			Id:             int64(i + 1),
			CreateAt:       now.Format("2006-01-02T15:04:05Z"),
			UpdateAt:       now.Format("2006-01-02T15:04:05Z"),
			PoolId:         int64(i + 1),
			ClusterName:    "mysql-prod-cluster",
			GroupName:      "payment-mysql-group",
			Ip:             ip,
			Port:           3306,
			InstanceRole:   "master",
			TotalMemory:    64.0,
			UsedMemory:     32.5,
			TotalDisk:      500.0,
			UsedDisk:       250.2,
			CPUCores:       8,
			CPULoad:        45.6,
			Datetime:       now.Format("2006-01-02T15:04:05Z"),
			DepartmentName: "支付系统",
		}
		resources = append(resources, resource)
	}

	return resources
}
