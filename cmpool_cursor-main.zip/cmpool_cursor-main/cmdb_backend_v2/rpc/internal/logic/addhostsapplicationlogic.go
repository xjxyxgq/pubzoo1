package logic

import (
	"context"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type AddHostsApplicationLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewAddHostsApplicationLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AddHostsApplicationLogic {
	return &AddHostsApplicationLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 手动添加资源池主机应用信息
func (l *AddHostsApplicationLogic) AddHostsApplication(in *cmpool.AddHostsAppReq) (*cmpool.AddHostsAppResp, error) {
	// todo: add your logic here and delete this line

	return &cmpool.AddHostsAppResp{}, nil
}
