package logic

import (
	"context"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type ModifyHostsApplicationLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewModifyHostsApplicationLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ModifyHostsApplicationLogic {
	return &ModifyHostsApplicationLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// 手动修改资源池主机应用信息
func (l *ModifyHostsApplicationLogic) ModifyHostsApplication(in *cmpool.MdfHostsAppReq) (*cmpool.MdfHostsAppResp, error) {
	// todo: add your logic here and delete this line

	return &cmpool.MdfHostsAppResp{}, nil
}
