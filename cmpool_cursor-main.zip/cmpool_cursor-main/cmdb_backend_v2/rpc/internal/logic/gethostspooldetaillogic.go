package logic

import (
	"context"
	"fmt"
	"strings"

	"cmdb-rpc/cmpool"
	"cmdb-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetHostsPoolDetailLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetHostsPoolDetailLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetHostsPoolDetailLogic {
	return &GetHostsPoolDetailLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// HostPoolRow 用于接收主机池查询结果
type HostPoolRow struct {
	Id              int64   `db:"id"`
	HostName        string  `db:"host_name"`
	HostIp          string  `db:"host_ip"`
	HostType        *string `db:"host_type"`
	H3cId           *string `db:"h3c_id"`
	H3cStatus       *string `db:"h3c_status"`
	DiskSize        int32   `db:"disk_size"`
	Ram             int32   `db:"ram"`
	Vcpus           int32   `db:"vcpus"`
	IfH3cSync       string  `db:"if_h3c_sync"`
	H3cImgId        string  `db:"h3c_img_id"`
	H3cHmName       string  `db:"h3c_hm_name"`
	IsDelete        string  `db:"is_delete"`
	LeafNumber      string  `db:"leaf_number"`
	RackNumber      string  `db:"rack_number"`
	RackHeight      int32   `db:"rack_height"`
	RackStartNumber int32   `db:"rack_start_number"`
	FromFactor      int32   `db:"from_factor"`
	SerialNumber    string  `db:"serial_number"`
	IsDeleted       bool    `db:"is_deleted"`
	IsStatic        bool    `db:"is_static"`
	CreateTime      string  `db:"create_time"`
	UpdateTime      string  `db:"update_time"`
}

// ApplicationRow 用于接收应用查询结果
type ApplicationRow struct {
	PoolId         int64   `db:"pool_id"`
	ServerType     *string `db:"server_type"`
	ServerVersion  *string `db:"server_version"`
	ServerSubtitle *string `db:"server_subtitle"`
	ClusterName    *string `db:"cluster_name"`
	ServerProtocol *string `db:"server_protocol"`
	ServerAddr     *string `db:"server_addr"`
	ServerPort     *int32  `db:"server_port"`
	ServerRole     *string `db:"server_role"`
	ServerStatus   *string `db:"server_status"`
	DepartmentName *string `db:"department_name"`
}

// 查询主机资源池详情，包括主机的硬件信息、软件信息，接口涉及数据量较大，一般不用于页面显示，用于向外部提供全量数据或数据导出需求
func (l *GetHostsPoolDetailLogic) GetHostsPoolDetail(in *cmpool.GetHostsPoolDetailReq) (*cmpool.GetHostsPoolDetailResp, error) {
	l.Logger.Infof("查询主机池详情，IP列表: %v", in.IpList)

	// 从数据库查询主机池详细信息
	hostsPoolDetail, err := l.getHostsPoolDetailFromDB(in.IpList)
	if err != nil {
		l.Logger.Errorf("查询主机池详情失败: %v", err)
		return &cmpool.GetHostsPoolDetailResp{
			Success: false,
			Message: fmt.Sprintf("查询主机池详情失败: %v", err),
		}, nil
	}

	l.Logger.Infof("查询到%d台主机的详细信息", len(hostsPoolDetail))
	return &cmpool.GetHostsPoolDetailResp{
		Success:         true,
		Message:         "查询成功",
		HostsPoolDetail: hostsPoolDetail,
	}, nil
}

// getHostsPoolDetailFromDB 从数据库查询主机池详细信息
func (l *GetHostsPoolDetailLogic) getHostsPoolDetailFromDB(ipList []string) ([]*cmpool.HostPoolDetail, error) {
	// 构建查询主机基本信息的SQL
	hostQuery := `SELECT id, host_name, host_ip, host_type, h3c_id, h3c_status, 
				  COALESCE(disk_size, 0) as disk_size, 
				  COALESCE(ram, 0) as ram, 
				  COALESCE(vcpus, 0) as vcpus,
				  COALESCE(if_h3c_sync, '') as if_h3c_sync,
				  COALESCE(h3c_img_id, '') as h3c_img_id,
				  COALESCE(h3c_hm_name, '') as h3c_hm_name,
				  COALESCE(is_delete, '') as is_delete,
				  COALESCE(leaf_number, '') as leaf_number,
				  COALESCE(rack_number, '') as rack_number,
				  COALESCE(rack_height, 0) as rack_height,
				  COALESCE(rack_start_number, 0) as rack_start_number,
				  COALESCE(from_factor, 0) as from_factor,
				  COALESCE(serial_number, '') as serial_number,
				  is_deleted, is_static, create_time, update_time
				  FROM hosts_pool 
				  WHERE is_deleted = 0`

	args := []interface{}{}
	if len(ipList) > 0 {
		placeholders := make([]string, len(ipList))
		for i, ip := range ipList {
			placeholders[i] = "?"
			args = append(args, ip)
		}
		hostQuery += fmt.Sprintf(" AND host_ip IN (%s)", strings.Join(placeholders, ","))
	}

	hostQuery += " ORDER BY id"

	l.Logger.Infof("执行主机查询: %s, 参数: %v", hostQuery, args)

	var hostRows []HostPoolRow
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &hostRows, hostQuery, args...)
	if err != nil {
		return nil, fmt.Errorf("查询主机信息失败: %w", err)
	}

	var hostsDetail []*cmpool.HostPoolDetail
	hostIdToIpMap := make(map[int64]string) // 用于后续查询应用信息

	// 转换主机信息
	for _, row := range hostRows {
		host := &cmpool.HostPoolDetail{
			Id:              row.Id,
			Hostname:        row.HostName,
			HostIp:          row.HostIp,
			Disk:            row.DiskSize,
			Ram:             row.Ram,
			VCpu:            row.Vcpus,
			IfH3CSync:       row.IfH3cSync,
			H3CImgId:        row.H3cImgId,
			H3CHmName:       row.H3cHmName,
			IsDelete:        row.IsDelete,
			LeafNumber:      row.LeafNumber,
			RackNumber:      row.RackNumber,
			RackHeight:      row.RackHeight,
			RackStartNumber: row.RackStartNumber,
			FromFactor:      row.FromFactor,
			SerialNumber:    row.SerialNumber,
			IsDeleted:       row.IsDeleted,
			IsStatic:        row.IsStatic,
			CreateTime:      row.CreateTime,
			UpdateTime:      row.UpdateTime,
			AppList:         []*cmpool.App{}, // 初始化应用列表
		}

		// 处理可为空的字段
		if row.HostType != nil {
			host.HostType = *row.HostType
		}
		if row.H3cId != nil {
			host.H3CId = *row.H3cId
		}
		if row.H3cStatus != nil {
			host.H3CStatus = *row.H3cStatus
		}

		hostsDetail = append(hostsDetail, host)
		hostIdToIpMap[host.Id] = host.HostIp
	}

	// 查询每台主机的应用信息
	if len(hostsDetail) > 0 {
		err = l.loadApplicationsForHosts(hostsDetail, hostIdToIpMap)
		if err != nil {
			l.Logger.Errorf("加载主机应用信息失败: %v", err)
			// 不返回错误，继续返回主机基本信息
		}
	}

	return hostsDetail, nil
}

// loadApplicationsForHosts 为主机加载应用信息
func (l *GetHostsPoolDetailLogic) loadApplicationsForHosts(hostsDetail []*cmpool.HostPoolDetail, hostIdToIpMap map[int64]string) error {
	if len(hostsDetail) == 0 {
		return nil
	}

	// 构建主机ID列表
	hostIds := make([]string, 0, len(hostsDetail))
	hostDetailMap := make(map[int64]*cmpool.HostPoolDetail)

	for _, host := range hostsDetail {
		hostIds = append(hostIds, fmt.Sprintf("%d", host.Id))
		hostDetailMap[host.Id] = host
	}

	// 查询应用信息
	appQuery := `SELECT pool_id, server_type, server_version, server_subtitle, 
				 cluster_name, server_protocol, server_addr, server_port, 
				 server_role, server_status, department_name
				 FROM hosts_applications 
				 WHERE deleted_at IS NULL AND pool_id IN (` + strings.Join(hostIds, ",") + `)
				 ORDER BY pool_id, id`

	l.Logger.Infof("执行应用查询: %s", appQuery)

	var appRows []ApplicationRow
	err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &appRows, appQuery)
	if err != nil {
		return fmt.Errorf("查询应用信息失败: %w", err)
	}

	// 将应用信息添加到对应的主机中
	for _, row := range appRows {
		app := &cmpool.App{}

		// 处理可为空的字段
		if row.ServerType != nil {
			app.ServerType = *row.ServerType
		}
		if row.ServerVersion != nil {
			app.ServerVersion = *row.ServerVersion
		}
		if row.ServerSubtitle != nil {
			app.ServerSubtitle = *row.ServerSubtitle
		}
		if row.ClusterName != nil {
			app.ClusterName = *row.ClusterName
		}
		if row.ServerProtocol != nil {
			app.ServiceProtocol = *row.ServerProtocol
		}
		if row.ServerAddr != nil {
			app.ServiceAddr = *row.ServerAddr
		}
		if row.ServerRole != nil {
			app.ServiceRole = *row.ServerRole
		}
		if row.DepartmentName != nil {
			app.DepartmentName = *row.DepartmentName
		}

		// 将应用信息添加到对应的主机中
		if host, exists := hostDetailMap[row.PoolId]; exists {
			host.AppList = append(host.AppList, app)
		}
	}

	return nil
}
