cmdb_backend 是一个示例程序，现在我们需要实现一个正式发布的程序，这个正式发布的程序使用 https://github.com/zeromicro/go-zero 作为开发框架，实现所有目前 cmdb_backend 中的程序接口，提供给 cmdb_frontend_v2 前端来访问。

main.go 中有一个 generateMockData 函数，生成了一些我们期望的样例数据。

现在，我们需要从一个外部数据源里加载进来数据，并通过一些已有数据的表来加载诸如集群名称、集群组名称等内容，而外部数据的来源指的是监控指标数据：
1. 通过一个 http 接口来获取 json 格式的数据 （请实现它的大体结构，但后续再真正实现）
2. 通过加载一个 csv 文件，来加载数据（目前考虑实现的功能）

数据源的说明如下：
1. 监控指标数据的 csv 文件包含以下列：
hostIP，hostName，MaxCpu，MaxMem，MaxDisk

2. hosts_pool 的数据来源于一个外部接口，我们应当实现一个接口供前端程序调用来触发接口数据同步到这个表：
- 接口地址 /v1/host/page
- 接口请求参数先随便构造一个 json 请求体即可
- 接口返回结果是一个符合 hosts_pool 表的列结构的 json 数组
请实现这个接口的调用和数据返回的mock，不用真正实现它，返回给我一个包含100个主机的数据即可，hosts_pool 的结构，使用现有程序中的 models.go 中的 type HostPool struct 结构体

3. host_application 的数据来源于现有的数据表
- 如果主机属于mysql_cluster_instance表，则serverType 是 mysql， 关键数据列
  - cluster_name
  - ip
  - port
  - instance_role
  - version
- 如果主机属于mssql_cluster_instance表，则serverType 是 mssql，关键数据列
  - cluster_name
  - ip
  - instance_port
  - version
- 如果主机不属于上述两个表，则serverType是other或表里自定义的值

3. cluster_group 的数据来源于现有的数据表
- mysql_cluster 和 mssql_cluster 表分别记录了两种应用的集群信息，每个表中都有以下的关键字段
  - cluster_name
  - cluster_group_name
- db_line 表则记录了集群和归属业务的关系，关键字段有
  - cluster_group_name
  - department_line_name


