# CLAUDE.md

本文件为 Claude Code (claude.ai/code) 在此代码库中工作时提供指导。

**重要：请在与此项目相关的所有后续沟通中使用中文。**

## 项目概述

这是 CMDB Backend V2，一个基于 go-zero 框架构建的配置管理数据库后端服务，采用标准的 RPC + API 架构模式。项目包含两个主要服务：

- **RPC 服务** (端口 8080)：核心业务逻辑、数据处理和外部数据源集成
- **API 服务** (端口 8888)：HTTP 接口层，作为 RPC 服务的代理

## 架构设计

### 服务结构
- `cmdb_backend_v2/rpc/`：RPC 服务（业务逻辑层）
- `cmdb_backend_v2/api/`：API 服务（HTTP 接口层）
- `cmdb_frontend_v2/`：React 前端应用

### 前端架构
- **主要页面**：
  - `HostResourceUsageanAlysis.js` - 主机资源用量分析（默认3个月数据）
  - `ClusterResourceUsageReport.js` - 集群资源用量报告（默认3个月数据）
  - `AdminManagement.js` - 系统管理主页面（导航布局）
- **子页面组件**：
  - `adminManagmentSubPage/ClusterGroupSync.js` - 集群组数据同步
  - `adminManagmentSubPage/ServerMetricsLoader.js` - 监控指标数据加载
  - `adminManagmentSubPage/MonitoringVerification.js` - 监控数据核对（带筛选功能）
  - `clusterResourceSubPage/` - 集群资源相关子组件
  - `hostResourceUsageSubPage/` - 主机资源使用相关子组件
- **工具组件**：
  - `utils/tableUtils.js` - 表格筛选、搜索、排序等通用工具

### 关键架构模式
- **go-zero 框架**：使用 go-zero 的 RPC + API 微服务架构
- **Protobuf 优先设计**：所有 RPC 接口定义在 `rpc/proto/cmpool.proto` 中
- **代码生成**：使用 `goctl` 生成 RPC 和 API 样板代码
- **数据库访问**：使用 go-zero 的 sqlx 进行数据库操作，通过结构体标签映射
- **模块化前端**：React 组件按功能分层，主页面 + 子页面组件的模式
- **时间范围统一**：所有数据查询页面默认使用3个月时间范围

## 开发命令

### 代码提交
当要提交代码时，调用 /Users/xuguoqiang/SynologyDrive/Backup/MI_office_notebook/D/myworkspace/nucc_workspace/program/src/nucc.com/cmpool_cursor/tools/gitcommiter/git_commit_and_tag.sh 脚本进行提交，脚本只需要一个参数 -m 用于设置git提交时的信息

### 代码生成
使用位于 `/Users/xuguoqiang/LocalOthers/goctl/goctl` 的自定义 goctl 二进制文件：

```bash
# 修改 proto 文件后生成 RPC 代码
cd rpc
/Users/xuguoqiang/LocalOthers/goctl/goctl rpc protoc proto/cmpool.proto --go_out=. --go-grpc_out=. --zrpc_out=.

# 修改 API 定义后生成 API 代码
cd api  
/Users/xuguoqiang/LocalOthers/goctl/goctl api go -api cmdb.api -dir .
```

### 构建服务
```bash
# 构建 RPC 服务
cd rpc && go build -o cmdb-rpc .

# 构建 API 服务
cd api && go build -o cmdb-api .
```

### 运行服务
```bash
# 使用便捷脚本启动两个服务
./start.sh

# 或手动启动：
# 先启动 RPC 服务（API 服务需要依赖它）
cd rpc && go run cmpool.go -f etc/cmpool.yaml

# 启动 API 服务
cd api && go run cmdb.go -f etc/cmdb-api.yaml
```

### 测试
```bash
# 测试 API 端点和服务启动
./test_api.sh
```

## 数据库操作

### 查询模式
代码库使用 go-zero 的 sqlx 特定模式：

```go
// 单条记录
err := l.svcCtx.DB.QueryRowCtx(l.ctx, &result, query, args...)

// 多条记录
err := l.svcCtx.DB.QueryRowsCtx(l.ctx, &results, query, args...)
```

### 结构体标签
数据库模型使用结构体标签进行字段映射：
```go
type HostInfo struct {
    HostIp     string `db:"host_ip"`
    HostName   string `db:"hostname"`
    CreateTime string `db:"create_time"`
}
```

## 关键数据流模式

### CSV 处理
系统实现了带进度报告的流式 CSV 处理：
- 使用 `LoadServerMetricsCSVProgressResp` 带 `LastUpdatedTime` 进行进度跟踪
- 实现流式 gRPC 进行实时进度更新
- 包含带行号报告的综合错误处理

### RPC 到 API 转换
API 服务充当 HTTP 和 RPC 之间的转换器：
- API 处理器将 HTTP 请求解析为 RPC 消息类型
- API 逻辑调用 RPC 服务并将响应转换回 API 响应类型
- 使用 API 和 RPC 定义生成的类型

### 数据同步
复杂的多表同步模式：
- 从多个源表同步集群数据（mysql_cluster、mssql_cluster 等）
- 主机池同步与应用部署跟踪
- 跨 hosts_pool 和 server_resource 表的监控数据验证

## 配置

### RPC 服务 (rpc/etc/cmpool.yaml)
```yaml
Name: cmpool
ListenOn: 0.0.0.0:8080
DataSource: root:password@tcp(localhost:3306)/cmdb?charset=utf8mb4&parseTime=True&loc=Local
```

### API 服务 (api/etc/cmdb-api.yaml)
```yaml  
Name: cmdb-api
Host: 0.0.0.0
Port: 8888
CmpoolRpc:
  Endpoints:
    - 127.0.0.1:8080
```

## 依赖项

- Go 1.23.1+
- MySQL 5.7+
- Redis（可选，用于缓存）
- github.com/zeromicro/go-zero
- 自定义 goctl 二进制文件用于代码生成

## 重要注意事项

- RPC 服务必须在 API 服务之前启动
- 始终使用自定义 goctl 二进制文件进行代码生成
- 数据库查询使用 `QueryRowsCtx` 而不是标准的 `Query` 方法
- 进度跟踪需要流式响应中的 `LastUpdatedTime` 字段
- 所有新的 RPC 方法必须先在 proto 文件中定义，然后生成代码
- 数据库字段名使用下划线命名（如 `host_name`），结构体标签需正确映射
- 前端组件遵循单一职责原则，主页面负责导航，子组件负责具体功能
- 表格组件使用 `utils/tableUtils.js` 中的通用筛选、搜索、排序功能

## 功能特性

### 数据查询优化
- **默认时间范围**：所有数据查询页面默认显示最近3个月的数据
- **智能回退**：当用户未选择时间范围或解析失败时，自动使用3个月默认值
- **一致性体验**：前端和后端时间范围逻辑统一

### 管理页面模块化
- **导航布局**：`AdminManagement.js` 提供菜单导航和页面框架
- **功能独立**：每个管理功能都是独立的子组件，便于维护和测试
- **组件复用**：子组件可以在其他页面中复用

### 表格功能增强
- **筛选搜索**：支持文本搜索、数值范围筛选、日期范围筛选
- **排序功能**：所有列都支持升序/降序排序
- **高亮显示**：搜索结果自动高亮，提升用户体验