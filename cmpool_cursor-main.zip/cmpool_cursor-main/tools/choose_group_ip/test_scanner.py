#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试IP扫描器功能的简单脚本
"""

import os
import sys
from find_available_ips import IPScanner

def test_scanner():
    """测试IP扫描器的基本功能"""
    # 测试网段，这里使用本地网段和一些常见的网段
    test_prefixes = ["127.0.0", "192.168.1"]
    
    print("开始测试IP扫描器...")
    print(f"测试网段: {', '.join(test_prefixes)}")
    
    # 创建扫描器实例，使用较短的超时时间加快测试
    scanner = IPScanner(test_prefixes, timeout=0.2, max_workers=20)
    
    # 测试ping功能
    print("\n测试ping功能:")
    localhost_result = scanner.ping("127.0.0.1")
    print(f"Ping 127.0.0.1: {'成功' if localhost_result else '失败'}")
    
    # 测试不存在的IP
    nonexistent_result = scanner.ping("192.168.1.254")
    print(f"Ping 192.168.1.254: {'成功' if nonexistent_result else '失败'}")
    
    # 测试扫描单个网段
    print("\n测试扫描单个网段:")
    prefix, unavailable_ips = scanner.scan_prefix("127.0.0")
    print(f"网段 {prefix} 中不可达的IP数量: {len(unavailable_ips)}")
    if unavailable_ips:
        print(f"前5个不可达IP: {', '.join(unavailable_ips[:5])}")
    
    # 测试连续IP段查找
    print("\n测试连续IP段查找:")
    test_ips = ["192.168.1.1", "192.168.1.2", "192.168.1.3", "192.168.1.5", "192.168.1.6", "192.168.1.10"]
    ranges = scanner.find_continuous_ranges(test_ips)
    print(f"测试IP列表: {', '.join(test_ips)}")
    print(f"连续IP段: {', '.join(ranges)}")
    
    # 测试完整扫描流程（仅扫描少量IP以加快测试）
    print("\n测试完整扫描流程（小规模）:")
    mini_scanner = IPScanner(["127.0.0"], timeout=0.1, max_workers=10)
    results = mini_scanner.scan_all()
    
    # 测试Excel导出（可选）
    test_output = "test_output.xlsx"
    print(f"\n测试Excel导出到 {test_output}:")
    mini_scanner.export_to_excel(results, test_output)
    
    if os.path.exists(test_output):
        print(f"Excel文件已成功创建: {test_output}")
        # 可以选择删除测试文件
        # os.remove(test_output)
        # print(f"已删除测试文件: {test_output}")
    else:
        print("Excel文件创建失败")
    
    print("\n测试完成!")

if __name__ == "__main__":
    test_scanner() 