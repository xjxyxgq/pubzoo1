#! /opt/anaconda3/envs/cmpool/bin/python3
# -*- coding: utf-8 -*-
import pandas as pd
import mysql.connector
from collections import defaultdict
import os

# 确保安装了openpyxl
try:
    import openpyxl
except ImportError:
    print("请先安装 openpyxl: pip install openpyxl")
    exit(1)

# 数据库连接配置
db_config = {
    'host': '127.0.0.1',
    'port': 3311,
    'user': 'root',
    'password': 'nov24feb11',
    'database': 'cmpool'
}

def get_cluster_ips():
    """从MySQL获取集群和IP的对应关系"""
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        
        cursor.execute("SELECT cluster_name, ip FROM cluster_ips")
        cluster_ip_map = defaultdict(list)
        for cluster_name, ip in cursor.fetchall():
            cluster_ip_map[cluster_name].append(ip)
            
        return cluster_ip_map
        
    except mysql.connector.Error as err:
        print(f"数据库错误: {err}")
        return None
    finally:
        if 'conn' in locals() and conn.is_connected():
            cursor.close()
            conn.close()

def merge_cluster_ip_mapping(df, db_cluster_ip_map):
    """
    合并数据库中的集群IP关系和Excel中的应用IP关系
    以数据库为主，Excel为补充
    
    Args:
        df: Excel数据DataFrame
        db_cluster_ip_map: 从数据库获取的集群IP映射
    
    Returns:
        合并后的完整集群IP映射
    """
    # 如果数据库映射为空，创建一个空的defaultdict
    if db_cluster_ip_map is None:
        db_cluster_ip_map = defaultdict(list)
    
    # 创建最终的映射，先复制数据库中的映射
    final_cluster_ip_map = defaultdict(list)
    for cluster_name, ips in db_cluster_ip_map.items():
        final_cluster_ip_map[cluster_name].extend(ips)
    
    # 收集数据库中已有的IP地址
    db_ips = set()
    for ips in db_cluster_ip_map.values():
        db_ips.update(ips)
    
    # 检查Excel中是否有"应用"列
    if '应用' not in df.columns:
        print("Warning: Excel中没有找到'应用'列，无法从Excel补充集群IP关系")
        return final_cluster_ip_map
    
    # 记录数据库中已有的集群数量
    db_cluster_count = len(db_cluster_ip_map)
    
    # 从Excel中补充数据库中没有的IP关系
    excel_added_clusters = set()  # 记录通过Excel新增的集群
    for _, row in df.iterrows():
        ip = row['IP地址']
        app_name = row['应用']
        
        # 如果IP不在数据库映射中，且应用名称不为空，则添加到映射中
        if ip not in db_ips and pd.notna(app_name):
            cluster_name = f"Exc_{str(app_name).strip()}"
            excel_added_clusters.add(cluster_name)
            final_cluster_ip_map[cluster_name].append(ip)
        elif ip not in db_ips and pd.isna(app_name):
            cluster_name = f"Exc_UNKNOWN"
            excel_added_clusters.add(cluster_name)
            final_cluster_ip_map[cluster_name].append(ip)

    # 打印统计信息
    db_ip_count = len(db_ips)
    excel_ip_count = len(df['IP地址'].unique()) - db_ip_count
    total_clusters = len(final_cluster_ip_map)
    excel_cluster_count = len(excel_added_clusters)
    
    print(f"集群IP关系统计:")
    print(f"  - 数据库中的IP数量: {db_ip_count}")
    print(f"  - Excel补充的IP数量: {excel_ip_count}")
    print(f"  - 数据库中的集群数量: {db_cluster_count}")
    print(f"  - Excel新增的集群数量: {excel_cluster_count}")
    print(f"  - 总集群数量: {total_clusters}")
    
    return final_cluster_ip_map

def read_data_file(file_path):
    """Read data from either xlsx or csv file"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_ext = os.path.splitext(file_path)[1].lower()
    
    try:
        if file_ext == '.xlsx':
            return pd.read_excel(file_path, engine='openpyxl')
        elif file_ext == '.csv':
            return pd.read_csv(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_ext}. Please use .xlsx or .csv")
    except Exception as e:
        raise Exception(f"Error reading file {file_path}: {str(e)}")

def analyze_cluster_usage(file_path='server_data.xlsx', show_all=False):
    """
    Analyze cluster resource usage from either xlsx or csv file
    
    Args:
        file_path (str): Path to the data file (.xlsx or .csv)
        show_all (bool): Whether to show all clusters regardless of resource utilization
    """
    # Define resource utilization thresholds
    THRESHOLDS = {
        'CPU': 10,    # Maximum CPU utilization threshold
        'MEM': 20,    # Maximum memory utilization threshold
        'DISK': 20    # Maximum disk utilization threshold
    }
    
    # Read data file
    try:
        df = read_data_file(file_path)
    except Exception as e:
        print(f"Error: {e}")
        return
    
    # Verify required columns exist
    required_columns = ['IP地址', '最大CPU', '最大内存', '最大磁盘']
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        print(f"Error: Missing required columns: {', '.join(missing_columns)}")
        return
    
    # Get cluster-IP mapping
    cluster_ip_map = get_cluster_ips()
    
    # Merge cluster IP mapping with Excel data
    merged_cluster_ip_map = merge_cluster_ip_mapping(df, cluster_ip_map)
    
    # Analyze resource usage for each cluster
    underutilized_clusters = []
    
    for cluster_name, ips in merged_cluster_ip_map.items():
        # Get resource usage data for all IPs in this cluster
        cluster_data = df[df['IP地址'].isin(ips)]
        
        if cluster_data.empty:
            continue
            
        # Calculate cluster-level maximum resource usage
        max_cpu = cluster_data['最大CPU'].max()
        max_mem = cluster_data['最大内存'].max()
        max_disk = cluster_data['最大磁盘'].max()

        trigger = ""
        if max_cpu < THRESHOLDS['CPU']:
            trigger += "#CPU"
        elif max_mem < THRESHOLDS['MEM']:
            trigger += "#MEM"
        elif max_disk < THRESHOLDS['DISK']:
            trigger += "#DISK"
        
        # Check if resource utilization is below thresholds or show_all is True
        if trigger != "" or show_all:
            underutilized_clusters.append({
                'cluster_name': cluster_name,
                'ip_count': len(ips),
                'max_cpu': max_cpu,
                'max_mem': max_mem,
                'max_disk': max_disk,
                'trigger': trigger
            })
    
    # Output analysis results
    if underutilized_clusters:
        # Define column widths
        COL_WIDTHS = {
            'cluster': 20,
            'ip_count': 10,
            'metrics': 12,  # width for each metric column
            'ips': 45
        }
        
        # 对 underutilized_clusters 列表根据 cluster_name 分割后的第二个元素及后续元素进行排序
        sorted_clusters = sorted(underutilized_clusters, 
                              key=lambda x: '_'.join(x['cluster_name'].split('_')[1:]) if '_' in x['cluster_name'] and len(x['cluster_name'].split('_')) > 1 else '')
        
        # 按照cluster_name分割后的第二个元素及后续元素进行分组
        group_map = defaultdict(list)
        for cluster in sorted_clusters:
            # 使用与排序相同的 lambda 逻辑获取分组键
            cluster_key = '_'.join(cluster['cluster_name'].split('_')[1:]) if '_' in cluster['cluster_name'] and len(cluster['cluster_name'].split('_')) > 1 else ''
            # 加入到对应的分组
            group_map[cluster_key].append(cluster)
        
        # 检查每组是否有机器不低于任何阈值
        for group_key, group_clusters in group_map.items():
            # 收集所有分组内的集群名称
            group_cluster_names = set(cluster['cluster_name'] for cluster in group_clusters)
            
            # 检查该分组中的所有集群
            has_good_machine = False
            for cluster_name, ips in merged_cluster_ip_map.items():
                # 跳过不属于当前分组的集群
                if '_' not in cluster_name:
                    continue
                
                parts = cluster_name.split('_')
                if len(parts) <= 1:
                    continue
                    
                this_cluster_key = '_'.join(parts[1:])
                if this_cluster_key != group_key:
                    continue
                
                # 如果这个集群不在低使用率集群列表中，说明它的所有指标都不低于阈值
                if cluster_name not in group_cluster_names:
                    # 找到了至少一台所有指标都不低于阈值的机器
                    has_good_machine = True
                    break
            
            # 如果找到了至少一台所有指标都不低于阈值的机器，给整个分组标记OK
            if has_good_machine:
                for cluster in group_clusters:
                    cluster['trigger'] += " OK"
        
        title = "Clusters with Resource Usage:" if show_all else "Clusters with Underutilized Resources:"
        print(f"\n{title}")
        total_width = COL_WIDTHS['cluster'] + COL_WIDTHS['ip_count'] + COL_WIDTHS['metrics']*4 + COL_WIDTHS['ips']
        print("-" * total_width)
        
        # Print header
        print(f"{'Cluster Name':{COL_WIDTHS['cluster']}} "
              f"{'IP Count':{COL_WIDTHS['ip_count']}} "
              f"{'Max CPU':{COL_WIDTHS['metrics']}} "
              f"{'Max Mem':{COL_WIDTHS['metrics']}} "
              f"{'Max Disk':{COL_WIDTHS['metrics']}} "
              f"{'IPs':{COL_WIDTHS['ips']}} "
              f"{'Trigger':{COL_WIDTHS['metrics']}}")
        print("-" * total_width)
        
        for cluster in sorted_clusters:
            # Get IPs for this cluster
            cluster_ips = merged_cluster_ip_map[cluster['cluster_name']]
            # Format IP list (show up to 5 IPs)
            ip_display = ', '.join(cluster_ips[:5])
            if len(cluster_ips) > 5:
                ip_display += '...'
                
            # Format each metric with percentage
            cpu_str = f"{cluster['max_cpu']:.2f}%"
            mem_str = f"{cluster['max_mem']:.2f}%"
            disk_str = f"{cluster['max_disk']:.2f}%"
            
            print(f"{cluster['cluster_name']:{COL_WIDTHS['cluster']}} "
                  f"{cluster['ip_count']:{COL_WIDTHS['ip_count']}} "
                  f"{cpu_str:{COL_WIDTHS['metrics']}} "
                  f"{mem_str:{COL_WIDTHS['metrics']}} "
                  f"{disk_str:{COL_WIDTHS['metrics']}} "
                  f"{ip_display:{COL_WIDTHS['ips']}} "
                  f"{cluster['trigger']:{COL_WIDTHS['metrics']}}")
    else:
        print("No clusters found with the specified criteria")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Analyze cluster resource usage from xlsx or csv file')
    parser.add_argument('--file', '-f', 
                       default='server_data.xlsx',
                       help='Path to the data file (.xlsx or .csv)')
    parser.add_argument('--all', '-a', 
                       action='store_true',
                       help='Show all clusters regardless of resource utilization')
    
    args = parser.parse_args()
    analyze_cluster_usage(args.file, args.all) 