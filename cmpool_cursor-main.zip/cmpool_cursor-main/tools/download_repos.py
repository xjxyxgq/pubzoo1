#! /opt/anaconda3/envs/cmpool/bin/python3
# -*- coding: utf-8 -*-
import os
import subprocess
from pathlib import Path
import re
import time
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

class GitDownloader:
    def __init__(self, max_retries=3, retry_delay=5, max_workers=5, update_existing=False):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.max_workers = max_workers
        self.failed_repos = {}
        self.download_base_dir = "downloaded_repos"
        self.failed_repos_file = "failed_repos.json"
        self.completed_repos_file = "completed_repos.json"
        self.failed_repos_lock = Lock()  # 添加线程锁
        self.print_lock = Lock()  # 添加打印锁
        self.completed_repos_lock = Lock()  # 添加已完成仓库的锁
        self.completed_repos = self.load_completed_repos()
        self.update_existing = update_existing  # 是否更新已存在的仓库
        
    def safe_print(self, *args, **kwargs):
        """线程安全的打印函数"""
        with self.print_lock:
            print(*args, **kwargs)
            
    def add_failed_repo(self, repo_url, error, attempts):
        """线程安全地添加失败记录"""
        with self.failed_repos_lock:
            self.failed_repos[repo_url] = {
                'last_error': error,
                'attempts': attempts,
                'timestamp': datetime.now().isoformat()
            }

    def get_flat_path(self, url):
        """将URL转换为扁平化的路径"""
        if url.startswith(('github.com/', 'gitbox.apache.org/', 'pypi.org/', 'opendev.org/', 'go.googlesource.com/')):
            # 替换所有路径分隔符为下划线
            flat_path = url.replace('/', '_')
            # 移除.git后缀
            flat_path = flat_path.replace('.git', '')
            return flat_path
        return f"github.com_{url.replace('/', '_')}"
        
    def clean_repo_url(self, url):
        """清理并标准化仓库URL"""
        # 对于 pypi 项目，直接返回包名
        if 'pypi.org/project' in url:
            return url.split('/')[-1]
        
        # 对于 github 项目，使用git协议
        if not url.startswith(('http://', 'https://', 'git://')):
            if 'github.com' in url:
                url = f"git://{url}.git"
            elif 'go.googlesource.com' in url:
                url = f"https://{url}"
            elif 'opendev.org' in url:
                url = f"https://{url}"
            else:
                url = f"https://github.com/{url}"
        
        return url

    def try_clone(self, url, project_dir):
        """尝试克隆仓库"""
        process = subprocess.Popen(['git', 'clone', '--depth', '1', url, project_dir],
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE,
                                 universal_newlines=True)
        stdout, stderr = process.communicate()
        return process.returncode == 0, stderr

    def load_completed_repos(self):
        """加载已完成下载的仓库记录"""
        if os.path.exists(self.completed_repos_file):
            try:
                with open(self.completed_repos_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                self.safe_print(f"Warning: Could not parse {self.completed_repos_file}, starting with empty records.")
                return {}
        return {}
    
    def save_completed_repos(self):
        """保存已成功下载的仓库记录"""
        with open(self.completed_repos_file, 'w') as f:
            json.dump(self.completed_repos, f, indent=2)
    
    def add_completed_repo(self, repo_url):
        """记录成功下载的仓库"""
        with self.completed_repos_lock:
            self.completed_repos[repo_url] = {
                'timestamp': datetime.now().isoformat(),
                'path': self.get_flat_path(repo_url)
            }
            # 定期保存以防程序中断
            if len(self.completed_repos) % 10 == 0:
                self.save_completed_repos()
    
    def is_valid_git_repo(self, project_dir):
        """检查目录是否是有效的Git仓库"""
        git_dir = os.path.join(project_dir, '.git')
        return os.path.exists(git_dir) and os.path.isdir(git_dir)
    
    def update_repo(self, project_dir):
        """更新已存在的仓库"""
        try:
            # 保存当前目录
            current_dir = os.getcwd()
            # 切换到仓库目录
            os.chdir(project_dir)
            
            # 执行git pull
            process = subprocess.Popen(['git', 'pull', '--rebase'],
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE,
                                     universal_newlines=True)
            stdout, stderr = process.communicate()
            success = process.returncode == 0
            
            # 切回原目录
            os.chdir(current_dir)
            
            return success, stderr if not success else stdout
        except Exception as e:
            # 确保切回原目录
            try:
                os.chdir(current_dir)
            except:
                pass
            return False, str(e)

    def download_repo(self, repo_url, index=None, total=None):
        """下载单个仓库，带重试机制"""
        try:
            # 跳过注释的行
            if repo_url.startswith('#'):
                self.safe_print(f"Skipping commented repository: {repo_url}")
                return True
            
            # 检查是否已经成功下载过
            if repo_url in self.completed_repos and not self.update_existing:
                self.safe_print(f"Repository {repo_url} has been successfully downloaded before, skipping...")
                return True
                
            clean_url = self.clean_repo_url(repo_url)
            flat_path = self.get_flat_path(repo_url)
            
            # 创建扁平化的目录路径
            project_dir = os.path.join(self.download_base_dir, flat_path)
            
            # 添加进度信息到输出
            progress = f"[{index}/{total}] " if index and total else ""
            
            # 处理已存在的仓库
            if os.path.exists(project_dir):
                # 验证是否是有效的Git仓库
                if not self.is_valid_git_repo(project_dir):
                    self.safe_print(f"{progress}Directory {project_dir} exists but is not a valid Git repository. Removing and re-downloading...")
                    import shutil
                    shutil.rmtree(project_dir)
                elif self.update_existing:
                    self.safe_print(f"{progress}Updating existing repository in {project_dir}...")
                    success, message = self.update_repo(project_dir)
                    if success:
                        self.safe_print(f"{progress}Successfully updated {flat_path}: {message.strip()}")
                        self.add_completed_repo(repo_url)  # 更新也算完成
                        return True
                    else:
                        self.safe_print(f"{progress}Failed to update {flat_path}: {message}")
                        # 如果更新失败，重新克隆
                        self.safe_print(f"{progress}Re-cloning repository...")
                        import shutil
                        shutil.rmtree(project_dir)
                else:
                    self.safe_print(f"{progress}Directory {project_dir} already exists, skipping...")
                    self.add_completed_repo(repo_url)  # 已存在的也记录为完成
                    return True
            
            # 确保下载目录存在
            os.makedirs(self.download_base_dir, exist_ok=True)
            
            for attempt in range(self.max_retries):
                self.safe_print(f"{progress}Downloading {flat_path} from {clean_url} (Attempt {attempt + 1}/{self.max_retries})...")
                
                # 尝试使用git协议
                success, error = self.try_clone(clean_url, project_dir)
                if success:
                    self.safe_print(f"{progress}Successfully downloaded {flat_path}")
                    self.add_completed_repo(repo_url)  # 记录成功下载
                    return True
                
                # 如果git协议失败，尝试https协议
                if 'git://' in clean_url:
                    https_url = clean_url.replace('git://', 'https://')
                    self.safe_print(f"{progress}Retrying with HTTPS: {https_url}")
                    success, error = self.try_clone(https_url, project_dir)
                    if success:
                        self.safe_print(f"{progress}Successfully downloaded {flat_path}")
                        self.add_completed_repo(repo_url)  # 记录成功下载
                        return True
                
                if attempt < self.max_retries - 1:
                    self.safe_print(f"{progress}Attempt {attempt + 1} failed. Retrying in {self.retry_delay} seconds...")
                    time.sleep(self.retry_delay)
                
            self.add_failed_repo(repo_url, error, self.max_retries)
            self.safe_print(f"{progress}Failed to download {repo_url} after {self.max_retries} attempts: {error}")
            return False
            
        except Exception as e:
            self.add_failed_repo(repo_url, str(e), self.max_retries)
            self.safe_print(f"{progress}Error processing {repo_url}: {str(e)}")
            return False

    def save_failed_repos(self):
        """保存失败的仓库信息到文件"""
        if self.failed_repos:
            with open(self.failed_repos_file, 'w') as f:
                json.dump(self.failed_repos, f, indent=2)
            self.safe_print(f"\nFailed repositories have been saved to {self.failed_repos_file}")

    def download_all(self, repos_file='tools/git_resp.txt'):
        """并发下载所有仓库"""
        # 创建下载目录
        os.makedirs(self.download_base_dir, exist_ok=True)
        
        # 读取仓库列表
        with open(repos_file, 'r') as f:
            repos = [repo.strip() for repo in f.readlines() if repo.strip()]
        
        # 去重
        repos = list(set(repos))
        
        # 下载统计
        total = len(repos)
        success = 0
        failed = 0
        skipped = 0
        already_downloaded = 0
        
        self.safe_print(f"\nStarting download with {self.max_workers} concurrent workers...")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # 创建下载任务，包含进度信息
            future_to_repo = {
                executor.submit(self.download_repo, repo, i+1, total): repo 
                for i, repo in enumerate(repos)
            }
            
            # 处理完成的任务
            for future in future_to_repo:
                repo = future_to_repo[future]
                try:
                    if repo.startswith('#'):
                        skipped += 1
                        continue
                    
                    # 检查是否是已经下载过的仓库
                    if repo in self.completed_repos and not self.update_existing and future.result():
                        already_downloaded += 1
                    elif future.result():
                        success += 1
                    else:
                        failed += 1
                except Exception as e:
                    self.safe_print(f"Unexpected error for {repo}: {str(e)}")
                    failed += 1
        
        # 保存失败信息
        self.save_failed_repos()
        
        # 保存完成信息
        self.save_completed_repos()
        
        # 打印总结
        self.safe_print(f"\nDownload Summary:")
        self.safe_print(f"Total repositories: {total}")
        self.safe_print(f"Successfully downloaded: {success}")
        self.safe_print(f"Already downloaded: {already_downloaded}")
        self.safe_print(f"Failed: {failed}")
        self.safe_print(f"Skipped (commented): {skipped}")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Download Git repositories with optimized handling.')
    parser.add_argument('--workers', type=int, default=int(os.getenv('GIT_DOWNLOAD_WORKERS', '5')), 
                        help='Number of concurrent download workers')
    parser.add_argument('--update', action='store_true', 
                        help='Update existing repositories instead of skipping them')
    parser.add_argument('--repos-file', type=str, default='tools/git_resp.txt',
                        help='Path to file containing repository URLs')
    
    args = parser.parse_args()
    
    downloader = GitDownloader(max_retries=3, retry_delay=5, 
                              max_workers=args.workers, 
                              update_existing=args.update)
    downloader.download_all(repos_file=args.repos_file)

if __name__ == '__main__':
    main() 