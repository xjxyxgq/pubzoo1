#!/bin/bash

export PATH=/usr/local/bin:$PATH
# ======== 可选参数 ========
TARGET_DISK_PERCENT=${1:-30}     # 目标磁盘占用率（百分比），默认 30%
DURATION=${2:-10}               # 运行持续时间（秒），默认 600 秒（10分钟）
TARGET_PATH=${3:-/tmp}           # 目标目录，默认 /tmp
NICE_LEVEL=${4:-19}              # nice 优先级（-20 到 19，数值越高优先级越低），默认 19
DISABLE_CGROUP=${5:-false}       # 是否禁用 cgroup（调试用），默认 false
DISK_SIZE=${6:-auto}             # 自定义磁盘占用大小（如 1G, 500M），auto=自动计算

GROUP_NAME="disk_limit_smart"
TEST_FILE_PREFIX="disk_stress_test"

# ======== 环境检查 ========
echo "=========================================="
echo "[*] 磁盘空间占用压测工具 - 双重隔离策略"
echo "=========================================="

# 检测系统架构
ARCH=$(uname -m)
OS_TYPE=$(uname -s)
echo "[*] 系统架构: $ARCH"
echo "[*] 操作系统: $OS_TYPE"

# 检测最佳文件创建命令
echo "[*] 检测文件创建命令兼容性:"
FORCE_DD=false
if [[ "$7" == "-f" ]]; then
    FORCE_DD=true
    echo "    ├─ 强制使用 dd 模式 (-f 参数)"
fi

if [[ "$FORCE_DD" == "true" ]]; then
    if command -v dd &> /dev/null; then
        FILE_CREATE_CMD="dd"
        echo "    ├─ dd: ✓ (强制使用)"
    else
        echo "    ├─ dd: ✗ (命令不可用)"
        echo "✗ 强制模式下需要 dd 命令"
        exit 1
    fi
elif [[ "$OS_TYPE" == "Linux" ]] && command -v fallocate &> /dev/null; then
    FILE_CREATE_CMD="fallocate"
    echo "    ├─ fallocate: ✓ (Linux 高效分配)"
elif [[ "$OS_TYPE" == "Darwin" ]] && command -v mkfile &> /dev/null; then
    FILE_CREATE_CMD="mkfile"
    echo "    ├─ mkfile: ✓ (macOS 原生命令)"
elif command -v dd &> /dev/null; then
    FILE_CREATE_CMD="dd"
    echo "    ├─ dd: ✓ (备选方案，添加 -f 参数强制使用)"
    echo "    └─ 建议: 使用 -f 参数明确选择 dd 命令"
else
    echo "    ├─ fallocate: ✗"
    echo "    ├─ mkfile: ✗"
    echo "    ├─ dd: ✗"
    echo "✗ 未找到可用的文件创建命令"
    exit 1
fi

echo "[*] 选择文件创建方法: $FILE_CREATE_CMD"

# 详细系统信息诊断
echo "[*] 系统详情诊断:"
echo "    ├─ 内核版本: $(uname -r)"
echo "    ├─ 发行版: $(if [[ "$OS_TYPE" == "Linux" ]]; then cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d'"' -f2 || echo "Unknown"; else echo "Non-Linux"; fi)"

# 检查目标目录
if [[ ! -d "$TARGET_PATH" ]]; then
    echo "✗ 目标目录不存在: $TARGET_PATH"
    exit 1
fi

if [[ ! -w "$TARGET_PATH" ]]; then
    echo "✗ 目标目录没有写权限: $TARGET_PATH"
    exit 1
fi

# 获取磁盘信息
if command -v df &> /dev/null; then
    DISK_INFO=$(df -h "$TARGET_PATH" | tail -1)
    TOTAL_SPACE=$(echo $DISK_INFO | awk '{print $2}')
    USED_SPACE=$(echo $DISK_INFO | awk '{print $3}')
    AVAILABLE_SPACE=$(echo $DISK_INFO | awk '{print $4}')
    CURRENT_PERCENT=$(echo $DISK_INFO | awk '{print $5}' | sed 's/%//')
    MOUNT_POINT=$(echo $DISK_INFO | awk '{print $6}')
    
    echo "[*] 磁盘信息 ($TARGET_PATH):"
    echo "    ├─ 挂载点: $MOUNT_POINT"
    echo "    ├─ 总空间: $TOTAL_SPACE"
    echo "    ├─ 已用空间: $USED_SPACE"
    echo "    ├─ 可用空间: $AVAILABLE_SPACE"
    echo "    └─ 当前占用率: ${CURRENT_PERCENT}%"
else
    echo "✗ df 命令不可用，无法获取磁盘信息"
    exit 1
fi

# 检查是否已经达标
if [[ $CURRENT_PERCENT -ge $TARGET_DISK_PERCENT ]]; then
    echo "[✓] 当前磁盘占用率 (${CURRENT_PERCENT}%) 已达到目标 (${TARGET_DISK_PERCENT}%)"
    echo "[*] 无需额外占用空间，程序将持续监控 ${DURATION} 秒"
    NEED_STRESS=false
else
    echo "[*] 需要提升磁盘占用率从 ${CURRENT_PERCENT}% 到 ${TARGET_DISK_PERCENT}%"
    NEED_STRESS=true
fi

# 检查 ionice 是否可用（Linux 系统）
IONICE_AVAILABLE=false
if command -v ionice &> /dev/null && [[ "$(uname)" == "Linux" ]]; then
    IONICE_AVAILABLE=true
fi

# 检测 cgroup 类型
CGROUP_ENABLED=true
if [[ "$DISABLE_CGROUP" == "true" ]]; then
    echo "[*] cgroup 功能已禁用（调试模式）"
    CGROUP_ENABLED=false
elif [[ -f /sys/fs/cgroup/cgroup.controllers ]]; then
    CGROUP_TYPE="v2"
    CGROUP_ROOT="/sys/fs/cgroup"
    echo "[*] 检测到 cgroup $CGROUP_TYPE"
elif [[ -d /sys/fs/cgroup/blkio ]]; then
    CGROUP_TYPE="v1"
    CGROUP_ROOT="/sys/fs/cgroup/blkio"
    echo "[*] 检测到 cgroup $CGROUP_TYPE"
else
    echo "[!] 警告: 未检测到可用的 cgroup 系统，将仅使用 nice/ionice"
    CGROUP_ENABLED=false
fi

# ======== 计算需要创建的文件大小 ========
if [[ "$NEED_STRESS" == "true" ]]; then
    # 获取可用空间（MB）
    AVAILABLE_MB=$(echo "$AVAILABLE_SPACE" | sed 's/[gG]/*1024/' | sed 's/[mM]//' | sed 's/[kK]/\/1024/' | bc 2>/dev/null | cut -d. -f1)
    
    # 获取总空间（MB）- 用于计算目标占用
    if [[ "$TOTAL_SPACE" =~ G ]]; then
        TOTAL_MB=$(echo "$TOTAL_SPACE" | sed 's/G//' | awk '{print int($1*1024)}')
    elif [[ "$TOTAL_SPACE" =~ M ]]; then
        TOTAL_MB=$(echo "$TOTAL_SPACE" | sed 's/M//' | awk '{print int($1)}')
    elif [[ "$TOTAL_SPACE" =~ T ]]; then
        TOTAL_MB=$(echo "$TOTAL_SPACE" | sed 's/T//' | awk '{print int($1*1024*1024)}')
    else
        # 假设是字节，转换为MB
        TOTAL_MB=$(echo "$TOTAL_SPACE" | awk '{print int($1/1024/1024)}')
    fi
    
    if [[ "$DISK_SIZE" == "auto" ]]; then
        # 自动计算所需空间
        TARGET_USED_MB=$((TOTAL_MB * TARGET_DISK_PERCENT / 100))
        CURRENT_USED_MB=$((TOTAL_MB - AVAILABLE_MB))
        NEEDED_SPACE_MB=$((TARGET_USED_MB - CURRENT_USED_MB))
        
        # 确保不会占用超过90%的可用空间（安全边界）
        MAX_SAFE_SPACE=$((AVAILABLE_MB * 90 / 100))
        if [[ $NEEDED_SPACE_MB -gt $MAX_SAFE_SPACE ]]; then
            NEEDED_SPACE_MB=$MAX_SAFE_SPACE
            echo "[!] 警告: 限制文件大小为 ${NEEDED_SPACE_MB} MB（安全边界）"
        fi
        
        echo "[*] 计算所需文件大小: ${NEEDED_SPACE_MB} MB"
    else
        # 用户自定义文件大小
        NEEDED_SPACE_MB=$(echo "$DISK_SIZE" | sed 's/[gG]/*1024/' | sed 's/[mM]//' | sed 's/[kK]/\/1024/' | bc 2>/dev/null | cut -d. -f1)
        if [[ $NEEDED_SPACE_MB -eq 0 ]]; then
            echo "✗ 无效的文件大小格式: $DISK_SIZE"
            exit 1
        fi
        echo "[*] 用户指定文件大小: ${NEEDED_SPACE_MB} MB"
    fi
    
    # 确保至少创建 10MB
    if [[ $NEEDED_SPACE_MB -lt 10 ]]; then
        NEEDED_SPACE_MB=10
        echo "[*] 最小文件大小设为: ${NEEDED_SPACE_MB} MB"
    fi
fi

echo "[*] 目标磁盘占用率: ${TARGET_DISK_PERCENT}%"
echo "[*] 运行时长: ${DURATION}s"
echo "[*] 目标目录: $TARGET_PATH"
echo "[*] 隔离策略: cgroup ($CGROUP_TYPE) I/O限制 + nice/ionice 软优先级"
echo "[*] Nice 优先级: $NICE_LEVEL"
if [[ "$IONICE_AVAILABLE" == "true" ]]; then
    echo "[*] I/O 调度: Idle 类别"
fi

# ======== 清理函数 ========
cleanup() {
    echo ""
    echo "[*] 正在清理资源..."
    
    # 停止文件创建进程
    if [[ -n "$CREATE_PID" ]]; then
        kill $CREATE_PID 2>/dev/null || true
        wait $CREATE_PID 2>/dev/null || true
    fi
    
    # 停止监控进程
    if [[ -n "$MONITOR_PID" ]]; then
        kill $MONITOR_PID 2>/dev/null || true
    fi
    
    # 删除测试文件
    if [[ -n "$TEST_FILE_PATH" && -f "$TEST_FILE_PATH" ]]; then
        echo "[*] 删除测试文件: $TEST_FILE_PATH"
        rm -f "$TEST_FILE_PATH" 2>/dev/null || true
    fi
    
    # 清理 cgroup
    if [[ -n "$CGROUP_PATH" && -d "$CGROUP_PATH" ]]; then
        echo "[*] 清理 cgroup: $CGROUP_PATH"
        sudo rmdir "$CGROUP_PATH" 2>/dev/null || true
    fi
    
    echo "[✓] 清理完成"
}

# 设置信号处理
trap cleanup EXIT INT TERM

# ======== 配置 cgroup ========
if [[ "$CGROUP_ENABLED" == "true" ]]; then
    # 检查 sudo 权限
    if ! sudo -n true 2>/dev/null; then
        echo "[!] 警告: 需要 sudo 权限来配置 cgroup，将跳过 cgroup 配置"
        CGROUP_ENABLED=false
    else
        CGROUP_PATH="$CGROUP_ROOT/$GROUP_NAME"
        
        echo "[*] 创建 cgroup: $CGROUP_PATH"
        sudo mkdir -p "$CGROUP_PATH"
        
        if [[ "$CGROUP_TYPE" == "v2" ]]; then
            # cgroup v2 I/O 限制配置
            echo "[*] 配置 cgroup v2 I/O 限制"
            
            # 检查是否启用了I/O控制器
            if [[ -f "$CGROUP_ROOT/cgroup.subtree_control" ]]; then
                CONTROLLERS=$(cat "$CGROUP_ROOT/cgroup.subtree_control" 2>/dev/null)
                echo "[*] 根cgroup控制器: $CONTROLLERS"
                if [[ "$CONTROLLERS" != *"io"* ]]; then
                    echo "io" | sudo tee -a "$CGROUP_ROOT/cgroup.subtree_control" > /dev/null 2>&1 || true
                    echo "[*] 尝试启用I/O控制器"
                fi
            fi
            
            # 设置I/O权重（较低优先级）
            if [[ -f "$CGROUP_PATH/io.weight" ]]; then
                echo "10" | sudo tee "$CGROUP_PATH/io.weight" > /dev/null 2>&1 || true
                echo "[*] 设置I/O权重: 10 (低优先级)"
            fi
            
        elif [[ "$CGROUP_TYPE" == "v1" ]]; then
            # cgroup v1 I/O 限制配置
            echo "[*] 配置 cgroup v1 I/O 限制"
            
            # 设置I/O权重（较低优先级）
            if [[ -f "$CGROUP_PATH/blkio.weight" ]]; then
                echo "10" | sudo tee "$CGROUP_PATH/blkio.weight" > /dev/null 2>&1 || true
                echo "[*] 设置I/O权重: 10 (低优先级)"
            fi
        fi
    fi
else
    echo "[*] 跳过 cgroup 配置，仅使用 nice/ionice 限制"
fi

# ======== 创建磁盘占用 ========
if [[ "$NEED_STRESS" == "true" ]]; then
    # 生成唯一的测试文件名
    TIMESTAMP=$(date +%s)
    TEST_FILE_PATH="$TARGET_PATH/${TEST_FILE_PREFIX}_${TIMESTAMP}.tmp"
    
    echo "=========================================="
    echo "[*] 开始创建测试文件: $TEST_FILE_PATH"
    echo "[*] 文件大小: ${NEEDED_SPACE_MB} MB"
    echo "=========================================="
    
    # 构建文件创建命令 
    case "$FILE_CREATE_CMD" in
        "fallocate")
            # Linux fallocate - 快速分配，但不写入实际数据
            CREATE_CMD="fallocate -l ${NEEDED_SPACE_MB}M \"$TEST_FILE_PATH\""
            echo "[*] 使用 fallocate 快速分配文件空间"
            ;;
        "mkfile")
            # macOS mkfile - 创建指定大小的文件
            CREATE_CMD="mkfile ${NEEDED_SPACE_MB}m \"$TEST_FILE_PATH\""
            echo "[*] 使用 mkfile 创建文件"
            ;;
        "dd")
            # 传统 dd 命令 - 写入实际数据，确保真实占用
            CREATE_CMD="dd if=/dev/zero of=\"$TEST_FILE_PATH\" bs=1M count=${NEEDED_SPACE_MB} conv=fsync"
            echo "[*] 使用 dd 写入实际数据到文件"
            ;;
        *)
            echo "✗ 未知的文件创建命令: $FILE_CREATE_CMD"
            exit 1
            ;;
    esac
    
    # 添加 nice 和 ionice
    PRIORITY_CMD="nice -n $NICE_LEVEL"
    if [[ "$IONICE_AVAILABLE" == "true" ]]; then
        PRIORITY_CMD="$PRIORITY_CMD ionice -c 3"  # Idle I/O 调度类别
    fi
    
    FINAL_CMD="$PRIORITY_CMD $CREATE_CMD"
    
    echo "[*] 执行命令: $FINAL_CMD"
    echo "[*] 开始文件创建..."
    
    # 启动文件创建进程
    eval "$FINAL_CMD" &
    CREATE_PID=$!
    echo "[*] 文件创建进程已启动，PID: $CREATE_PID"
    
    # 将进程加入 cgroup
    if [[ "$CGROUP_ENABLED" == "true" ]]; then
        echo "[*] 将文件创建进程 $CREATE_PID 加入 cgroup..."
        sleep 1
        
        if [[ "$CGROUP_TYPE" == "v2" ]]; then
            echo "$CREATE_PID" | sudo tee "$CGROUP_PATH/cgroup.procs" > /dev/null
            if grep -q "^$CREATE_PID$" "$CGROUP_PATH/cgroup.procs" 2>/dev/null; then
                echo "[✓] 文件创建进程成功加入 cgroup v2"
            else
                echo "[✗] 警告: 文件创建进程可能未成功加入 cgroup v2"
            fi
        elif [[ "$CGROUP_TYPE" == "v1" ]]; then
            echo "$CREATE_PID" | sudo tee "$CGROUP_PATH/tasks" > /dev/null
            if grep -q "^$CREATE_PID$" "$CGROUP_PATH/tasks" 2>/dev/null; then
                echo "[✓] 文件创建进程成功加入 cgroup v1"
            else
                echo "[✗] 警告: 文件创建进程可能未成功加入 cgroup v1"
            fi
        fi
        echo "[✓] 文件创建进程开始受限执行 (cgroup + nice/ionice)"
    else
        echo "[✓] 文件创建进程开始执行 (仅 nice/ionice)"
    fi
    
    # 等待文件创建完成
    wait $CREATE_PID
    CREATE_EXIT_CODE=$?
    CREATE_PID=""
    
    if [[ $CREATE_EXIT_CODE -eq 0 ]]; then
        echo "[✓] 测试文件创建完成"
        # 验证文件大小
        if [[ -f "$TEST_FILE_PATH" ]]; then
            ACTUAL_SIZE=$(du -m "$TEST_FILE_PATH" 2>/dev/null | cut -f1)
            echo "[*] 实际文件大小: ${ACTUAL_SIZE} MB"
            
            # 对于 fallocate，可能需要额外说明
            if [[ "$FILE_CREATE_CMD" == "fallocate" ]]; then
                echo "[*] 注意: fallocate 创建稀疏文件，占用磁盘空间但不写入实际数据"
            fi
        fi
    else
        echo "[✗] 测试文件创建失败，退出码: $CREATE_EXIT_CODE"
    fi
    
else
    echo "=========================================="
    echo "[*] 跳过文件创建，开始监控模式..."
    echo "=========================================="
fi

# ======== 实时监控函数 ========
monitor_disk() {
    echo "[*] 开始监控磁盘使用情况..."
    local count=0
    local max_samples=$(( DURATION / 5 ))  # 每5秒监控一次


    # 如不进行压测，则监控两次快速退出
    if [[ $NEED_STRESS == 'false' ]]; then
      max_samples=2
    else
      # 确保至少监控5次
      if [[ $max_samples -lt 5 ]]; then
        max_samples=5
      fi
    fi
    
    while [[ $count -lt $max_samples ]]; do
        # 获取当前磁盘使用情况
        local current_disk_info=$(df -h "$TARGET_PATH" | tail -1)
        local current_used=$(echo $current_disk_info | awk '{print $3}')
        local current_available=$(echo $current_disk_info | awk '{print $4}')
        local current_percent=$(echo $current_disk_info | awk '{print $5}' | sed 's/%//')
        
        # 输出监控信息
        local timestamp=$(date '+%H:%M:%S')
        local output="[$timestamp] 磁盘使用: ${current_used} (${current_percent}%)"
        output="$output | 可用: ${current_available}"
        output="$output | 目标: ${TARGET_DISK_PERCENT}%"
        
        # 状态指示
        if [[ $current_percent -ge $TARGET_DISK_PERCENT ]]; then
            output="$output | ✓ 已达标"
        else
            local diff=$((TARGET_DISK_PERCENT - current_percent))
            output="$output | ⚠ 差${diff}%"
        fi
        
        echo "$output"
        
        # 显示测试文件状态
        if [[ -n "$TEST_FILE_PATH" && -f "$TEST_FILE_PATH" ]]; then
            if [[ $(( count % 10 )) -eq 0 ]]; then
                local file_size=$(du -h "$TEST_FILE_PATH" 2>/dev/null | cut -f1)
                echo "    └─ 测试文件: ${file_size}"
            fi
        fi
        
        sleep 5
        ((count++))
    done
    
    echo "[*] 监控结束"
}

# 启动监控（前台运行，确保实时输出）
monitor_disk &
MONITOR_PID=$!

# ======== 等待完成 ========
# 等待监控完成
wait $MONITOR_PID
MONITOR_PID=""

echo "=========================================="
echo "[✓] 程序成功完成"

# ======== 显示最终统计信息 ========
# 获取最终磁盘使用情况
FINAL_DISK_INFO=$(df -h "$TARGET_PATH" | tail -1)
FINAL_USED=$(echo $FINAL_DISK_INFO | awk '{print $3}')
FINAL_AVAILABLE=$(echo $FINAL_DISK_INFO | awk '{print $4}')
FINAL_PERCENT=$(echo $FINAL_DISK_INFO | awk '{print $5}' | sed 's/%//')

echo "[*] 最终磁盘统计:"
echo "    ├─ 起始占用率: ${CURRENT_PERCENT}%"
echo "    ├─ 结束占用率: ${FINAL_PERCENT}%"
echo "    ├─ 目标占用率: ${TARGET_DISK_PERCENT}%"
echo "    └─ 达标状态: $( [[ $FINAL_PERCENT -ge $TARGET_DISK_PERCENT ]] && echo "✓ 已达标" || echo "✗ 未达标" )"

if [[ -n "$TEST_FILE_PATH" && -f "$TEST_FILE_PATH" ]]; then
    FINAL_FILE_SIZE=$(du -h "$TEST_FILE_PATH" 2>/dev/null | cut -f1)
    echo "[*] 测试文件信息:"
    echo "    ├─ 路径: $TEST_FILE_PATH"
    echo "    ├─ 大小: ${FINAL_FILE_SIZE}"
    echo "    └─ 状态: 将在程序退出时自动删除"
fi

echo "=========================================="

# ======== 使用说明 ========
cat << 'EOF'

双重隔离策略说明：
├── cgroup I/O限制: 内核级I/O权重控制，降低磁盘访问优先级
├── nice 软优先级: 进程调度优先级，减少对系统其他进程的影响
└── ionice I/O优先级: 降低磁盘访问优先级（Linux）

磁盘占用策略：
├── 智能检测: 自动检测当前磁盘占用率是否已达标
├── 安全边界: 自动留出10%安全边界，避免磁盘空间耗尽
├── 文件管理: 使用临时文件占用空间，程序退出时自动清理
├── 平台优化: Linux使用fallocate，macOS使用mkfile，其他系统使用dd
└── 强制模式: 添加-f参数强制使用dd命令

使用方法：
  ./disk_usage_limit.sh [磁盘%] [时长s] [目标路径] [nice值] [禁用cgroup] [文件大小] [-f]
  
参数说明：
  - 磁盘%: 1-100，目标磁盘占用率
  - 时长: 运行持续时间（秒）
  - 目标路径: 测试文件创建路径，默认/tmp
  - nice值: -20到19，19为最低优先级
  - 禁用cgroup: true/false，默认false（调试用）
  - 文件大小: auto/具体值（如1G, 500M），auto=自动计算
  - -f: 强制使用dd命令（可选）
  
示例：
  ./disk_usage_limit.sh 50 600 /tmp 19              # 50%占用率，10分钟，/tmp目录
  ./disk_usage_limit.sh 30 300 /home/test 15        # 30%占用率，/home/test目录
  ./disk_usage_limit.sh 40 600 /tmp 19 false 1G     # 强制创建1GB文件
  ./disk_usage_limit.sh 60 300 /tmp 19 true         # 禁用cgroup，仅使用nice/ionice
  ./disk_usage_limit.sh 50 600 /tmp 19 false auto -f # 强制使用dd命令

特性说明：
  - 如果当前磁盘占用率已达标，程序将切换为监控模式
  - 自动计算所需文件大小，确保达到目标占用率
  - 实时监控磁盘使用情况，每5秒输出一次状态
  - 程序退出时自动清理创建的测试文件
  - 支持cgroup v1/v2两种版本的I/O限制
  - 平台自适应：Linux优先使用fallocate，macOS优先使用mkfile

文件创建命令说明：
  - fallocate (Linux): 快速分配文件空间，创建稀疏文件，高效但不写入实际数据
  - mkfile (macOS): macOS原生命令，创建指定大小的文件
  - dd (通用): 传统命令，写入实际数据到磁盘，速度较慢但兼容性最好

注意事项：
  - 确保目标目录有足够的可用空间和写权限
  - fallocate创建的稀疏文件占用磁盘空间但不写入实际数据
  - 大文件创建可能需要较长时间，请耐心等待
  - 程序异常退出时，测试文件可能需要手动清理

EOF
