#!/bin/bash

export PATH=/usr/local/bin:$PATH
# ======== 可选参数 ========
TARGET_MEMORY_PERCENT=${1:-30}     # 目标内存占用率（百分比），默认 30%
DURATION=${2:-600}                 # 运行持续时间（秒），默认 600 秒（10分钟）
NICE_LEVEL=${3:-19}               # nice 优先级（-20 到 19，数值越高优先级越低），默认 19
DISABLE_CGROUP=${4:-false}        # 是否禁用 cgroup（调试用），默认 false
MEMORY_SIZE=${5:-auto}            # 自定义内存大小（如 1G, 500M），auto=自动计算

GROUP_NAME="memory_limit_smart"

# ======== 环境检查 ========
echo "=========================================="
echo "[*] 内存占用压测工具 - 双重隔离策略"
echo "=========================================="

# 检测系统架构
ARCH=$(uname -m)
echo "[*] 系统架构: $ARCH"

# 架构特定优化
if [[ "$ARCH" =~ ^(aarch64|arm64|armv7l|armv8)$ ]]; then
    echo "[*] ARM 架构检测：启用内存分配优化"
    echo "    └─ 这解决了ARM系统内存管理器调度差异问题"
    ARM_OPTIMIZED=true
    # ARM架构内存分配策略调整
    VM_WORKERS_MULTIPLIER=0.5  # ARM使用更少的工作进程
    MEMORY_CHUNK_SIZE=256      # ARM使用较小的内存块(MB)
else
    echo "[*] x86 架构：使用标准内存分配策略"
    ARM_OPTIMIZED=false
    VM_WORKERS_MULTIPLIER=1.0
    MEMORY_CHUNK_SIZE=512      # x86使用标准内存块
fi

# 详细系统信息诊断
echo "[*] 系统详情诊断:"
echo "    ├─ 内核版本: $(uname -r)"
echo "    ├─ 发行版: $(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME | cut -d'"' -f2 || echo "Unknown")"
echo "    ├─ 操作系统: $(uname -s)"
echo "    └─ 内存信息: $(if [[ "$(uname)" == "Darwin" ]]; then echo "$(sysctl hw.memsize | awk '{print $2/1024/1024/1024"GB"}')"; else free -h 2>/dev/null | head -2 | tail -1 || echo "Unknown"; fi)"

# 检查 stress-ng
if ! command -v stress-ng &> /dev/null; then
    echo "✗ 请先安装 stress-ng"
    echo "  Ubuntu/Debian: sudo apt install stress-ng"
    echo "  CentOS/RHEL: sudo yum install stress-ng"
    echo "  macOS: brew install stress-ng"
    exit 1
fi

# 显示 stress-ng 版本信息
STRESS_VERSION=$(stress-ng --version 2>/dev/null | head -1 || echo "Unknown")
echo "[*] stress-ng 版本: $STRESS_VERSION"

# cgroup 功能检查
echo "[*] cgroup 功能诊断:"
if [[ -f /proc/cgroups ]]; then
    echo "    ├─ 可用控制器:"
    cat /proc/cgroups | grep -E "(memory|cpu)" | while read line; do
        echo "        └─ $line"
    done
else
    echo "    ├─ /proc/cgroups 不存在"
fi

# 检查 sudo 权限
if ! sudo -n true 2>/dev/null; then
    echo "✗ 需要 sudo 权限来配置 cgroup"
    echo "  请运行: sudo $0 $@"
    exit 1
fi

# 检查 ionice 是否可用（Linux 系统）
IONICE_AVAILABLE=false
if command -v ionice &> /dev/null && [[ "$(uname)" == "Linux" ]]; then
    IONICE_AVAILABLE=true
fi

# 检测 cgroup 类型
CGROUP_ENABLED=true
if [[ "$DISABLE_CGROUP" == "true" ]]; then
    echo "[*] cgroup 功能已禁用（调试模式）"
    CGROUP_ENABLED=false
elif [[ -f /sys/fs/cgroup/cgroup.controllers ]]; then
    CGROUP_TYPE="v2"
    CGROUP_ROOT="/sys/fs/cgroup"
    echo "[*] 检测到 cgroup $CGROUP_TYPE"
elif [[ -d /sys/fs/cgroup/memory ]]; then
    CGROUP_TYPE="v1"
    CGROUP_ROOT="/sys/fs/cgroup/memory"
    echo "[*] 检测到 cgroup $CGROUP_TYPE"
else
    echo "[!] 警告: 未检测到可用的 cgroup 系统，将仅使用 nice/ionice"
    CGROUP_ENABLED=false
fi

# ======== 内存信息获取 ========
# 获取总内存（MB） - macOS兼容性增强
if [[ "$(uname)" == "Darwin" ]]; then
    # macOS 使用 sysctl 获取内存信息
    TOTAL_MEMORY_BYTES=$(sysctl -n hw.memsize)
    TOTAL_MEMORY_MB=$((TOTAL_MEMORY_BYTES / 1024 / 1024))
    
    # macOS 内存统计较为复杂，使用vm_stat获取
    VM_STAT=$(vm_stat)
    PAGE_SIZE=$(vm_stat | head -1 | grep -o '[0-9]*')
    FREE_PAGES=$(echo "$VM_STAT" | grep "Pages free" | awk '{print $3}' | tr -d '.')
    INACTIVE_PAGES=$(echo "$VM_STAT" | grep "Pages inactive" | awk '{print $3}' | tr -d '.')
    AVAILABLE_PAGES=$((FREE_PAGES + INACTIVE_PAGES))
    AVAILABLE_MEMORY_MB=$(((AVAILABLE_PAGES * PAGE_SIZE) / 1024 / 1024))
    
    echo "[*] macOS 内存检测模式"
elif [[ -f /proc/meminfo ]]; then
    # Linux 标准方式
    TOTAL_MEMORY_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    TOTAL_MEMORY_MB=$((TOTAL_MEMORY_KB / 1024))
    AVAILABLE_MEMORY_KB=$(grep MemAvailable /proc/meminfo | awk '{print $2}' 2>/dev/null || grep MemFree /proc/meminfo | awk '{print $2}')
    AVAILABLE_MEMORY_MB=$((AVAILABLE_MEMORY_KB / 1024))
    echo "[*] Linux 内存检测模式"
elif command -v free &> /dev/null; then
    # free 命令备用方案
    TOTAL_MEMORY_MB=$(free -m | awk 'NR==2{print $2}')
    AVAILABLE_MEMORY_MB=$(free -m | awk 'NR==2{print $7}' 2>/dev/null || free -m | awk 'NR==2{print $4}')
    echo "[*] 通用内存检测模式"
else
    echo "✗ 无法获取内存信息"
    echo "  支持的系统: Linux (proc/meminfo), macOS (sysctl), 通用系统 (free)"
    exit 1
fi

# 计算当前内存占用率
USED_MEMORY_MB=$((TOTAL_MEMORY_MB - AVAILABLE_MEMORY_MB))
CURRENT_MEMORY_PERCENT=$((USED_MEMORY_MB * 100 / TOTAL_MEMORY_MB))

echo "[*] 内存信息:"
echo "    ├─ 总内存: ${TOTAL_MEMORY_MB} MB"
echo "    ├─ 已用内存: ${USED_MEMORY_MB} MB"
echo "    ├─ 可用内存: ${AVAILABLE_MEMORY_MB} MB"
echo "    └─ 当前占用率: ${CURRENT_MEMORY_PERCENT}%"

# 检查是否已经达标
if [[ $CURRENT_MEMORY_PERCENT -ge $TARGET_MEMORY_PERCENT ]]; then
    echo "[✓] 当前内存占用率 (${CURRENT_MEMORY_PERCENT}%) 已达到目标 (${TARGET_MEMORY_PERCENT}%)"
    echo "[*] 无需额外占用内存，程序将持续监控 ${DURATION} 秒"
    NEED_STRESS=false
else
    echo "[*] 需要提升内存占用率从 ${CURRENT_MEMORY_PERCENT}% 到 ${TARGET_MEMORY_PERCENT}%"
    NEED_STRESS=true
fi

# ======== 计算需要申请的内存 ========
if [[ "$NEED_STRESS" == "true" ]]; then
    if [[ "$MEMORY_SIZE" == "auto" ]]; then
        # 自动计算所需内存
        TARGET_MEMORY_MB=$((TOTAL_MEMORY_MB * TARGET_MEMORY_PERCENT / 100))
        NEEDED_MEMORY_MB=$((TARGET_MEMORY_MB - USED_MEMORY_MB))
        
        # 确保不会申请过多内存（留 10% 安全边界）
        MAX_SAFE_MEMORY=$((AVAILABLE_MEMORY_MB * 90 / 100))
        if [[ $NEEDED_MEMORY_MB -gt $MAX_SAFE_MEMORY ]]; then
            NEEDED_MEMORY_MB=$MAX_SAFE_MEMORY
            echo "[!] 警告: 限制申请内存为 ${NEEDED_MEMORY_MB} MB（安全边界）"
        fi
        
        echo "[*] 计算所需申请内存: ${NEEDED_MEMORY_MB} MB"
    else
        # 用户自定义内存大小
        # 处理用户自定义内存大小，增加兼容性
        if command -v bc &> /dev/null; then
            NEEDED_MEMORY_MB=$(echo "$MEMORY_SIZE" | sed 's/[gG]/*1024/' | sed 's/[mM]//' | bc 2>/dev/null || echo "0")
        else
            # 不使用bc时的处理方式
            case "${MEMORY_SIZE^^}" in
                *G) 
                    NEEDED_MEMORY_MB=$(( $(echo "$MEMORY_SIZE" | sed 's/[gG]//') * 1024 ))
                    ;;
                *M)
                    NEEDED_MEMORY_MB=$(echo "$MEMORY_SIZE" | sed 's/[mM]//')
                    ;;
                *)
                    NEEDED_MEMORY_MB=$(echo "$MEMORY_SIZE" | grep -o '[0-9]*' | head -1)
                    ;;
            esac
        fi
        if [[ $NEEDED_MEMORY_MB -eq 0 ]]; then
            echo "✗ 无效的内存大小格式: $MEMORY_SIZE"
            exit 1
        fi
        echo "[*] 用户指定申请内存: ${NEEDED_MEMORY_MB} MB"
    fi
    
    # 确保至少申请 10MB
    if [[ $NEEDED_MEMORY_MB -lt 10 ]]; then
        NEEDED_MEMORY_MB=10
        echo "[*] 最小申请内存设为: ${NEEDED_MEMORY_MB} MB"
    fi
fi

echo "[*] 目标内存使用率: ${TARGET_MEMORY_PERCENT}%"
echo "[*] 运行时长: ${DURATION}s"
echo "[*] 隔离策略: cgroup ($CGROUP_TYPE) 硬限制 + nice/ionice 软优先级"
echo "[*] Nice 优先级: $NICE_LEVEL"
if [[ "$IONICE_AVAILABLE" == "true" ]]; then
    echo "[*] I/O 调度: Idle 类别"
fi

# ======== 清理函数 ========
cleanup() {
    echo ""
    echo "[*] 正在清理资源..."
    
    # 停止 stress-ng 进程
    if [[ -n "$STRESS_PID" ]]; then
        kill $STRESS_PID 2>/dev/null || true
        wait $STRESS_PID 2>/dev/null || true
    fi
    
    # 停止监控进程
    if [[ -n "$MONITOR_PID" ]]; then
        kill $MONITOR_PID 2>/dev/null || true
    fi
    
    # 清理 cgroup
    if [[ -n "$CGROUP_PATH" && -d "$CGROUP_PATH" ]]; then
        echo "[*] 清理 cgroup: $CGROUP_PATH"
        sudo rmdir "$CGROUP_PATH" 2>/dev/null || true
    fi
    
    echo "[✓] 清理完成"
}

# 设置信号处理
trap cleanup EXIT INT TERM

# ======== 配置 cgroup ========
if [[ "$CGROUP_ENABLED" == "true" ]]; then
    CGROUP_PATH="$CGROUP_ROOT/$GROUP_NAME"
    
    echo "[*] 创建 cgroup: $CGROUP_PATH"
    sudo mkdir -p "$CGROUP_PATH"
    
    if [[ "$CGROUP_TYPE" == "v2" ]]; then
        # cgroup v2 内存限制配置
        MEMORY_LIMIT_BYTES=$((TOTAL_MEMORY_MB * TARGET_MEMORY_PERCENT * 1024 * 1024 / 100))
        echo "[*] 配置 cgroup v2 内存限制: $((MEMORY_LIMIT_BYTES / 1024 / 1024)) MB"
        echo "$MEMORY_LIMIT_BYTES" | sudo tee "$CGROUP_PATH/memory.max" > /dev/null
        
        # 检查是否启用了内存控制器
        if [[ -f "$CGROUP_ROOT/cgroup.subtree_control" ]]; then
            CONTROLLERS=$(cat "$CGROUP_ROOT/cgroup.subtree_control" 2>/dev/null)
            echo "[*] 根cgroup控制器: $CONTROLLERS"
            if [[ "$CONTROLLERS" != *"memory"* ]]; then
                echo "memory" | sudo tee -a "$CGROUP_ROOT/cgroup.subtree_control" > /dev/null 2>&1 || true
                echo "[*] 尝试启用内存控制器"
            fi
        fi
        
    elif [[ "$CGROUP_TYPE" == "v1" ]]; then
        # cgroup v1 内存限制配置
        MEMORY_LIMIT_BYTES=$((TOTAL_MEMORY_MB * TARGET_MEMORY_PERCENT * 1024 * 1024 / 100))
        echo "[*] 配置 cgroup v1 内存限制: $((MEMORY_LIMIT_BYTES / 1024 / 1024)) MB"
        echo "$MEMORY_LIMIT_BYTES" | sudo tee "$CGROUP_PATH/memory.limit_in_bytes" > /dev/null
        
        # 验证配置
        ACTUAL_LIMIT=$(cat "$CGROUP_PATH/memory.limit_in_bytes" 2>/dev/null)
        if [[ -n "$ACTUAL_LIMIT" ]]; then
            ACTUAL_LIMIT_MB=$((ACTUAL_LIMIT / 1024 / 1024))
            echo "[*] 实际 cgroup v1 内存限制: ${ACTUAL_LIMIT_MB} MB"
        fi
    fi
else
    echo "[*] 跳过 cgroup 配置，仅使用 nice/ionice 限制"
fi

# ======== 构建 stress-ng 命令 ========
if [[ "$NEED_STRESS" == "true" ]]; then
    # 架构特定的内存工作进程数计算
    BASE_VM_WORKERS=1
    if [[ $NEEDED_MEMORY_MB -gt 1024 ]]; then
        BASE_VM_WORKERS=2
    fi
    
    # 应用架构优化乘数
    # 检查bc命令是否可用
    if command -v bc &> /dev/null; then
        VM_WORKERS=$(echo "$BASE_VM_WORKERS * $VM_WORKERS_MULTIPLIER" | bc | cut -d. -f1)
    else
        # bc不可用时使用awk进行浮点运算
        VM_WORKERS=$(awk "BEGIN {printf \"%.0f\", $BASE_VM_WORKERS * $VM_WORKERS_MULTIPLIER}")
    fi
    if [[ $VM_WORKERS -lt 1 ]]; then
        VM_WORKERS=1
    fi
    
    echo "[*] 架构优化配置:"
    echo "    ├─ 工作进程数: $VM_WORKERS (基数: $BASE_VM_WORKERS, 乘数: $VM_WORKERS_MULTIPLIER)"
    echo "    ├─ 内存块大小: ${MEMORY_CHUNK_SIZE}MB"
    echo "    └─ ARM优化: $ARM_OPTIMIZED"
    
    # 构建基础命令
    STRESS_CMD="stress-ng --vm $VM_WORKERS --vm-bytes ${NEEDED_MEMORY_MB}M --timeout ${DURATION}s --metrics-brief --vm-keep"
    
    # 添加架构特定的stress-ng方法测试和选择
    echo "[*] 测试 stress-ng 内存方法兼容性..."
    AVAILABLE_VM_METHODS=()
    
    # 测试常用的内存压测方法
    for method in "all" "flip" "zero" "inc" "rnd"; do
        if timeout 2s stress-ng --vm 1 --vm-method "$method" --vm-bytes 10M --timeout 1s --quiet >/dev/null 2>&1; then
            AVAILABLE_VM_METHODS+=("$method")
            echo "    ├─ $method: ✓"
        else
            echo "    ├─ $method: ✗"
        fi
    done
    
    # 选择最佳方法
    if [[ ${#AVAILABLE_VM_METHODS[@]} -gt 0 ]]; then
        # ARM架构优先选择较轻量的方法
        if [[ "$ARM_OPTIMIZED" == "true" ]]; then
            for preferred in "inc" "zero" "all"; do
                for available in "${AVAILABLE_VM_METHODS[@]}"; do
                    if [[ "$available" == "$preferred" ]]; then
                        SELECTED_METHOD="$preferred"
                        break 2
                    fi
                done
            done
        else
            # x86架构优先选择all方法
            for preferred in "all" "rnd" "flip"; do
                for available in "${AVAILABLE_VM_METHODS[@]}"; do
                    if [[ "$available" == "$preferred" ]]; then
                        SELECTED_METHOD="$preferred"
                        break 2
                    fi
                done
            done
        fi
        
        if [[ -n "$SELECTED_METHOD" ]]; then
            STRESS_CMD="$STRESS_CMD --vm-method $SELECTED_METHOD"
            echo "    └─ 选择方法: $SELECTED_METHOD"
        else
            echo "    └─ 使用默认方法"
        fi
    else
        echo "    └─ 警告: 所有方法测试失败，使用默认设置"
    fi
    
    # 添加 nice 和 ionice
    PRIORITY_CMD="nice -n $NICE_LEVEL"
    if [[ "$IONICE_AVAILABLE" == "true" ]]; then
        PRIORITY_CMD="$PRIORITY_CMD ionice -c 3"  # Idle I/O 调度类别
    fi
    
    FINAL_CMD="$PRIORITY_CMD $STRESS_CMD"
    
    echo "=========================================="
    echo "[*] 执行命令: $FINAL_CMD"
    echo "[*] 开始内存压测..."
    echo "=========================================="
    
    # 启动 stress-ng
    echo "[*] 启动 stress-ng 进程..."
    eval "$FINAL_CMD" &
    STRESS_PID=$!
    echo "[*] stress-ng 进程已启动，PID: $STRESS_PID"
    
    # 将进程加入 cgroup
    if [[ "$CGROUP_ENABLED" == "true" ]]; then
        echo "[*] 将主进程 $STRESS_PID 加入 cgroup..."
        sleep 1
        
        if [[ "$CGROUP_TYPE" == "v2" ]]; then
            echo "$STRESS_PID" | sudo tee "$CGROUP_PATH/cgroup.procs" > /dev/null
            if grep -q "^$STRESS_PID$" "$CGROUP_PATH/cgroup.procs" 2>/dev/null; then
                echo "[✓] 主进程成功加入 cgroup v2"
            else
                echo "[✗] 警告: 主进程可能未成功加入 cgroup v2"
            fi
        elif [[ "$CGROUP_TYPE" == "v1" ]]; then
            echo "$STRESS_PID" | sudo tee "$CGROUP_PATH/tasks" > /dev/null
            if grep -q "^$STRESS_PID$" "$CGROUP_PATH/tasks" 2>/dev/null; then
                echo "[✓] 主进程成功加入 cgroup v1"
            else
                echo "[✗] 警告: 主进程可能未成功加入 cgroup v1"
            fi
        fi
        echo "[✓] stress-ng 开始受限执行 (cgroup + nice/ionice)"
    else
        echo "[✓] stress-ng 开始执行 (仅 nice/ionice)"
    fi
else
    echo "=========================================="
    echo "[*] 跳过内存申请，开始监控模式..."
    echo "=========================================="
fi

# ======== 实时监控函数 ========
monitor_memory() {
    echo "[*] 开始监控内存使用情况..."
    local count=0
    local max_samples=$(( DURATION / 5 ))  # 每5秒监控一次
    
    # 如不进行压测，则监控两次快速退出
    if [[ $NEED_STRESS == 'false' ]]; then
      max_samples=2
    else
      # 确保至少监控5次
      if [[ $max_samples -lt 5 ]]; then
        max_samples=5
      fi
    fi

    
    while [[ $count -lt $max_samples ]]; do
        # 如果有stress-ng进程，检查是否还在运行
        if [[ -n "$STRESS_PID" ]]; then
            if ! kill -0 $STRESS_PID 2>/dev/null; then
                echo "[*] stress-ng 进程已结束，继续监控"
                STRESS_PID=""
            fi
        fi
        
        # 获取当前内存使用情况 - 跨平台兼容
        if [[ "$(uname)" == "Darwin" ]]; then
            # macOS 内存监控
            local vm_stat_current=$(vm_stat)
            local free_pages_current=$(echo "$vm_stat_current" | grep "Pages free" | awk '{print $3}' | tr -d '.')
            local inactive_pages_current=$(echo "$vm_stat_current" | grep "Pages inactive" | awk '{print $3}' | tr -d '.')
            local available_pages_current=$((free_pages_current + inactive_pages_current))
            local current_available_mb=$(((available_pages_current * PAGE_SIZE) / 1024 / 1024))
            local current_used_mb=$((TOTAL_MEMORY_MB - current_available_mb))
            local current_percent=$((current_used_mb * 100 / TOTAL_MEMORY_MB))
        elif [[ -f /proc/meminfo ]]; then
            # Linux 标准方式
            local current_available_kb=$(grep MemAvailable /proc/meminfo | awk '{print $2}' 2>/dev/null || grep MemFree /proc/meminfo | awk '{print $2}')
            local current_available_mb=$((current_available_kb / 1024))
            local current_used_mb=$((TOTAL_MEMORY_MB - current_available_mb))
            local current_percent=$((current_used_mb * 100 / TOTAL_MEMORY_MB))
        else
            # 通用 free 命令
            local mem_info=$(free -m | awk 'NR==2{printf "%d %d", $3, $7}')
            local current_used_mb=$(echo $mem_info | awk '{print $1}')
            local current_available_mb=$(echo $mem_info | awk '{print $2}')
            local current_percent=$((current_used_mb * 100 / TOTAL_MEMORY_MB))
        fi
        
        # 输出监控信息
        local timestamp=$(date '+%H:%M:%S')
        local output="[$timestamp] 内存使用: ${current_used_mb}MB (${current_percent}%)"
        output="$output | 可用: ${current_available_mb}MB"
        output="$output | 目标: ${TARGET_MEMORY_PERCENT}%"
        
        # 状态指示
        if [[ $current_percent -ge $TARGET_MEMORY_PERCENT ]]; then
            output="$output | ✓ 已达标"
        else
            local diff=$((TARGET_MEMORY_PERCENT - current_percent))
            output="$output | ⚠ 差${diff}%"
        fi
        
        echo "$output"
        
        # cgroup 使用统计（每10次显示一次）
        if [[ $(( count % 10 )) -eq 0 ]] && [[ "$CGROUP_TYPE" == "v1" ]] && [[ -f "$CGROUP_PATH/memory.usage_in_bytes" ]]; then
            local cgroup_usage=$(cat "$CGROUP_PATH/memory.usage_in_bytes" 2>/dev/null)
            if [[ -n "$cgroup_usage" ]]; then
                local usage_mb=$((cgroup_usage / 1024 / 1024))
                echo "    └─ cgroup 内存使用: ${usage_mb}MB"
            fi
        fi
        
        sleep 5
        ((count++))
    done
    
    echo "[*] 监控结束"
}

# 启动监控（前台运行，确保实时输出）
monitor_memory &
MONITOR_PID=$!

# ======== 等待完成 ========
if [[ -n "$STRESS_PID" ]]; then
    wait $STRESS_PID
    STRESS_EXIT_CODE=$?
else
    # 仅监控模式，等待指定时间
    sleep $DURATION
    STRESS_EXIT_CODE=0
fi

# 停止监控
kill $MONITOR_PID 2>/dev/null || true
wait $MONITOR_PID 2>/dev/null || true

echo "=========================================="
if [[ $STRESS_EXIT_CODE -eq 0 ]]; then
    echo "[✓] 程序成功完成"
else
    echo "[✗] 程序异常退出，退出码: $STRESS_EXIT_CODE"
fi

# ======== 显示最终统计信息 ========
# 获取最终内存使用情况 - 跨平台兼容
if [[ "$(uname)" == "Darwin" ]]; then
    # macOS 最终统计
    FINAL_VM_STAT=$(vm_stat)
    FINAL_FREE_PAGES=$(echo "$FINAL_VM_STAT" | grep "Pages free" | awk '{print $3}' | tr -d '.')
    FINAL_INACTIVE_PAGES=$(echo "$FINAL_VM_STAT" | grep "Pages inactive" | awk '{print $3}' | tr -d '.')
    FINAL_AVAILABLE_PAGES=$((FINAL_FREE_PAGES + FINAL_INACTIVE_PAGES))
    FINAL_AVAILABLE_MB=$(((FINAL_AVAILABLE_PAGES * PAGE_SIZE) / 1024 / 1024))
    FINAL_USED_MB=$((TOTAL_MEMORY_MB - FINAL_AVAILABLE_MB))
    FINAL_PERCENT=$((FINAL_USED_MB * 100 / TOTAL_MEMORY_MB))
elif [[ -f /proc/meminfo ]]; then
    # Linux 标准方式
    FINAL_AVAILABLE_KB=$(grep MemAvailable /proc/meminfo | awk '{print $2}' 2>/dev/null || grep MemFree /proc/meminfo | awk '{print $2}')
    FINAL_AVAILABLE_MB=$((FINAL_AVAILABLE_KB / 1024))
    FINAL_USED_MB=$((TOTAL_MEMORY_MB - FINAL_AVAILABLE_MB))
    FINAL_PERCENT=$((FINAL_USED_MB * 100 / TOTAL_MEMORY_MB))
else
    # 通用 free 命令
    FINAL_MEM_INFO=$(free -m | awk 'NR==2{printf "%d %d", $3, $7}')
    FINAL_USED_MB=$(echo $FINAL_MEM_INFO | awk '{print $1}')
    FINAL_AVAILABLE_MB=$(echo $FINAL_MEM_INFO | awk '{print $2}')
    FINAL_PERCENT=$((FINAL_USED_MB * 100 / TOTAL_MEMORY_MB))
fi

echo "[*] 最终内存统计:"
echo "    ├─ 起始占用率: ${CURRENT_MEMORY_PERCENT}%"
echo "    ├─ 结束占用率: ${FINAL_PERCENT}%"
echo "    ├─ 目标占用率: ${TARGET_MEMORY_PERCENT}%"
echo "    └─ 达标状态: $( [[ $FINAL_PERCENT -ge $TARGET_MEMORY_PERCENT ]] && echo "✓ 已达标" || echo "✗ 未达标" )"

if [[ "$CGROUP_TYPE" == "v1" && -f "$CGROUP_PATH/memory.max_usage_in_bytes" ]]; then
    MAX_USAGE=$(cat "$CGROUP_PATH/memory.max_usage_in_bytes" 2>/dev/null)
    if [[ -n "$MAX_USAGE" ]]; then
        MAX_USAGE_MB=$((MAX_USAGE / 1024 / 1024))
        echo "[*] cgroup 最大内存使用: ${MAX_USAGE_MB}MB"
    fi
fi

echo "=========================================="

# ======== 使用说明 ========
cat << 'EOF'

双重隔离策略说明：
├── cgroup 硬限制: 内核级内存配额控制，防止系统内存耗尽
├── nice 软优先级: 进程调度优先级，减少对系统其他进程的影响
└── ionice I/O优先级: 降低磁盘访问优先级（Linux）

内存分配策略：
├── 智能检测: 自动检测当前内存占用率是否已达标
├── 安全边界: 自动留出10%安全边界，避免系统内存耗尽
└── 持久占用: 使用--vm-keep确保内存持续占用

使用方法：
  sudo ./memory_usage_limit.sh [内存%] [时长s] [nice值] [禁用cgroup] [内存大小]
  
参数说明：
  - 内存%: 1-100，目标内存占用率
  - 时长: 运行持续时间（秒）
  - nice值: -20到19，19为最低优先级
  - 禁用cgroup: true/false，默认false（调试用）
  - 内存大小: auto/具体值（如1G, 500M），auto=自动计算
  
示例：
  sudo ./memory_usage_limit.sh 50 600 19              # 50%占用率，10分钟，最低优先级
  sudo ./memory_usage_limit.sh 30 300 15              # 30%占用率，5分钟
  sudo ./memory_usage_limit.sh 40 600 19 false 1G     # 强制申请1GB内存
  sudo ./memory_usage_limit.sh 60 300 19 true         # 禁用cgroup，仅使用nice/ionice

特性说明：
  - 如果当前内存占用率已达标，程序将切换为监控模式
  - 自动计算所需申请的内存大小，确保达到目标占用率
  - 实时监控内存使用情况，每5秒输出一次状态
  - 支持cgroup v1/v2两种版本的内存限制

EOF