# CMDB V2 项目需求文档

**项目状态**: 🚀 主要功能已完成，持续迭代中

**最新更新 (v0.4.0)**:
- ✅ 统一所有页面默认时间范围为3个月
- ✅ 重构管理页面为模块化子组件架构
- ✅ 增强表格筛选和搜索功能
- ✅ 完善监控数据核对功能

---

我需要做两个页面，页面的代码放在 cmdb_frontend_v2 目录下的前端项目代码中。相关依赖的接口，代码放在 cmdb_backend 项目中实现。

这两个新页面均作为当前 App.js 页面的选项卡，第一个页面作为一个常驻的选项卡，第二个页面”集群有效性报告“，默认不可见，当点击第一个页面中的”集群有效性报告“按钮时，才显示它，并且在第一个页面中点击不同集群的”集群有效性报告“按钮时，始终只显示一个”集群有效性报告页面“并根据点击的集群刷新集群有效性报告页面的内容，刷新页面过程中，提供加载动画。

- 第一个页面：集群资源用量报告
	- 页面数据源
		- 本页面需要的数据源为一个接口，请帮我按照这个数据返回格式在cmdb_backend项目中生成一个接口
			- 接口地址 /api/cmdb/v1/cluster-resource-summary
			- 接口的数据来源于数据库中的 server_resources 表
			- 接口返回包括以下json字段：部门、团队、集群名称、集群IP地址列表、服务器类型、最大CPU、平均CPU、最大内存、平均内存、最大磁盘、平均磁盘
	- 页面构成
		- 筛选框，支持以下几个筛选维度：
			1. 集群组
			2. 集群
			3. 部门
			4. 开始日期：指集群资源使用率数据的开始时间
			5. 结束日期：指集群资源使用率数据的结束时间
			6. 阈值设定，支持分别设置 CPU利用率、硬盘利用率、内存利用率 的最高和最低阈值
		- 复选框
			1. 选择是否只显示不达标集群的数据
		- 在一排用4个方块，分别显示：当前筛选出的集群数量、主机数量、资源利用率阈值达标集群数量和所属集群的主机数量、不达标集群数量和所属集群的主机数量
		- 用一个表格以集群维度列出数据
			1. 数据列包括：集群组名、集群名、所属部门、CPU峰值利用率、硬盘峰值利用率、内存峰值利用率（利用率数据达标绿色，不达标红色），集群有效性报告（这个报告将打开另一个页面，稍后我们再实现这个页面）
			2. 所有的数据列均支持点击列名排序，支持分页显示（参考”主机资源用量分析“页面的”资源警报详情“分页表格的风格和功能实现）

- 第二个页面：集群有效性报告
	- 页面数据源
		- 本页面显示的表格数据，来源于表 backup_restore_check_info，它的表结构如下，请帮我按照这个数据返回格式在cmdb_backend项目中生成一个接口
			- 表结构
			~~~sql
						CREATE TABLE `backup_restore_check_info` (
			  `id` int(11) NOT NULL AUTO_INCREMENT,
			  `check_seq` varchar(20) NOT NULL COMMENT '检查轮次',
			  `check_db` varchar(50) NOT NULL COMMENT '检查数据库集群',
			  `check_src_ip` varchar(50) NOT NULL COMMENT '备份IP',
			  `db_backup_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			  `db_backup_date` varchar(20) NOT NULL COMMENT '备份日期',
			  `backup_name` varchar(200) NOT NULL COMMENT '备份文件名',
			  `db_restore_begin_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '恢复开始时间',
			  `check_dst_ip` varchar(50) NOT NULL COMMENT '恢复IP',
			  `check_app` varchar(50) NOT NULL COMMENT '恢复业务',
			  `check_db_type` varchar(20) NOT NULL COMMENT '数据库架构',
			  `db_app_line` varchar(50) NOT NULL COMMENT '数据库应用团队',
			  `db_restore_end_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '恢复结束时间',
			  `backup_check_result` varchar(10) NOT NULL DEFAULT 'OK',
			  PRIMARY KEY (`id`) ,
			  UNIQUE KEY `uq_seq` (`check_seq`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ;
			~~~
			- 接口返回字段，均来自于上述backup_restore_check_info数据表
				1. id
				2. 检查序列
				3. 集群名称
				4. 检查源IP
				5. 备份时间
				6. 备份集名称
				7. 恢复时间
				8. 检查目标ip
				9. 应用名称
				10. 业务名称
				11. 恢复结束时间
				12. 恢复验证结果
			
		- 本页面”其他详情“按钮，需要的数据源为一个接口，请帮我按照这个数据返回格式在cmdb_backend项目中生成一个接口
			- 接口地址 /api/cmdb/v1/cluster_confirm_summary
			- 接口数据来源于数据库中的表 backup_restore_check_info、plugin_execution_records、cluster_groups、server_resources、cluster_group，需要联合这些表来获取接口所需的数据。backup_restore_check_info 里有一个 check_src_ip 字段，表示数据库的ip地址，你可以用这个地址从server_resource表中关联到具体的机器，然后继续用 server_resources 表中的 cluster_name 关联到 cluster_groups表中获得集群组关系。
			- 接口返回数据包括以下所有字段：
				1. 数据库恢复报告文件地址，word 文件
				2. 其他相关的检查插件的运行结果内容
	- 页面构成		
		- 页面用于显示具体集群的有效性检查历史和结果，以表格形式展示，表格有以下字段：
			1. id
			2. 检查序列
			3. 集群名称
			4. 检查源IP
			5. 备份时间
			6. 备份集名称
			7. 恢复时间
			8. 检查目标ip
			9. 应用名称
			10. 业务名称
			11. 恢复结束时间
			12. 恢复验证结果
			13. 其他详情，插件运行结果，此项结果将显示一个按钮，点击将请求后端的API接口获取数据，并弹出一个窗口显示数据，数据为多个键值对，键是插件的名称，值是插件的运行结果，结果是一个 json 格式的数据，应在页面进行json的格式化展示