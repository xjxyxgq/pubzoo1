import React, { useState, useEffect } from 'react';
import { Layout, Tabs } from 'antd';
import HostList from './components/hostPoolSubPage/HostPoolList';
import DatabaseClusterAnalysis from './components/HostResourceUsageanAlysis';
import ClusterResourceReport from './components/ClusterResourceUsageReport';
import ClusterValidityReport from './components/ClusterValidityReport';
import AdminManagement from './components/AdminManagement';
import HardwareResourceVerification from './components/HardwareResourceVerification';
import './App.css';

const { Header, Content } = Layout;
const { TabPane } = Tabs;

const App = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showValidityReport, setShowValidityReport] = useState(false);
  const [validityReportCluster, setValidityReportCluster] = useState('');
  const [activeKey, setActiveKey] = useState('1');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  const formatTime = (date) => {
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).replace(/\//g, '-');
  };

  const handleShowValidityReport = (clusterName) => {
    setValidityReportCluster(clusterName);
    setShowValidityReport(true);
    setActiveKey('4');
  };

  const handleTabChange = (key) => {
    setActiveKey(key);
    // 如果从集群有效性报告选项卡切换到其他选项卡，隐藏集群有效性报告
    if (key !== '4') {
      setShowValidityReport(false);
    }
  };

  return (
    <Layout className="layout">
      <Header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ color: 'white', margin: 0 }}>数据库主机资源池</h1>
        <span style={{ color: 'white' }}>{formatTime(currentTime)}</span>
      </Header>
      <Content style={{ padding: '0 50px' }}>
        <div className="site-layout-content">
          <Tabs activeKey={activeKey} onChange={handleTabChange}>
            <TabPane tab="主机资源池" key="1">
              <HostList />
            </TabPane>
            <TabPane tab="主机资源用量分析" key="2">
              <DatabaseClusterAnalysis />
            </TabPane>
            <TabPane tab="集群资源用量报告" key="3">
              <ClusterResourceReport onShowValidityReport={handleShowValidityReport} />
            </TabPane>
            {showValidityReport && (
              <TabPane tab="集群有效性报告" key="4">
                <ClusterValidityReport clusterName={validityReportCluster} />
              </TabPane>
            )}
            <TabPane tab="系统管理" key="5">
              <AdminManagement />
            </TabPane>
            <TabPane tab="硬件资源验证" key="6">
              <HardwareResourceVerification />
            </TabPane>
          </Tabs>
        </div>
      </Content>
    </Layout>
  );
}

export default App;
