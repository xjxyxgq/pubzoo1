import axios from 'axios';
import React from 'react';
import ReactDOM from 'react-dom';
import { Modal, Spin, Typography, Progress } from 'antd';
import moment from 'moment';

const { Text, Paragraph } = Typography;

const API_BASE_URL = 'https://api.siliconflow.cn/v1/chat/completions';
const API_KEY = process.env.REACT_APP_DEEPSEEK_API_KEY;

const buildAnalysisPrompt = (clusterData) => {
  const serverDetails = clusterData.servers.map(server => `
    - 主机名: ${server.hostname}
      内存: ${server.used_memory}/${server.total_memory}GB (${((server.used_memory/server.total_memory)*100).toFixed(2)}%)
      CPU: ${server.cpu_load}%
      磁盘: ${server.used_disk}/${server.total_disk}GB (${((server.used_disk/server.total_disk)*100).toFixed(2)}%)
  `).join('\n');

  return `请分析以下数据库集群的硬件使用情况并给出扩缩容建议：
集群名称: ${clusterData.clusterName}
集群概况:
- 平均CPU使用率: ${clusterData.cpu.toFixed(2)}%
- 平均内存使用率: ${clusterData.memory.toFixed(2)}%
- 平均磁盘使用率: ${clusterData.disk.toFixed(2)}%
- 总内存: ${clusterData.memoryTotal}GB
- 总磁盘: ${clusterData.diskTotal}GB

详细主机列表:
${serverDetails}

请用JSON格式返回分析结果，包含以下字段：
{
  "analysis": "简要分析（包含具体数值）",
  "suggestions": ["基于具体数据的扩缩容建议"],
  "riskAssessment": "风险评估（引用具体指标）",
  "recommendedAction": "推荐操作步骤"
}`;
};

// 创建一个用于挂载弹出层的DOM节点
const createModalContainer = () => {
    const div = document.createElement('div');
    div.id = 'api-response-modal';
    document.body.appendChild(div);
    return div;
};

// 显示API响应弹出层
const showResponseModal = () => {
    const modalRef = {
        startTime: moment(),
        timer: null,
        instance: null,
        updateTimer: function(setProgress) {
            const duration = moment().diff(this.startTime, 'seconds');
            setProgress(duration);
            this.timer = setTimeout(() => this.updateTimer(setProgress), 1000);
        }
    };

    const modal = Modal.info({
        title: 'AI分析进行中...',
        width: 800,
        maskClosable: false,
        content: (
            <ApiResponseDisplay 
                onMount={setProgress => {
                    modalRef.updateTimer(setProgress);
                }}
                onUnmount={() => {
                    if (modalRef.timer) clearTimeout(modalRef.timer);
                }}
            />
        ),
        onOk: () => {
            if (modalRef.timer) clearTimeout(modalRef.timer);
            modalRef.instance?.destroy();
        }
    });

    modalRef.instance = modal;
    return modalRef;
};

// API响应显示组件
const ApiResponseDisplay = ({ onMount, onUnmount, response, error }) => {
    const [progress, setProgress] = React.useState(0);

    React.useEffect(() => {
        onMount(setProgress);
        return () => onUnmount();
    }, []);

    return (
        <div style={{ maxHeight: '60vh', overflow: 'auto' }}>
            {!response && !error && (
                <div style={{ textAlign: 'center', padding: '20px' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: '20px' }}>
                        <Progress 
                            type="circle" 
                            percent={100} 
                            format={() => `${progress}s`}
                        />
                    </div>
                </div>
            )}
            {response && (
                <div>
                    <Text type="success">分析完成 (用时: {progress}秒)</Text>
                    <Paragraph>
                        <pre style={{ 
                            background: '#f6f8fa', 
                            padding: '16px',
                            borderRadius: '6px',
                            maxHeight: '400px',
                            overflow: 'auto'
                        }}>
                            {typeof response === 'string' 
                                ? response 
                                : JSON.stringify(response, null, 2)}
                        </pre>
                    </Paragraph>
                </div>
            )}
            {error && (
                <div>
                    <Text type="danger">请求失败 (用时: {progress}秒)</Text>
                    <Paragraph>
                        <pre style={{ 
                            background: '#fff2f0', 
                            padding: '16px',
                            borderRadius: '6px'
                        }}>
                            {error.toString()}
                        </pre>
                    </Paragraph>
                </div>
            )}
        </div>
    );
};

// 修改sendAnalysisRequest函数
export const sendAnalysisRequest = async (clusterData) => {
    const modalRef = showResponseModal();
    const setModalContent = (response, error = null) => {
        modalRef.instance.update({
            content: (
                <ApiResponseDisplay
                    response={response}
                    error={error}
                    onMount={setProgress => {
                        modalRef.updateTimer(setProgress);
                    }}
                    onUnmount={() => {
                        if (modalRef.timer) clearTimeout(modalRef.timer);
                    }}
                />
            )
        });
    };

    try {
        // 使用axios的timeout配置
        const response = await axios.post(API_BASE_URL, {
            model: "deepseek-ai/DeepSeek-V3",
            messages: [
                {
                    role: "system",
                    content: "你是一个专业的数据库运维专家，擅长分析硬件资源使用情况并提供优化建议"
                },
                {
                    role: "user",
                    content: buildAnalysisPrompt(clusterData)
                }
            ],
            stream: false,
            max_tokens: 512,
            temperature: 0.7,
            top_p: 0.7,
            top_k: 50,
            frequency_penalty: 0.5,
            response_format: { type: "text" }
        }, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            },
            // 设置较长的超时时间，比如2分钟
            timeout: 240000
        });

        const resultText = response.data.choices[0].message.content;
        // 处理返回的Markdown格式JSON字符串
        const cleanJsonText = resultText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
        try {
            const parsedResult = JSON.parse(cleanJsonText);
            setModalContent(parsedResult);
            return parsedResult;
        } catch (parseError) {
            console.error('JSON解析失败，原始文本:', resultText);
            console.error('清理后文本:', cleanJsonText);
            setModalContent(null, `返回数据格式错误: ${parseError.message}\n原始返回:\n${resultText}`);
            throw new Error('返回数据格式错误');
        }
    } catch (error) {
        // 如果是网络请求错误
        let errorMessage;
        if (error.response?.data) {
            errorMessage = `错误代码: ${error.response.data.code}, 错误信息: ${error.response.data.message}`;
        } else if (error.code === 'ECONNABORTED') {
            errorMessage = '请求超时（4分钟），请稍后重试';
        } else {
            errorMessage = '分析请求失败: ' + (error.message || '未知错误');
        }
        setModalContent(null, errorMessage);
        throw new Error(errorMessage);
    }
};

export const executeClusterAction = async (action) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/cluster/execute-action`, action, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || '操作执行失败');
  }
};

// 其他可能的API函数... 