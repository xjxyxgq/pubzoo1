import React, { useState, useEffect } from 'react';
import { 
  Card, 
  InputNumber, 
  Button, 
  Upload, 
  message, 
  Table, 
  Modal, 
  Tag, 
  Typography, 
  Spin,
  Icon,
  Input,
  Row,
  Col
} from 'antd';

const { Title, Text } = Typography;
const { Dragger } = Upload;

const DiskResourceVerification = () => {
  const [loading, setLoading] = useState(false);
  const [statusLoading, setStatusLoading] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState([]);
  const [historyModalVisible, setHistoryModalVisible] = useState(false);
  const [historyData, setHistoryData] = useState([]);
  const [selectedHostIp, setSelectedHostIp] = useState('');
  const [historyLoading, setHistoryLoading] = useState(false);
  
  // 执行详情Modal状态
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [currentRecord, setCurrentRecord] = useState(null);
  
  // 表单状态
  const [targetPercent, setTargetPercent] = useState(30);
  const [duration, setDuration] = useState(600);
  const [targetPath, setTargetPath] = useState('/tmp');
  const [hostIpList, setHostIpList] = useState([]);
  const [fileUploaded, setFileUploaded] = useState(false);

  // 获取验证状态
  const fetchVerificationStatus = async () => {
    setStatusLoading(true);
    try {
      const response = await fetch('/api/cmdb/v1/hardware-resource-verification-status?resource_type=disk');
      const result = await response.json();
      
      if (result.success) {
        setVerificationStatus(result.verification_records || []);
      } else {
        message.error(result.message || '获取验证状态失败');
      }
    } catch (error) {
      message.error('请求失败: ' + error.message);
    } finally {
      setStatusLoading(false);
    }
  };

  // 获取历史记录
  const fetchHistoryData = async (hostIp) => {
    setHistoryLoading(true);
    try {
      const response = await fetch(`/api/cmdb/v1/hardware-resource-verification-history?host_ip=${hostIp}&resource_type=disk`);
      const result = await response.json();
      
      if (result.success) {
        setHistoryData(result.history_records || []);
      } else {
        message.error(result.message || '获取历史记录失败');
      }
    } catch (error) {
      message.error('请求失败: ' + error.message);
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    fetchVerificationStatus();
    // 定时刷新状态
    const interval = setInterval(() => {
      fetchVerificationStatus();
    }, 10000); // 每10秒刷新一次

    return () => clearInterval(interval);
  }, []);

  // 处理文件上传
  const handleFileUpload = (file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      const lines = text.split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0);
      
      // 简单IP格式验证
      const validIpPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
      const validIps = lines.filter(line => validIpPattern.test(line));
      
      if (validIps.length === 0) {
        message.error('文件中没有找到有效的IP地址');
        return;
      }
      
      setHostIpList(validIps);
      setFileUploaded(true);
      message.success(`成功读取到 ${validIps.length} 个有效IP地址`);
    };
    reader.readAsText(file);
    return false; // 阻止自动上传
  };

  // 提交验证请求
  const handleSubmit = async () => {
    // 验证表单数据
    if (!targetPercent || targetPercent < 1 || targetPercent > 95) {
      message.error('请输入有效的磁盘占用率 (1-95)');
      return;
    }
    
    if (!duration || duration < 60) {
      message.error('执行持续时间至少60秒');
      return;
    }
    
    if (!targetPath || targetPath.trim() === '') {
      message.error('请输入目标测试目录');
      return;
    }
    
    if (!fileUploaded || hostIpList.length === 0) {
      message.error('请先上传包含主机IP的文件');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/cmdb/v1/hardware-resource-verification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          host_ip_list: hostIpList,
          resource_type: 'disk',
          target_percent: targetPercent,
          duration: duration,
          script_params: JSON.stringify({
            nice_level: "19",
            target_path: targetPath
          })
        }),
      });

      const result = await response.json();
      
      if (result.success) {
        message.success(`磁盘验证任务已提交，任务ID: ${result.task_id}`);
        // 重置表单
        setTargetPercent(30);
        setDuration(600);
        setTargetPath('/tmp');
        setHostIpList([]);
        setFileUploaded(false);
        setTimeout(() => {
          fetchVerificationStatus();
        }, 1000);
      } else {
        message.error(result.message || '提交失败');
      }
    } catch (error) {
      message.error('请求失败: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  // 查看历史记录
  const showHistory = (hostIp) => {
    setSelectedHostIp(hostIp);
    setHistoryModalVisible(true);
    fetchHistoryData(hostIp);
  };

  // 显示执行详情
  const showExecutionDetail = (record) => {
    setCurrentRecord(record);
    setDetailModalVisible(true);
  };

  // 状态标签颜色映射
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'blue';
      case 'running': return 'orange';
      case 'completed': return 'green';
      case 'failed': return 'red';
      default: return 'default';
    }
  };

  // 状态文本映射
  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return '待执行';
      case 'running': return '执行中';
      case 'completed': return '已完成';
      case 'failed': return '执行失败';
      default: return status;
    }
  };

  // 验证状态表格列定义
  const statusColumns = [
    {
      title: '主机IP',
      dataIndex: 'host_ip',
      key: 'host_ip',
      render: (text) => (
        <Button type="link" onClick={() => showHistory(text)}>
          {text}
        </Button>
      ),
    },
    {
      title: '执行状态',
      dataIndex: 'execution_status',
      key: 'execution_status',
      render: (status) => (
        <Tag color={getStatusColor(status)}>
          {getStatusText(status)}
        </Tag>
      ),
    },
    {
      title: '目标阈值',
      dataIndex: 'target_percent',
      key: 'target_percent',
      render: (percent) => `${percent}%`,
    },
    {
      title: '执行结果',
      dataIndex: 'result_summary',
      key: 'result_summary',
      render: (summary) => {
        if (!summary) return '-';
        try {
          const result = JSON.parse(summary);
          return result.success ? (
            <Tag color="success">成功</Tag>
          ) : (
            <Tag color="error">失败</Tag>
          );
        } catch {
          return '-';
        }
      },
    },
    {
      title: '最后执行时间',
      dataIndex: 'create_time',
      key: 'create_time',
      render: (time) => time ? new Date(time).toLocaleString() : '-',
    },
  ];

  // 历史记录表格列定义
  const historyColumns = [
    {
      title: '任务ID',
      dataIndex: 'task_id',
      key: 'task_id',
      ellipsis: true,
    },
    {
      title: '目标阈值',
      dataIndex: 'target_percent',
      key: 'target_percent',
      render: (percent) => `${percent}%`,
    },
    {
      title: '持续时间',
      dataIndex: 'duration',
      key: 'duration',
      render: (duration) => `${duration}秒`,
    },
    {
      title: '执行状态',
      dataIndex: 'execution_status',
      key: 'execution_status',
      render: (status) => (
        <Tag color={getStatusColor(status)}>
          {getStatusText(status)}
        </Tag>
      ),
    },
    {
      title: '退出代码',
      dataIndex: 'exit_code',
      key: 'exit_code',
      render: (code) => code || '-',
    },
    {
      title: '执行时间',
      dataIndex: 'create_time',
      key: 'create_time',
      render: (time) => time ? new Date(time).toLocaleString() : '-',
    },
  ];

  return (
    <div>
      <Card title="磁盘资源验证配置" style={{ marginBottom: 24 }}>
        <Row gutter={[16, 16]}>
          <Col span={24}>
            <label style={{ fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>
              预期磁盘空间占用率 (%)
            </label>
            <InputNumber
              value={targetPercent}
              onChange={setTargetPercent}
              style={{ width: '100%' }}
              placeholder="请输入1-95之间的数值"
              min={1}
              max={95}
            />
          </Col>
          
          <Col span={24}>
            <label style={{ fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>
              执行持续时间 (秒)
            </label>
            <InputNumber
              value={duration}
              onChange={setDuration}
              style={{ width: '100%' }}
              placeholder="默认600秒（10分钟）"
              min={60}
            />
          </Col>
          
          <Col span={24}>
            <label style={{ fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>
              目标测试目录
            </label>
            <Input
              value={targetPath}
              onChange={(e) => setTargetPath(e.target.value)}
              placeholder="默认 /tmp，确保目录存在且有写权限"
            />
          </Col>
          
          <Col span={24}>
            <label style={{ fontWeight: 'bold', marginBottom: '8px', display: 'block' }}>
              主机IP列表文件 {fileUploaded && <Tag color="green">已上传 {hostIpList.length} 个IP</Tag>}
            </label>
            <Dragger
              name="file"
              accept=".txt,.csv"
              beforeUpload={handleFileUpload}
              showUploadList={false}
            >
              <p className="ant-upload-drag-icon">
                <Icon type="inbox" />
              </p>
              <p className="ant-upload-text">点击或拖拽文件到此区域上传</p>
              <p className="ant-upload-hint">
                支持单个文件上传，文件格式为 .txt 或 .csv，每行一个IP地址
              </p>
            </Dragger>
          </Col>
          
          <Col span={24}>
            <Button 
              type="primary" 
              onClick={handleSubmit}
              loading={loading}
              size="large"
              style={{ width: '100%' }}
              disabled={!fileUploaded}
            >
              <Icon type="play-circle" />
              提交磁盘验证任务
            </Button>
          </Col>
        </Row>
      </Card>

      <Card title="验证状态" extra={
        <Button onClick={fetchVerificationStatus} loading={statusLoading}>
          <Icon type="reload" />
          刷新状态
        </Button>
      }>
        <Spin spinning={statusLoading}>
          <Table
            dataSource={verificationStatus}
            columns={statusColumns}
            rowKey="id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: '暂无验证记录' }}
          />
        </Spin>
      </Card>

      <Modal
        title={`主机 ${selectedHostIp} 的磁盘验证历史记录`}
        visible={historyModalVisible}
        onCancel={() => setHistoryModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setHistoryModalVisible(false)}>
            关闭
          </Button>
        ]}
        width={1000}
      >
        <Spin spinning={historyLoading}>
          <Table
            dataSource={historyData}
            columns={historyColumns}
            rowKey="id"
            pagination={{ pageSize: 10 }}
            locale={{ emptyText: '暂无历史记录' }}
          />
        </Spin>
      </Modal>

      {/* 执行详情Modal */}
      <Modal
        title="执行详情"
        visible={detailModalVisible}
        onCancel={() => setDetailModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setDetailModalVisible(false)}>
            关闭
          </Button>
        ]}
        width={800}
      >
        {currentRecord && (
          <div>
            <Row gutter={[16, 16]}>
              <Col span={24}>
                <Text strong>任务信息:</Text>
                <div style={{ marginLeft: 16, marginTop: 8 }}>
                  <p><Text strong>任务ID:</Text> {currentRecord.task_id}</p>
                  <p><Text strong>主机IP:</Text> {currentRecord.host_ip}</p>
                  <p><Text strong>执行状态:</Text> 
                    <Tag color={getStatusColor(currentRecord.execution_status)} style={{ marginLeft: 8 }}>
                      {getStatusText(currentRecord.execution_status)}
                    </Tag>
                  </p>
                  <p><Text strong>退出代码:</Text> {currentRecord.exit_code || '-'}</p>
                  <p><Text strong>开始时间:</Text> {currentRecord.start_time || '-'}</p>
                  <p><Text strong>结束时间:</Text> {currentRecord.end_time || '-'}</p>
                </div>
              </Col>
              
              {currentRecord.result_summary && (
                <Col span={24}>
                  <Text strong>执行结果摘要:</Text>
                  <div style={{ marginTop: 8, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
                    <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>
                      {currentRecord.result_summary}
                    </pre>
                  </div>
                </Col>
              )}
              
              {currentRecord.stdout_log && (
                <Col span={24}>
                  <Text strong>标准输出:</Text>
                  <div style={{ marginTop: 8, padding: 12, backgroundColor: '#f6ffed', border: '1px solid #b7eb8f', borderRadius: 4, maxHeight: 300, overflow: 'auto' }}>
                    <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>
                      {currentRecord.stdout_log}
                    </pre>
                  </div>
                </Col>
              )}
              
              {currentRecord.stderr_log && (
                <Col span={24}>
                  <Text strong>标准错误:</Text>
                  <div style={{ marginTop: 8, padding: 12, backgroundColor: '#fff2f0', border: '1px solid #ffccc7', borderRadius: 4, maxHeight: 300, overflow: 'auto' }}>
                    <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>
                      {currentRecord.stderr_log}
                    </pre>
                  </div>
                </Col>
              )}
              
              {currentRecord.ssh_error && (
                <Col span={24}>
                  <Text strong>SSH错误:</Text>
                  <div style={{ marginTop: 8, padding: 12, backgroundColor: '#fff1f0', border: '1px solid #ffa39e', borderRadius: 4 }}>
                    <pre style={{ margin: 0, fontSize: 12, whiteSpace: 'pre-wrap' }}>
                      {currentRecord.ssh_error}
                    </pre>
                  </div>
                </Col>
              )}
            </Row>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default DiskResourceVerification;