// 磁盘空间预测组件
import React from 'react';
import { Table } from 'antd';
import { getTextColumnSearchProps, getNumberRangeFilterProps, getColumnSorter, getPercentageValue, getDateRangeFilterProps } from '../../utils/tableUtils';

export const getDiskPredictionColumns = () => [
  {
    title: 'ID',
    dataIndex: 'id',
    ...getTextColumnSearchProps('id', 'ID'),
    ...getColumnSorter('id'),
  },
  {
    title: 'IP',
    dataIndex: 'ip',
    ...getTextColumnSearchProps('ip', 'IP地址'),
    ...getColumnSorter('ip'),
  },
  {
    title: 'Cluster Name',
    dataIndex: 'cluster_name',
    ...getTextColumnSearchProps('cluster_name', '集群名称'),
    ...getColumnSorter('cluster_name'),
  },
  {
    title: 'Current Disk Usage',
    dataIndex: 'current_disk_usage',
    ...getNumberRangeFilterProps('current_disk_usage', '%', (record) => {
      const usage = getPercentageValue(record, 'used_disk', 'total_disk');
      return isNaN(usage) ? 0 : usage;
    }),
    sorter: (a, b) => {
      const aUsage = getPercentageValue(a, 'used_disk', 'total_disk');
      const bUsage = getPercentageValue(b, 'used_disk', 'total_disk');
      return aUsage - bUsage;
    },
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usage = getPercentageValue(record, 'used_disk', 'total_disk');
      return `${usage.toFixed(2)}%`;
    },
  },
  {
    title: 'Predicted Full Date',
    dataIndex: 'predicted_full_date',
    ...getDateRangeFilterProps('predicted_full_date', (record) => {
      const usageRate = (record.used_disk / record.total_disk) / 30;
      const daysUntilFull = (1 - (record.used_disk / record.total_disk)) / usageRate;
      return new Date(new Date().getTime() + daysUntilFull * 24 * 60 * 60 * 1000);
    }),
    sorter: (a, b) => {
      const getFullDate = (record) => {
        const usageRate = (record.used_disk / record.total_disk) / 30;
        const daysUntilFull = (1 - (record.used_disk / record.total_disk)) / usageRate;
        return new Date(new Date().getTime() + daysUntilFull * 24 * 60 * 60 * 1000);
      };
      return getFullDate(a).getTime() - getFullDate(b).getTime();
    },
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usageRate = (record.used_disk / record.total_disk) / 30;
      const daysUntilFull = (1 - (record.used_disk / record.total_disk)) / usageRate;
      const fullDate = new Date(new Date().getTime() + daysUntilFull * 24 * 60 * 60 * 1000);
      return fullDate.toLocaleDateString();
    },
  },
];

const DiskFullPrediction = ({ data, pagination = true }) => {
  return (
    <Table
      columns={getDiskPredictionColumns()}
      dataSource={data}
      rowKey={(record) => `${record.id}-${record.ip}`}
      pagination={{
        showSizeChanger: true,
        showQuickJumper: true,
        pageSizeOptions: ['5', '20', '50', '100', '500'],
        defaultPageSize: 5,
      }}
    />
  );
}

export default DiskFullPrediction;