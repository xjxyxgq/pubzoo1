// 主机资源详情组件
import React, { useState } from 'react';
import { Table, Button, DatePicker, Alert, Spin, Modal, message } from 'antd';
import { getTextColumnSearchProps, getNumberRangeFilterProps, getColumnSorter, getPercentageValue, getDateRangeFilterProps } from '../../utils/tableUtils';
import moment from 'moment';
import axios from 'axios';

// 主机详细指标数据弹出界面组件
const HostMetricsModal = ({ visible, onCancel, hostIp, dateRange }) => {
  const [loading, setLoading] = useState(false);
  const [metricsData, setMetricsData] = useState([]);
  const [originalData, setOriginalData] = useState([]);
  const [sortedInfo, setSortedInfo] = useState({});
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8888';

  const fetchHostMetrics = async (page = 1, pageSize = 10) => {
    if (!hostIp) return;
    
    setLoading(true);
    try {
      const params = {
        ip: hostIp,
        page,
        pageSize,
      };
      
      if (dateRange && dateRange[0] && dateRange[1]) {
        params.startDate = dateRange[0].format('YYYY-MM-DD');
        params.endDate = dateRange[1].format('YYYY-MM-DD');
      } else {
        params.startDate = moment().subtract(3, 'months').format('YYYY-MM-DD');
        params.endDate = moment().format('YYYY-MM-DD');
      }

      const response = await axios.get(`${backendUrl}/api/cmdb/v1/server-resources`, { params });
      const data = Array.isArray(response.data) ? response.data : (response.data.list || []);
      
      // 过滤出指定IP的数据
      const filteredData = data.filter(item => item.ip === hostIp || item.ip_address === hostIp);
      
      setOriginalData(filteredData);
      setMetricsData(filteredData);
      setSortedInfo({}); // 重置排序状态
      setPagination(prev => ({
        ...prev,
        current: page,
        pageSize,
        total: filteredData.length,
      }));
    } catch (error) {
      console.error('获取主机指标数据失败:', error);
      message.error('获取主机指标数据失败');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (visible && hostIp) {
      fetchHostMetrics(pagination.current, pagination.pageSize);
    }
  }, [visible, hostIp, dateRange]);

  // 生成唯一的 rowKey
  const generateRowKey = (record, index) => {
    // 尝试多种方式生成唯一ID
    if (record.id) return String(record.id);
    
    const parts = [
      record.ip || record.ip_address || 'ip',
      record.host_name || 'host',
      record.date_time || new Date().toISOString(),
      String(record.cpu_load || 0),
      String(record.used_memory || 0),
      String(index)
    ];
    
    // 创建一个基于内容的哈希码
    const hashCode = parts.join('-').split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    return `host-${Math.abs(hashCode)}-${index}`;
  };

  const columns = [
    {
      title: 'IP地址',
      dataIndex: 'ip',
      key: 'ip',
      render: (value, record) => value || record.ip_address,
    },
    {
      title: 'CPU负载 (%)',
      dataIndex: 'cpu_load',
      key: 'cpu_load',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'cpu_load' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
    },
    {
      title: '已用内存 (GB)',
      dataIndex: 'used_memory',
      key: 'used_memory',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'used_memory' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '总内存 (GB)',
      dataIndex: 'total_memory',
      key: 'total_memory',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'total_memory' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '内存使用率 (%)',
      key: 'memory_usage',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'memory_usage' && sortedInfo.order,
      render: (_, record) => {
        const usage = getPercentageValue(record, 'used_memory', 'total_memory');
        return `${usage.toFixed(2)}%`;
      },
    },
    {
      title: '已用磁盘 (GB)',
      dataIndex: 'used_disk',
      key: 'used_disk',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'used_disk' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '总磁盘 (GB)',
      dataIndex: 'total_disk',
      key: 'total_disk',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'total_disk' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '磁盘使用率 (%)',
      key: 'disk_usage',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'disk_usage' && sortedInfo.order,
      render: (_, record) => {
        const usage = getPercentageValue(record, 'used_disk', 'total_disk');
        return `${usage.toFixed(2)}%`;
      },
    },
    {
      title: '时间戳',
      dataIndex: 'date_time',
      key: 'date_time',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'date_time' && sortedInfo.order,
      render: (value) => {
        if (!value) return 'N/A';
        const date = new Date(value);
        return isNaN(date.getTime()) ? value : date.toLocaleString();
      },
    },
  ];

  // 客户端排序函数
  const sortData = (data, sorter) => {
    // 如果没有排序器、没有列键或没有排序方向，返回原始数据
    if (!sorter || !sorter.columnKey || !sorter.order) {
      console.log('No sorting applied, returning original data');
      return [...data]; // 返回数组副本避免引用问题
    }

    return [...data].sort((a, b) => {
      let aVal, bVal;
      
      // 根据不同的列类型处理排序值
      switch (sorter.columnKey) {
        case 'memory_usage':
          aVal = getPercentageValue(a, 'used_memory', 'total_memory');
          bVal = getPercentageValue(b, 'used_memory', 'total_memory');
          break;
        case 'disk_usage':
          aVal = getPercentageValue(a, 'used_disk', 'total_disk');
          bVal = getPercentageValue(b, 'used_disk', 'total_disk');
          break;
        case 'date_time':
          aVal = new Date(a.date_time || 0).getTime();
          bVal = new Date(b.date_time || 0).getTime();
          break;
        default:
          // 数值字段
          aVal = Number(a[sorter.columnKey]) || 0;
          bVal = Number(b[sorter.columnKey]) || 0;
          break;
      }

      if (sorter.order === 'ascend') {
        return aVal - bVal;
      } else {
        return bVal - aVal;
      }
    });
  };

  const handleTableChange = (paginationConfig, filters, sorter) => {
    console.log('=== HostMetricsModal Table Change Event ===');
    console.log('Pagination:', paginationConfig);
    console.log('Filters:', filters);
    console.log('Sorter:', sorter);
    console.log('Original data length:', originalData.length);
    console.log('Current metrics data length:', metricsData.length);
    
    // 检查排序参数
    if (sorter && sorter.columnKey) {
      console.log('Sorting by:', sorter.columnKey, 'Order:', sorter.order);
      
      // 显示前几条数据用于调试
      console.log('Sample original data:', originalData.slice(0, 3).map(item => ({
        [sorter.columnKey]: item[sorter.columnKey],
        ip: item.ip || item.ip_address
      })));
    }
    
    // 更新排序状态
    setSortedInfo(sorter || {});
    
    // 应用排序
    const sortedData = sortData(originalData, sorter);
    console.log('Sorted data length:', sortedData.length);
    
    if (sorter && sorter.columnKey && sortedData.length > 0) {
      console.log('Sample sorted data:', sortedData.slice(0, 3).map(item => ({
        [sorter.columnKey]: item[sorter.columnKey],
        ip: item.ip || item.ip_address
      })));
    }
    
    setMetricsData(sortedData);
    
    // 更新分页信息
    setPagination(prev => ({
      ...prev,
      current: paginationConfig.current,
      pageSize: paginationConfig.pageSize,
    }));
    
    console.log('=== End Table Change Event ===');
  };

  return (
    <Modal
      title={`主机 ${hostIp} 的详细监控数据`}
      visible={visible}
      onCancel={onCancel}
      footer={[
        <Button key="close" onClick={onCancel}>
          关闭
        </Button>
      ]}
      width={1200}
      destroyOnClose
    >
      <Table
        columns={columns}
        dataSource={metricsData}
        loading={loading}
        sortDirections={['ascend', 'descend']}
        showSorterTooltip={false}
        pagination={{
          ...pagination,
          showSizeChanger: true,
          showQuickJumper: true,
          pageSizeOptions: ['10', '20', '50', '100'],
          showTotal: (total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条记录`,
        }}
        onChange={handleTableChange}
        rowKey={generateRowKey}
        scroll={{ x: 1000 }}
      />
    </Modal>
  );
};

export const getHostResourceDetailColumns = (onIpClick) => [
  { 
    title: 'ID', 
    dataIndex: 'id',
    ...getTextColumnSearchProps('id', 'ID'),
    ...getColumnSorter('id'),
  },
  { 
    title: 'Cluster Name', 
    dataIndex: 'cluster_name',
    ...getTextColumnSearchProps('cluster_name', '集群名称'),
    ...getColumnSorter('cluster_name'),
  },
  { 
    title: 'Group Name', 
    dataIndex: 'group_name',
    ...getTextColumnSearchProps('group_name', '组名'),
    ...getColumnSorter('group_name'),
  },
  { 
    title: 'IP', 
    dataIndex: 'ip',
    ...getTextColumnSearchProps('ip', 'IP地址'),
    ...getColumnSorter('ip'),
    render: (value, record) => {
      const ip = value || record.ip_address;
      return (
        <Button 
          type="link" 
          style={{ padding: 0, height: 'auto' }}
          onClick={() => onIpClick && onIpClick(ip)}
        >
          {ip}
        </Button>
      );
    },
  },
  { 
    title: 'Port', 
    dataIndex: 'port',
    ...getNumberRangeFilterProps('port'),
    ...getColumnSorter('port'),
  },
  { 
    title: 'Instance Role', 
    dataIndex: 'instance_role',
    ...getTextColumnSearchProps('instance_role', '实例角色'),
    ...getColumnSorter('instance_role'),
  },
  { 
    title: 'Total Memory (GB)', 
    dataIndex: 'total_memory',
    ...getNumberRangeFilterProps('total_memory', 'GB'),
    ...getColumnSorter('total_memory'),
    render: (value) => value ? value.toFixed(2) : '0.00',
  },
  { 
    title: 'Used Memory (GB)', 
    dataIndex: 'used_memory',
    ...getNumberRangeFilterProps('used_memory', 'GB'),
    ...getColumnSorter('used_memory'),
    render: (value) => value ? value.toFixed(2) : '0.00',
  },
  {
    title: 'Memory Usage (%)',
    dataIndex: ['used_memory', 'total_memory'],
    ...getNumberRangeFilterProps('memory_usage', '%', (record) => getPercentageValue(record, 'used_memory', 'total_memory')),
    sorter: (a, b) => getPercentageValue(a, 'used_memory', 'total_memory') - getPercentageValue(b, 'used_memory', 'total_memory'),
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usage = getPercentageValue(record, 'used_memory', 'total_memory');
      return `${usage.toFixed(2)}%`;
    },
  },
  { 
    title: 'Total Disk (GB)', 
    dataIndex: 'total_disk',
    ...getNumberRangeFilterProps('total_disk', 'GB'),
    ...getColumnSorter('total_disk'),
    render: (value) => value ? value.toFixed(2) : '0.00',
  },
  { 
    title: 'Used Disk (GB)', 
    dataIndex: 'used_disk',
    ...getNumberRangeFilterProps('used_disk', 'GB'),
    ...getColumnSorter('used_disk'),
    render: (value) => value ? value.toFixed(2) : '0.00',
  },
  {
    title: 'Disk Usage (%)',
    dataIndex: ['used_disk', 'total_disk'],
    ...getNumberRangeFilterProps('disk_usage', '%', (record) => getPercentageValue(record, 'used_disk', 'total_disk')),
    sorter: (a, b) => getPercentageValue(a, 'used_disk', 'total_disk') - getPercentageValue(b, 'used_disk', 'total_disk'),
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usage = getPercentageValue(record, 'used_disk', 'total_disk');
      return `${usage.toFixed(2)}%`;
    },
  },
  { 
    title: 'CPU Cores', 
    dataIndex: 'cpu_cores',
    ...getNumberRangeFilterProps('cpu_cores'),
    ...getColumnSorter('cpu_cores'),
  },
  { 
    title: 'CPU Load (%)', 
    dataIndex: 'cpu_load',
    ...getNumberRangeFilterProps('cpu_load', '%'),
    ...getColumnSorter('cpu_load'),
    render: (value) => `${value ? value.toFixed(2) : '0.00'}%`,
  },
  { 
    title: 'Date Time', 
    dataIndex: 'date_time',
    ...getDateRangeFilterProps('date_time', (record) => {
      // 处理日期时间字段，支持多种格式
      const dateValue = record.date_time;
      if (!dateValue) return null;
      
      if (dateValue instanceof Date) {
        return dateValue;
      }
      
      if (typeof dateValue === 'string') {
        return new Date(dateValue);
      }
      
      return null;
    }),
    ...getColumnSorter('date_time', (record) => {
      const dateValue = record.date_time;
      if (!dateValue) return new Date(0);
      
      if (dateValue instanceof Date) {
        return dateValue;
      }
      
      if (typeof dateValue === 'string') {
        const date = new Date(dateValue);
        return isNaN(date.getTime()) ? new Date(0) : date;
      }
      
      return new Date(0);
    }),
    render: (value) => {
      if (!value) return 'N/A';
      
      if (value instanceof Date) {
        return value.toLocaleString();
      }
      
      if (typeof value === 'string') {
        const date = new Date(value);
        return isNaN(date.getTime()) ? value : date.toLocaleString();
      }
      
      return String(value);
    },
  },
];

const HostResourceDetail = ({ 
  data, 
  pagination = true, 
  dateRange, 
  onDateChange,
  refreshData,
  error,
  loading
}) => {
  const { RangePicker } = DatePicker;
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedHostIp, setSelectedHostIp] = useState(null);

  const handleIpClick = (ip) => {
    setSelectedHostIp(ip);
    setModalVisible(true);
  };

  const handleModalClose = () => {
    setModalVisible(false);
    setSelectedHostIp(null);
  };
  
  return (
    <div>
      {onDateChange && (
        <div style={{ marginBottom: 16 }}>
          <RangePicker 
            value={dateRange}
            onChange={onDateChange}
            style={{ marginRight: 16 }}
          />
          <Button 
            type="primary" 
            onClick={refreshData}
            loading={loading}
          >
            刷新数据
          </Button>
        </div>
      )}
      
      {error && (
        <Alert
          message="数据加载错误"
          description={error}
          type="error"
          showIcon
          style={{ marginBottom: 16 }}
        />
      )}
      
      <Spin spinning={loading}>
        <Table 
          columns={getHostResourceDetailColumns(handleIpClick)} 
          dataSource={data} 
          rowKey={(record) => `${record.id || record.ip}-${record.date_time || Date.now()}`} 
          pagination={pagination ? {
            showSizeChanger: true,
            showQuickJumper: true,
            pageSizeOptions: ['5', '20', '50', '100', '500'],
            defaultPageSize: 5,
          } : false}
          locale={{
            emptyText: error ? '加载失败' : (loading ? '加载中...' : '暂无数据')
          }}
        />
      </Spin>

      <HostMetricsModal
        visible={modalVisible}
        onCancel={handleModalClose}
        hostIp={selectedHostIp}
        dateRange={dateRange}
      />
    </div>
  );
};

export default HostResourceDetail;
