// 资源警报详情组件
import React, { useMemo } from 'react';
import { Table } from 'antd';
import { getTextColumnSearchProps, getNumberRangeFilterProps, getColumnSorter, getPercentageValue } from '../../utils/tableUtils';

export const getResourceAlertsColumns = (cpuMin, cpuMax, memoryMin, memoryMax, diskMin, diskMax) => [
  {
    title: 'ID',
    dataIndex: 'id',
    ...getTextColumnSearchProps('id', 'ID'),
    ...getColumnSorter('id'),
  },
  {
    title: 'IP',
    dataIndex: 'ip',
    ...getTextColumnSearchProps('ip', 'IP地址'),
    ...getColumnSorter('ip'),
  },
  {
    title: 'Cluster Name',
    dataIndex: 'cluster_name',
    ...getTextColumnSearchProps('cluster_name', '集群名称'),
    ...getColumnSorter('cluster_name'),
  },
  {
    title: 'CPU Usage',
    dataIndex: 'cpu_load',
    ...getNumberRangeFilterProps('cpu_load', '%'),
    ...getColumnSorter('cpu_load'),
    render: (value) => {
      const text = `${value.toFixed(2)}%`;
      const color = value < cpuMin ? 'green' : value > cpuMax ? 'red' : 'inherit';
      return <span style={{ color }}>{text}</span>;
    },
  },
  {
    title: 'Memory Usage',
    dataIndex: 'memory_usage',
    ...getNumberRangeFilterProps('memory_usage', '%', (record) => {
      const usage = getPercentageValue(record, 'used_memory', 'total_memory');
      return isNaN(usage) ? 0 : usage;
    }),
    sorter: (a, b) => {
      const aUsage = getPercentageValue(a, 'used_memory', 'total_memory');
      const bUsage = getPercentageValue(b, 'used_memory', 'total_memory');
      return aUsage - bUsage;
    },
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usage = getPercentageValue(record, 'used_memory', 'total_memory');
      const text = `${usage.toFixed(2)}%`;
      const color = usage < memoryMin ? 'green' : usage > memoryMax ? 'red' : 'inherit';
      return <span style={{ color }}>{text}</span>;
    },
  },
  {
    title: 'Disk Usage',
    dataIndex: 'disk_usage',
    ...getNumberRangeFilterProps('disk_usage', '%', (record) => {
      const usage = getPercentageValue(record, 'used_disk', 'total_disk');
      return isNaN(usage) ? 0 : usage;
    }),
    sorter: (a, b) => {
      const aUsage = getPercentageValue(a, 'used_disk', 'total_disk');
      const bUsage = getPercentageValue(b, 'used_disk', 'total_disk');
      return aUsage - bUsage;
    },
    sortDirections: ['descend', 'ascend'],
    render: (_, record) => {
      const usage = getPercentageValue(record, 'used_disk', 'total_disk');
      const text = `${usage.toFixed(2)}%`;
      const color = usage < diskMin ? 'green' : usage > diskMax ? 'red' : 'inherit';
      return <span style={{ color }}>{text}</span>;
    },
  },
];

const ResourceAlerts = ({ data, cpuThresholds, memoryThresholds, diskThresholds, triggerUpdate, pagination = true }) => {
  const filteredData = useMemo(() => {
    return data.filter(item => {
      const cpuUsage = item.cpu_load;
      const memoryUsage = (item.used_memory / item.total_memory) * 100;
      const diskUsage = (item.used_disk / item.total_disk) * 100;
      
      const cpuCompliant = cpuUsage >= cpuThresholds.min && cpuUsage <= cpuThresholds.max;
      const memoryCompliant = memoryUsage >= memoryThresholds.min && memoryUsage <= memoryThresholds.max;
      const diskCompliant = diskUsage >= diskThresholds.min && diskUsage <= diskThresholds.max;
      
      return !cpuCompliant || !memoryCompliant || !diskCompliant;
    });
  }, [data, cpuThresholds, memoryThresholds, diskThresholds]);

  return (
    <Table
      columns={getResourceAlertsColumns(
        cpuThresholds.min, 
        cpuThresholds.max, 
        memoryThresholds.min, 
        memoryThresholds.max, 
        diskThresholds.min, 
        diskThresholds.max
      )}
      dataSource={filteredData}
      rowKey={(record) => `${record.id}-${record.ip}`}
      pagination={{
        showSizeChanger: true,
        showQuickJumper: true,
        pageSizeOptions: ['5', '20', '50', '100', '500'],
        defaultPageSize: 5,
      }}
    />
  );
}

export default ResourceAlerts;
