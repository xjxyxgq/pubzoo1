import React, { useState } from 'react';
import { Typography, Icon, Menu, Layout } from 'antd';
import ClusterGroupSync from './adminManagmentSubPage/ClusterGroupSync';
import ServerMetricsLoader from './adminManagmentSubPage/ServerMetricsLoader';
import MonitoringVerification from './adminManagmentSubPage/MonitoringVerification';

const { Title } = Typography;
const { Sider, Content } = Layout;

const AdminManagement = () => {
  const [selectedMenu, setSelectedMenu] = useState('cluster-sync');


  return (
    <Layout style={{ background: '#fff' }}>
      <Sider width={200} style={{ background: '#fff' }}>
        <Menu
          mode="inline"
          selectedKeys={[selectedMenu]}
          style={{ height: '100%' }}
          onSelect={({ key }) => setSelectedMenu(key)}
        >
          <Menu.Item key="cluster-sync">
            <Icon type="sync" />
            <span>集群组数据同步</span>
          </Menu.Item>
          <Menu.Item key="server-metrics">
            <Icon type="bar-chart" />
            <span>监控指标数据加载</span>
          </Menu.Item>
          <Menu.Item key="monitoring-verification">
            <Icon type="eye" />
            <span>监控数据核对</span>
          </Menu.Item>
        </Menu>
      </Sider>
      <Content style={{ padding: '0 24px', minHeight: 280 }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <Title level={2}>
            <Icon type="setting" style={{ marginRight: '8px', color: '#1890ff' }} />
            系统管理
          </Title>
    </div>
        
        {selectedMenu === 'cluster-sync' && <ClusterGroupSync />}
        {selectedMenu === 'server-metrics' && <ServerMetricsLoader />}
        {selectedMenu === 'monitoring-verification' && <MonitoringVerification />}
      </Content>
    </Layout>
  );
};

export default AdminManagement; 