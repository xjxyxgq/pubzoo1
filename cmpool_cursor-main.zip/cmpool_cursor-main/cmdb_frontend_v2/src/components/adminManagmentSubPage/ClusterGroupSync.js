import React, { useState } from 'react';
import { Button, Card, Typography, message, Spin, Alert, Icon } from 'antd';
import axios from 'axios';

const { Paragraph, Text } = Typography;

const ClusterGroupSync = () => {
  const [loading, setLoading] = useState(false);
  const [syncResult, setSyncResult] = useState(null);

  const handleSyncClusterGroups = async () => {
    setLoading(true);
    setSyncResult(null);
    
    try {
      const response = await axios.post('http://localhost:8888/api/cmdb/v1/sync-cluster-groups');
      
      // 处理成功响应 - 适配实际的API响应格式
      if (response.data.success === true) {
        setSyncResult({
          success: true,
          message: response.data.message,
          syncCount: response.data.synced_count,
          details: response.data.details // 添加详细信息支持
        });
        message.success('集群组数据同步成功！');
      } else {
        throw new Error(response.data.message || '同步失败');
      }
    } catch (error) {
      console.error('同步失败:', error);
      setSyncResult({
        success: false,
        message: error.response?.data?.message || error.message || '网络请求失败'
      });
      message.error('同步失败，请检查后端服务');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Card 
        title={
          <div>
            <Icon type="sync" style={{ marginRight: '8px' }} />
            集群组数据同步
          </div>
        }
        style={{ marginBottom: '16px' }}
      >
        <Paragraph>
          <Text strong>功能说明：</Text>
          <br />
          此功能将从各个集群表（MySQL、MSSQL、TiDB、GoldenDB）中提取集群信息，
          并同步到cluster_groups表中。同步过程包括：
        </Paragraph>

        <div style={{ marginBottom: '16px' }}>
          <div style={{ marginBottom: '8px' }}>• 从mysql_cluster表提取MySQL集群数据</div>
          <div style={{ marginBottom: '8px' }}>• 从mssql_cluster表提取MSSQL集群数据</div>
          <div style={{ marginBottom: '8px' }}>• 从tidb_cluster表提取TiDB集群数据</div>
          <div style={{ marginBottom: '8px' }}>• 从goldendb_cluster表提取GoldenDB集群数据</div>
          <div style={{ marginBottom: '8px' }}>• 根据cluster_group_name查询对应的部门信息</div>
          <div style={{ marginBottom: '8px' }}>• 更新或插入cluster_groups表记录</div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '24px' }}>
          <Button 
            type="primary" 
            size="large"
            loading={loading}
            onClick={handleSyncClusterGroups}
            disabled={loading}
          >
            {loading ? '同步中...' : '开始同步集群组数据'}
          </Button>
        </div>
      </Card>

      {loading && (
        <Card>
          <div style={{ textAlign: 'center', padding: '20px' }}>
            <Spin size="large" />
            <div style={{ marginTop: '16px' }}>
              <Text>正在同步集群组数据，请稍等...</Text>
            </div>
          </div>
        </Card>
      )}

      {syncResult && (
        <Card
          style={{ marginTop: 16 }}
          type={syncResult.success ? 'success' : 'error'}
        >
          <Alert
            type={syncResult.success ? 'success' : 'error'}
            message={syncResult.success ? '同步成功' : '同步失败'}
            description={
              <div>
                <p>{syncResult.message}</p>
                {syncResult.success && syncResult.syncCount > 0 && (
                  <div style={{ marginTop: 12 }}>
                    <p><strong>同步详情：</strong></p>
                    <div style={{ paddingLeft: 16 }}>
                      <p>总同步记录数：<strong>{syncResult.syncCount}</strong></p>
                      {syncResult.details && syncResult.details.length > 0 && (
                        <div>
                          <p>各数据库类型同步情况：</p>
                          <ul style={{ paddingLeft: 20 }}>
                            {syncResult.details.map((detail, index) => (
                              detail.synced_count > 0 && (
                                <li key={index} style={{ marginBottom: 4 }}>
                                  <strong>{detail.database_type.toUpperCase()}</strong>: 
                                  {detail.synced_count} 个集群组
                                  {detail.cluster_groups && detail.cluster_groups.length > 0 && (
                                    <span style={{ color: '#666', fontSize: '12px' }}>
                                      {' '}({detail.cluster_groups.join(', ')})
                                    </span>
                                  )}
                                </li>
                              )
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            }
            showIcon
          />
        </Card>
      )}
    </>
  );
};

export default ClusterGroupSync;