import React, { useState } from 'react';
import { Typography, Icon, Menu, Layout } from 'antd';
import CpuResourceVerification from './hardwareResourceVerificationSubPage/CpuResourceVerification';
import MemoryResourceVerification from './hardwareResourceVerificationSubPage/MemoryResourceVerification';
import DiskResourceVerification from './hardwareResourceVerificationSubPage/DiskResourceVerification';

const { Title } = Typography;
const { Sider, Content } = Layout;

const HardwareResourceVerification = () => {
  const [selectedMenu, setSelectedMenu] = useState('cpu-verification');

  return (
    <Layout style={{ background: '#fff' }}>
      <Sider width={200} style={{ background: '#fff' }}>
        <Menu
          mode="inline"
          selectedKeys={[selectedMenu]}
          style={{ height: '100%' }}
          onSelect={({ key }) => setSelectedMenu(key)}
        >
          <Menu.Item key="cpu-verification">
            <Icon type="dashboard" />
            <span>CPU资源验证</span>
          </Menu.Item>
          <Menu.Item key="memory-verification">
            <Icon type="radar-chart" />
            <span>内存资源验证</span>
          </Menu.Item>
          <Menu.Item key="disk-verification">
            <Icon type="hdd" />
            <span>磁盘资源验证</span>
          </Menu.Item>
        </Menu>
      </Sider>
      <Content style={{ padding: '0 24px', minHeight: 280 }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <Title level={2}>
            <Icon type="experiment" style={{ marginRight: '8px', color: '#1890ff' }} />
            硬件资源验证
          </Title>
        </div>
        
        {selectedMenu === 'cpu-verification' && <CpuResourceVerification />}
        {selectedMenu === 'memory-verification' && <MemoryResourceVerification />}
        {selectedMenu === 'disk-verification' && <DiskResourceVerification />}
      </Content>
    </Layout>
  );
};

export default HardwareResourceVerification;