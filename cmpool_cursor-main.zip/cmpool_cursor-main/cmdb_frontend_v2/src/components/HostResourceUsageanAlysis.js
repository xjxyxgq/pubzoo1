// 主机资源用量分析页
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Select, Layout, Card, Row, Col, Input, Button, message, DatePicker, ConfigProvider, Spin, Alert, Tabs, Checkbox, Statistic, Icon } from 'antd';
import axios from 'axios';
import html2canvas from 'html2canvas';
import Alerts from './hostResourceUsageSubPage/Alerts';
import ResourceAlerts from './hostResourceUsageSubPage/ResourceAlerts';
import DiskFullPrediction from './hostResourceUsageSubPage/DiskFullPrediction';
//import ResourceUsageTrend from './hostResourceUsageSubPage/ResourceUsageTrend.js';
//import PerformanceAnomalyDetection from './hostResourceUsageSubPage/PerformanceAnomalyDetection';
import moment, { now } from 'moment';
import 'moment/locale/zh-cn';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import * as XLSX from 'xlsx';
import { getResourceAlertsColumns } from './hostResourceUsageSubPage/ResourceAlerts';
import { getDiskPredictionColumns } from './hostResourceUsageSubPage/DiskFullPrediction';
//import { getResourceTrendColumns } from './hostResourceUsageSubPage/ResourceUsageTrend.js';
//import { getAnomalyDetectionColumns } from './hostResourceUsageSubPage/PerformanceAnomalyDetection';
import GeographicDistribution from './hostResourceUsageSubPage/GeographicDistribution';
import { sendAnalysisRequest, executeClusterAction } from '../services/deepseekApi';
import ClusterResourceUsage from './clusterResourceSubPage/ClusterResourceUsage';
import HostResourceDetail from './hostResourceUsageSubPage/HostResourceDetail';

const { Content } = Layout;
const { RangePicker } = DatePicker;
const { Option } = Select;

moment.locale('zh-cn');

const DatabaseClusterAnalysis = () => {
    const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8888';
    const [clusterGroups, setClusterGroups] = useState([]);
    const [selectedGroups, setSelectedGroups] = useState([]);
    const [selectedClusters, setSelectedClusters] = useState([]);
    const [selectedDepartments, setSelectedDepartments] = useState([]);
    const [serverResources, setServerResources] = useState([]);
    const [dateRange, setDateRange] = useState(null);
    const [cpuThresholds, setCpuThresholds] = useState({ min: 10, max: 80 });
    const [memoryThresholds, setMemoryThresholds] = useState({ min: 10, max: 80 });
    const [diskThresholds, setDiskThresholds] = useState({ min: 10, max: 80 });
    const [showOnlyNonCompliant, setShowOnlyNonCompliant] = useState(false);
    const [triggerUpdate, setTriggerUpdate] = useState(0);
    const [emailAddress, setEmailAddress] = useState('');
    const contentRef = useRef(null);
    const [analysisResult, setAnalysisResult] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisError, setAnalysisError] = useState(null);
    const [selectedCluster, setSelectedCluster] = useState(null);
    const [dataLoadingError, setDataLoadingError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    
    // 统计数据
    const [stats, setStats] = useState({
        totalClusters: 0,
        totalHosts: 0,
        compliantClusters: 0,
        compliantHosts: 0,
        nonCompliantClusters: 0,
        nonCompliantHosts: 0
    });
    
    // 移除别名，直接使用对应的阈值对象
    
    useEffect(() => {
            axios.get(`${backendUrl}/api/cmdb/v1/cluster-groups`)
        .then(response => {
            let clusterGroupsList = [];
            
            // 处理不同的数据结构
            if (Array.isArray(response.data)) {
                clusterGroupsList = response.data;
            } else if (response.data && response.data.list) {
                clusterGroupsList = response.data.list;
            } else if (response.data && response.data.data) {
                clusterGroupsList = response.data.data;
            } else {
                console.warn('未知的集群组数据格式:', response.data);
                clusterGroupsList = [];
            }
            
            setClusterGroups(clusterGroupsList);
        })
        .catch(error => {
            console.error('Error fetching cluster groups:', error);
            setClusterGroups([]);
        });

        fetchServerResources();
    }, []);

    // 设置默认日期范围为最近3个月
    useEffect(() => {
        const endDate = moment();
        const startDate = moment().subtract(3, 'months');
        setDateRange([startDate, endDate]);
    }, []);

    const fetchServerResources = (startDate, endDate) => {
        const params = {};
        if (startDate && endDate) {
            params.startDate = startDate.format('YYYY-MM-DD');
            params.endDate = endDate.format('YYYY-MM-DD');
        } else {
            params.startDate = "1986-04-02";
            params.endDate = moment().add(1, 'day').format('YYYY-MM-DD');
        }

        setServerResources([]); // 清空当前数据
        setDataLoadingError(null); // 清空之前的错误
        setIsLoading(true);
        message.loading({ content: '正在加载数据...', key: 'loadingData' });

        axios.get(`${backendUrl}/api/cmdb/v1/server-resources`, { params })
            .then(response => {
                setIsLoading(false);
                
                // 检查API是否返回了错误信息
                if (response.data && response.data.success === false) {
                    setDataLoadingError(response.data.message || '获取数据失败，但服务器未提供具体错误信息');
                    message.error({ content: response.data.message || '获取数据失败', key: 'loadingData', duration: 4 });
                    return;
                }
                
                const serverResourcesList = Array.isArray(response.data) 
                    ? response.data 
                    : (response.data.list || []);
                setServerResources(serverResourcesList);
                message.success({ content: '数据加载成功', key: 'loadingData', duration: 2 });
            })
            .catch(error => {
                setIsLoading(false);
                console.error('Error fetching server resources:', error);
                const errorMessage = error.response?.data?.message || '数据加载失败，请检查网络连接或联系管理员';
                setDataLoadingError(errorMessage);
                message.error({ content: errorMessage, key: 'loadingData', duration: 4 });
            });
    };

    const handleGroupChange = (value) => {
        setSelectedGroups(value);
    };

    const handleClusterChange = (value) => {
        setSelectedClusters(value);
    };

    const handleDepartmentChange = (value) => {
        setSelectedDepartments(value);
    };

    const handleCpuThresholdChange = (type, value) => {
        setCpuThresholds(prev => ({
            ...prev,
            [type]: value
        }));
        setTriggerUpdate(prev => prev + 1);
    };

    const handleMemoryThresholdChange = (type, value) => {
        setMemoryThresholds(prev => ({
            ...prev,
            [type]: value
        }));
        setTriggerUpdate(prev => prev + 1);
    };

    const handleDiskThresholdChange = (type, value) => {
        setDiskThresholds(prev => ({
            ...prev,
            [type]: value
        }));
        setTriggerUpdate(prev => prev + 1);
    };

    const handleShowNonCompliantChange = (e) => {
        setShowOnlyNonCompliant(e.target.checked);
    };

    const updateStats = (data) => {
        // 按集群聚合数据来计算集群统计
        const clusterStats = data.reduce((acc, resource) => {
            const clusterName = resource.cluster_name || '未知集群';
            if (!acc[clusterName]) {
                acc[clusterName] = [];
            }
            acc[clusterName].push(resource);
            return acc;
        }, {});

        const totalClusters = Object.keys(clusterStats).length;
        const totalHosts = data.length;

        // 计算达标和不达标的集群
        let compliantClusters = 0;
        let compliantHosts = 0;
        let nonCompliantClusters = 0;
        let nonCompliantHosts = 0;

        Object.entries(clusterStats).forEach(([clusterName, hosts]) => {
            let clusterCompliant = true;
            let clusterCompliantHostCount = 0;

            hosts.forEach(host => {
                const cpuUsage = Number(host.cpu_load) || 0;
                const memoryUsage = (Number(host.used_memory) / Number(host.total_memory)) * 100 || 0;
                const diskUsage = (Number(host.used_disk) / Number(host.total_disk)) * 100 || 0;

                const cpuCompliant = cpuUsage >= cpuThresholds.min && cpuUsage <= cpuThresholds.max;
                const memoryCompliant = memoryUsage >= memoryThresholds.min && memoryUsage <= memoryThresholds.max;
                const diskCompliant = diskUsage >= diskThresholds.min && diskUsage <= diskThresholds.max;

                const hostCompliant = cpuCompliant && memoryCompliant && diskCompliant;
                if (hostCompliant) {
                    clusterCompliantHostCount++;
                } else {
                    clusterCompliant = false;
                }
            });

            if (clusterCompliant) {
                compliantClusters++;
                compliantHosts += hosts.length;
            } else {
                nonCompliantClusters++;
                nonCompliantHosts += hosts.length;
            }
        });

        setStats({
            totalClusters,
            totalHosts,
            compliantClusters,
            compliantHosts,
            nonCompliantClusters,
            nonCompliantHosts
        });
    };

    const handleDateRangeChange = (dates, dateStrings) => {
        setDateRange(dates);
        if (dates) {
            fetchServerResources(dates[0], dates[1]);
        } else {
            fetchServerResources();
        }
    };

    const filteredData = useMemo(() => {
        let filtered = serverResources.filter(resource => {
            const groupMatch = selectedGroups.length === 0 || selectedGroups.includes(resource.group_name);
            const clusterMatch = selectedClusters.length === 0 || selectedClusters.includes(resource.cluster_name);
            const departmentMatch = selectedDepartments.length === 0 || selectedDepartments.includes(resource.department_name);
            return groupMatch && clusterMatch && departmentMatch;
        });

        // 按阈值筛选
        if (showOnlyNonCompliant) {
            filtered = filtered.filter(resource => {
                const cpuUsage = Number(resource.cpu_load) || 0;
                const memoryUsage = (Number(resource.used_memory) / Number(resource.total_memory)) * 100 || 0;
                const diskUsage = (Number(resource.used_disk) / Number(resource.total_disk)) * 100 || 0;
                
                const cpuCompliant = cpuUsage >= cpuThresholds.min && cpuUsage <= cpuThresholds.max;
                const memoryCompliant = memoryUsage >= memoryThresholds.min && memoryUsage <= memoryThresholds.max;
                const diskCompliant = diskUsage >= diskThresholds.min && diskUsage <= diskThresholds.max;
                
                return !cpuCompliant || !memoryCompliant || !diskCompliant;
            });
        }

        return filtered;
    }, [serverResources, selectedGroups, selectedClusters, selectedDepartments, showOnlyNonCompliant, cpuThresholds, memoryThresholds, diskThresholds]);

    // 获取过滤后的唯一集群列表
    const filteredClusters = useMemo(() => {
        const uniqueClusters = new Set(filteredData.map(item => item.cluster_name));
        return Array.from(uniqueClusters);
    }, [filteredData]);



    const handleSendEmail = async () => {
        if (!emailAddress) {
            message.error('请输入邮件地址');
            return;
        }

        if (contentRef.current) {
            try {
                const canvas = await html2canvas(document.body);
                const imageDataUrl = canvas.toDataURL('image/png');
          
                const emailContent = `
                  <html>
                    <body style="font-family: Arial, sans-serif;">
                      <h1 style="color: #333;">服务器资源使用情况报告</h1>
                      <p>以下是当前服务器资源使用情况的截图：</p>
                      <img src="${imageDataUrl}" alt="Server Resources" style="max-width: 100%;" />
                    </body>
                  </html>
                `;
          
                const response = await axios.post(`${backendUrl}/api/cmdb/v1/send-email`, {
                  to: emailAddress,
                  subject: '服务器资源使用情况报告',
                  content: emailContent
                });
          
                if (response.data.success) {
                  message.success('邮件发送成功');
                } else {
                  message.error('邮件发送失败');
                }
              } catch (error) {
                console.error('发送邮件时出错：', error);
                message.error('邮件发送失败');
              }
        }
    };

    const filteredDepartments = clusterGroups.filter(group => {
        return selectedGroups.length === 0 || selectedGroups.includes(group.group_name);
    }).map(group => group.department_name);

    let uniqueClusterGroups = Array.from(new Set(clusterGroups
        .filter(group => group && (group.group_name || group.groupName || group.name))
        .map(group => group.group_name || group.groupName || group.name)
        .filter(Boolean)
    ));
    
    // 如果集群组数据为空，尝试从服务器资源数据中提取
    if (uniqueClusterGroups.length === 0 && serverResources.length > 0) {
        uniqueClusterGroups = Array.from(new Set(serverResources
            .filter(resource => resource && (resource.group_name || resource.team))
            .map(resource => resource.group_name || resource.team)
            .filter(Boolean)
        ));
    }
    
    const uniqueClusters = Array.from(new Set(serverResources
        .filter(resource => resource && resource.cluster_name)
        .map(resource => resource.cluster_name)
        .filter(Boolean)
    ));
    const uniqueDepartments = Array.from(new Set(filteredDepartments.filter(Boolean)));
    

    // 修改导出函数，使其使用表格组件的实际数据和列
    const exportToExcel = (columns, dataSource, fileName) => {
        const exportData = dataSource.map(record => {
            const row = {};
            columns.forEach(col => {
                if (col.dataIndex) {
                    let value;
                    if (Array.isArray(col.dataIndex)) {
                        // 处理复合字段
                        value = col.render ? col.render(null, record) : record[col.dataIndex[0]];
                    } else {
                        // 处理单一字段
                        value = col.render ? col.render(record[col.dataIndex], record) : record[col.dataIndex];
                    }
                    // 如果值是 React 元素（带有颜色的 span），则提取其文本内容
                    if (value && value.props && value.props.children) {
                        value = value.props.children;
                    }
                    row[col.title] = value;
                }
            });
            return row;
        });
        
        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        XLSX.writeFile(wb, `${fileName}.xlsx`);
    };

    // 为每个表格添加导出按钮的渲染函数
    const renderExportButton = (onClick) => (
        <Button
            type="primary"
            size="small"
            onClick={onClick}
            style={{ float: 'right', marginLeft: '10px' }}
        >
            导出Excel
        </Button>
    );

    // 添加一个过滤函数来获取超过阈值的数据
    const getFilteredAlertData = (data) => {
        return data.filter(item => {
            const cpuUsage = item.cpu_load;
            const memoryUsage = (item.used_memory / item.total_memory) * 100;
            const diskUsage = (item.used_disk / item.total_disk) * 100;
            
            const cpuCompliant = cpuUsage >= cpuThresholds.min && cpuUsage <= cpuThresholds.max;
            const memoryCompliant = memoryUsage >= memoryThresholds.min && memoryUsage <= memoryThresholds.max;
            const diskCompliant = diskUsage >= diskThresholds.min && diskUsage <= diskThresholds.max;
            
            return !cpuCompliant || !memoryCompliant || !diskCompliant;
        });
    };

    // 修改资源警报详情的导出处理函数
    const handleExportResourceAlerts = () => {
        const columns = getResourceAlertsColumns(cpuThresholds.min, cpuThresholds.max, memoryThresholds.min, memoryThresholds.max, diskThresholds.min, diskThresholds.max);
        // 使用过滤后的数据而不是所有数据
        const filteredAlertData = getFilteredAlertData(filteredData);
        exportToExcel(columns, filteredAlertData, '资源警报详情');
    };

    const handleExportDiskPrediction = () => {
        const columns = getDiskPredictionColumns();
        exportToExcel(columns, filteredData, '磁盘空间预测');
    };

    // const handleExportResourceTrend = () => {
    //     const columns = getResourceTrendColumns();
    //     exportToExcel(columns, filteredData, '资源使用趋势');
    // };

    // const handleExportAnomalyDetection = () => {
    //     const columns = getAnomalyDetectionColumns();
    //     exportToExcel(columns, filteredData, '性能异常检测');
    // };

    const handleExportServerResource = () => {
        const columns = [
            { title: '集群名称', dataIndex: 'cluster_name' },
            { title: '主机名称', dataIndex: 'host_name' },
            { title: 'IP地址', dataIndex: 'ip_address' },
            { title: '部门', dataIndex: 'department_name' },
            { title: 'CPU利用率', dataIndex: 'cpu_load' },
            { title: '内存利用率', dataIndex: 'used_memory' },
            { title: '磁盘利用率', dataIndex: 'used_disk' },
            { title: '总内存', dataIndex: 'total_memory' },
            { title: '总磁盘', dataIndex: 'total_disk' },
            { title: '操作系统', dataIndex: 'os_type' },
            { title: '主机类型', dataIndex: 'host_type' },
            { title: '部署环境', dataIndex: 'deployment_environment' },
            { title: '集群组', dataIndex: 'group_name' },
            { title: '备注', dataIndex: 'notes' },
            { title: '创建时间', dataIndex: 'created_at' },
            { title: '更新时间', dataIndex: 'updated_at' },
        ];
        exportToExcel(columns, filteredData, '服务器资源详情');
    };

    const handleAnalyzeCluster = async () => {
        if (!selectedCluster) {
            message.error('请先选择要分析的集群');
            return;
        }

        // 从 filteredData 中获取选中集群的数据
        const clusterServers = filteredData.filter(s => s.cluster_name === selectedCluster);
        
        if (clusterServers.length === 0) {
            message.error('选中的集群没有可用数据');
            return;
        }

        // 计算集群的聚合数据
        const clusterData = {
            clusterName: selectedCluster,
            groupName: clusterServers[0]?.group_name || '未分组',
            servers: clusterServers,
            nodeCount: clusterServers.length
        };
        
        
        setIsAnalyzing(true);
        try {
            const response = await sendAnalysisRequest(clusterData);
            
            if (response.suggestions) {
                setAnalysisResult(response);
            } else {
                console.warn('API返回数据格式异常:', response);
                setAnalysisError('分析结果格式不符合预期');
            }
        } catch (error) {
            console.error('分析过程发生错误:', error);
            setAnalysisError(error.message);
        } finally {
            setIsAnalyzing(false);
        }
    };

    useEffect(() => {
        axios.get(`${backendUrl}/api/cmdb/v1/cluster-groups`)
            .then(response => {
            let clusterGroupsList = [];
            
            // 处理不同的数据结构
            if (Array.isArray(response.data)) {
                clusterGroupsList = response.data;
            } else if (response.data && response.data.list) {
                clusterGroupsList = response.data.list;
            } else if (response.data && response.data.data) {
                clusterGroupsList = response.data.data;
                } else {
                console.warn('未知的集群组数据格式:', response.data);
                clusterGroupsList = [];
                }
            
            setClusterGroups(clusterGroupsList);
            })
            .catch(error => {
            console.error('Error fetching cluster groups:', error);
            setClusterGroups([]);
            });

        // 初始化时加载服务器资源数据
        fetchServerResources();
    }, []);

    // 当筛选数据变化时，更新统计数据
    useEffect(() => {
        updateStats(filteredData);
    }, [filteredData, cpuThresholds, memoryThresholds, diskThresholds]);

    // 添加一个Tab组件，包含现有的内容和集群资源使用情况
    const { TabPane } = Tabs;

    return (
        <ConfigProvider locale={zhCN}>
            <Layout>
                <Content style={{ padding: '20px' }}>
                    <Card title="筛选条件" style={{ marginBottom: 16 }}>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <div>集群组</div>
                                <Select
                                    mode="multiple"
                                    style={{ width: '100%' }}
                                    placeholder="选择集群组"
                                    value={selectedGroups}
                                    onChange={handleGroupChange}
                                    loading={uniqueClusterGroups.length === 0 && clusterGroups.length === 0}
                                    notFoundContent={
                                        uniqueClusterGroups.length === 0 
                                            ? '没有可用的集群组' 
                                            : '未找到匹配的集群组'
                                    }
                                >
                                    {uniqueClusterGroups.map(group => (
                                        <Option key={group} value={group}>{group}</Option>
                                    ))}
                                </Select>
                            </Col>
                            <Col span={8}>
                                <div>集群</div>
                                <Select
                                    mode="multiple"
                                    style={{ width: '100%' }}
                                    placeholder="选择集群"
                                    value={selectedClusters}
                                    onChange={handleClusterChange}
                                >
                                    {uniqueClusters.map(cluster => (
                                        <Option key={cluster} value={cluster}>{cluster}</Option>
                                    ))}
                                </Select>
                            </Col>
                            <Col span={8}>
                                <div>部门</div>
                                <Select
                                    mode="multiple"
                                    style={{ width: '100%' }}
                                    placeholder="选择部门"
                                    value={selectedDepartments}
                                    onChange={handleDepartmentChange}
                                >
                                    {uniqueDepartments.map(department => (
                                        <Option key={department} value={department}>{department}</Option>
                                    ))}
                                </Select>
                            </Col>
                            <Col span={8}>
                                <div>日期范围</div>
                                <RangePicker 
                                    style={{ width: '100%' }}
                                    onChange={handleDateRangeChange}
                                    value={dateRange}
                                />
                            </Col>
                            <Col span={8}>
                                <div>CPU利用率阈值 (%)</div>
                                <Input.Group compact>
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最低"
                                        type="number"
                                        value={cpuThresholds.min}
                                        onChange={(e) => handleCpuThresholdChange('min', parseFloat(e.target.value))}
                                    />
                                    <Input
                                        style={{ width: '10%', textAlign: 'center', pointerEvents: 'none' }}
                                        placeholder="~"
                                        disabled
                                        value="~"
                                    />
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最高"
                                        type="number"
                                        value={cpuThresholds.max}
                                        onChange={(e) => handleCpuThresholdChange('max', parseFloat(e.target.value))}
                                    />
                                </Input.Group>
                            </Col>
                            <Col span={8}>
                                <div>内存利用率阈值 (%)</div>
                                <Input.Group compact>
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最低"
                                        type="number"
                                        value={memoryThresholds.min}
                                        onChange={(e) => handleMemoryThresholdChange('min', parseFloat(e.target.value))}
                                    />
                                    <Input
                                        style={{ width: '10%', textAlign: 'center', pointerEvents: 'none' }}
                                        placeholder="~"
                                        disabled
                                        value="~"
                                    />
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最高"
                                        type="number"
                                        value={memoryThresholds.max}
                                        onChange={(e) => handleMemoryThresholdChange('max', parseFloat(e.target.value))}
                                    />
                                </Input.Group>
                            </Col>
                            <Col span={8}>
                                <div>磁盘利用率阈值 (%)</div>
                                <Input.Group compact>
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最低"
                                        type="number"
                                        value={diskThresholds.min}
                                        onChange={(e) => handleDiskThresholdChange('min', parseFloat(e.target.value))}
                                    />
                                    <Input
                                        style={{ width: '10%', textAlign: 'center', pointerEvents: 'none' }}
                                        placeholder="~"
                                        disabled
                                        value="~"
                                    />
                                    <Input
                                        style={{ width: '45%' }}
                                        placeholder="最高"
                                        type="number"
                                        value={diskThresholds.max}
                                        onChange={(e) => handleDiskThresholdChange('max', parseFloat(e.target.value))}
                                    />
                                </Input.Group>
                            </Col>
                            <Col span={8}>
                                <Checkbox 
                                    checked={showOnlyNonCompliant}
                                    onChange={handleShowNonCompliantChange}
                                >
                                    只显示不达标集群的数据
                                </Checkbox>
                            </Col>
                        </Row>
                    </Card>

                    <Card title="操作配置" style={{ marginBottom: 16 }}>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <div>AI分析集群</div>
                                <Select
                                    loading={serverResources.length === 0}
                                    showSearch
                                    style={{ width: '100%' }}
                                    placeholder="🔍 选择分析集群"
                                    optionFilterProp="children"
                                    value={selectedCluster}
                                    onChange={value => {
                                        console.log('选择的集群:', value);
                                        setSelectedCluster(value);
                                    }}
                                    filterOption={(input, option) =>
                                        option.children.toLowerCase().includes(input.toLowerCase())
                                    }
                                    notFoundContent={
                                        <div style={{ padding: 8, color: '#999' }}>
                                            {filteredClusters.length === 0 
                                                ? '没有可用的集群数据' 
                                                : '未找到匹配的集群'}
                                        </div>
                                    }
                                >
                                    {filteredClusters.map(clusterName => {
                                        const clusterData = filteredData.filter(item => item.cluster_name === clusterName);
                                        const groupName = clusterData[0]?.group_name || '未知组';
                                        const nodeCount = clusterData.length;
                                        return (
                                            <Option 
                                                key={clusterName} 
                                                value={clusterName}
                                                title={`节点数: ${nodeCount}`}
                                            >
                                                {`${clusterName} (${groupName})`}
                                            </Option>
                                        );
                                    })}
                                </Select>
                            </Col>
                            <Col span={8}>
                                <div>邮件地址</div>
                                <Input
                                    placeholder="输入邮件地址"
                                    value={emailAddress}
                                    onChange={(e) => setEmailAddress(e.target.value)}
                                />
                            </Col>
                            <Col span={8}>
                                <div>邮件发送</div>
                                <Button 
                                    type="primary" 
                                    style={{ width: '100%' }}
                                    onClick={handleSendEmail}
                                >
                                    发送页面截图到邮箱
                                </Button>
                            </Col>
                        </Row>
                    </Card>

                    {/* 添加错误提示 */}
                    {dataLoadingError && (
                        <Alert
                            message="数据加载错误"
                            description={dataLoadingError}
                            type="error"
                            showIcon
                            style={{ marginBottom: 16 }}
                            action={
                                <Button 
                                    size="small" 
                                    type="primary" 
                                    onClick={() => {
                                        fetchServerResources(
                                            dateRange ? dateRange[0] : null, 
                                            dateRange ? dateRange[1] : null
                                        );
                                    }}
                                >
                                    重试
                                </Button>
                            }
                        />
                    )}

                    <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
                        <Col span={6}>
                            <Card>
                                <Statistic
                                    title="集群数量"
                                    value={stats.totalClusters}
                                    prefix={<Icon type="warning" />}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card>
                                <Statistic
                                    title="主机数量"
                                    value={stats.totalHosts}
                                    prefix={<Icon type="warning" />}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card>
                                <Statistic
                                    title="达标集群数量/主机数量"
                                    value={`${stats.compliantClusters}/${stats.compliantHosts}`}
                                    prefix={<Icon type="check-circle" style={{ color: 'green' }} />}
                                />
                            </Card>
                        </Col>
                        <Col span={6}>
                            <Card>
                                <Statistic
                                    title="不达标集群数量/主机数量"
                                    value={`${stats.nonCompliantClusters}/${stats.nonCompliantHosts}`}
                                    prefix={<Icon type="close-circle" style={{ color: 'red' }} />}
                                />
                            </Card>
                        </Col>
                    </Row>

                    <div ref={contentRef}>
                        <Tabs defaultActiveKey="resource-alerts" type="card">
                            <TabPane tab="资源警报" key="resource-alerts">
                        <Row gutter={[16, 16]}>
                                    <Col span={24}>
                                <Card title="资源警报">
                                    <Alerts 
                                        data={filteredData} 
                                        cpuThresholds={cpuThresholds}
                                        memoryThresholds={memoryThresholds}
                                        diskThresholds={diskThresholds}
                                        triggerUpdate={triggerUpdate}
                                        selectedGroups={selectedGroups}
                                    />
                                </Card>
                            </Col>
                                    <Col span={24}>    
                                <Card 
                                    title={
                                        <div>
                                            资源警报详情
                                            {renderExportButton(handleExportResourceAlerts)}
                                        </div>
                                    }
                                >
                                    <ResourceAlerts 
                                        data={filteredData} 
                                        cpuThresholds={cpuThresholds}
                                        memoryThresholds={memoryThresholds}
                                        diskThresholds={diskThresholds}
                                        triggerUpdate={triggerUpdate}
                                        pagination={false}
                                    />
                                </Card>
                            </Col>
                                </Row>
                            </TabPane>
                            <TabPane tab="磁盘空间预测" key="disk-prediction">
                                <Card 
                                    title={
                                        <div>
                                            磁盘空间预测
                                            {renderExportButton(handleExportDiskPrediction)}
                                        </div>
                                    }
                                >
                                    <DiskFullPrediction data={filteredData} pagination={false} />
                                </Card>
                            </TabPane>
                            <TabPane tab="地域资源分布" key="geographic-distribution">
                                <Card title="地域资源分布">
                                    <GeographicDistribution data={filteredData} />
                                </Card>
                            </TabPane>
                            <TabPane tab="服务器资源详情" key="server-resource-details">
                                <Card 
                                    title={
                                        <div>
                                            服务器资源详情
                                            {renderExportButton(handleExportServerResource)}
                                        </div>
                                    }
                                >
                                    <HostResourceDetail 
                                        data={filteredData} 
                                        pagination={{
                                            showSizeChanger: true,
                                            showQuickJumper: true,
                                            pageSizeOptions: ['10', '20', '50', '100', '500'],
                                            defaultPageSize: 10,
                                        }}
                                        dateRange={dateRange}
                                        onDateChange={handleDateRangeChange}
                                        refreshData={() => fetchServerResources(
                                            dateRange ? dateRange[0] : null, 
                                            dateRange ? dateRange[1] : null
                                        )}
                                        error={dataLoadingError}
                                        loading={isLoading}
                                    />
                                </Card>
                            </TabPane>
                        </Tabs>
                    </div>
                    <div className="ai-analysis-section">
                        <h3>AI智能分析</h3>
                        <Button 
                            type="primary" 
                            onClick={handleAnalyzeCluster}
                            disabled={isAnalyzing}
                        >
                            {isAnalyzing ? <Spin size="small" /> : '开始智能分析'}
                        </Button>
                        
                        {analysisError && (
                            <Alert message={analysisError} type="error" style={{ marginTop: 16 }} />
                        )}
                        
                        {analysisResult && (
                            <div className="analysis-results">
                                <h4>优化建议：</h4>
                                <pre>{JSON.stringify(analysisResult, null, 2)}</pre>
                                <Button 
                                    type="primary" 
                                    onClick={() => executeRecommendation(analysisResult)}
                                    style={{ marginTop: 8 }}
                                >
                                    执行建议方案
                                </Button>
                            </div>
                        )}
                    </div>
                </Content>
            </Layout>
        </ConfigProvider>
    );
};

const executeRecommendation = async (recommendation) => {
    try {
        // 调用后端API执行具体操作
        await executeClusterAction(recommendation.action);
        message.success('操作已成功执行');
    } catch (error) {
        message.error(`操作执行失败: ${error.message}`);
    }
};

export default DatabaseClusterAnalysis;