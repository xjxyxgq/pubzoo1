// 集群资源使用情况组件
import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Table, message, Modal, Button } from 'antd';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { getTextColumnSearchProps, getNumberRangeFilterProps, getColumnSorter, getPercentageValue } from '../../utils/tableUtils';
import axios from 'axios';
import moment from 'moment';

// 集群详细数据弹出界面组件
const ClusterDetailsModal = ({ visible, onCancel, clusterName, dateRange }) => {
  const [loading, setLoading] = useState(false);
  const [clusterData, setClusterData] = useState([]);
  const [originalData, setOriginalData] = useState([]);
  const [sortedInfo, setSortedInfo] = useState({});
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8888';

  const fetchClusterDetails = async (page = 1, pageSize = 10) => {
    if (!clusterName) return;
    
    setLoading(true);
    try {
      const params = {
        cluster: clusterName,
        page,
        pageSize,
      };
      
      if (dateRange && dateRange[0] && dateRange[1]) {
        params.startDate = dateRange[0].format('YYYY-MM-DD');
        params.endDate = dateRange[1].format('YYYY-MM-DD');
      } else {
        params.startDate = moment().subtract(3, 'months').format('YYYY-MM-DD');
        params.endDate = moment().format('YYYY-MM-DD');
      }

      const response = await axios.get(`${backendUrl}/api/cmdb/v1/server-resources`, { params });
      const data = Array.isArray(response.data) ? response.data : (response.data.list || []);
      
      // 过滤出指定集群的数据
      const filteredData = data.filter(item => item.cluster_name === clusterName);
      
      setOriginalData(filteredData);
      setClusterData(filteredData);
      setSortedInfo({}); // 重置排序状态
      setPagination(prev => ({
        ...prev,
        current: page,
        pageSize,
        total: filteredData.length,
      }));
    } catch (error) {
      console.error('获取集群详细数据失败:', error);
      message.error('获取集群详细数据失败');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (visible && clusterName) {
      fetchClusterDetails(pagination.current, pagination.pageSize);
    }
  }, [visible, clusterName, dateRange]);

  // 生成唯一的 rowKey
  const generateRowKey = (record, index) => {
    // 尝试多种方式生成唯一ID
    if (record.id) return String(record.id);
    
    const parts = [
      record.cluster_name || 'cluster',
      record.ip || record.ip_address || 'ip',
      record.host_name || 'host',
      record.date_time || new Date().toISOString(),
      String(index)
    ];
    
    // 创建一个基于内容的哈希码
    const hashCode = parts.join('-').split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    return `cluster-${Math.abs(hashCode)}-${index}`;
  };

  const columns = [
    {
      title: '集群名称',
      dataIndex: 'cluster_name',
      key: 'cluster_name',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'cluster_name' && sortedInfo.order,
    },
    {
      title: 'IP地址',
      dataIndex: 'ip',
      key: 'ip',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'ip' && sortedInfo.order,
      render: (value, record) => value || record.ip_address,
    },
    {
      title: '主机名',
      dataIndex: 'host_name',
      key: 'host_name',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'host_name' && sortedInfo.order,
    },
    {
      title: 'CPU负载 (%)',
      dataIndex: 'cpu_load',
      key: 'cpu_load',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'cpu_load' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
    },
    {
      title: '已用内存 (GB)',
      dataIndex: 'used_memory',
      key: 'used_memory',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'used_memory' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '总内存 (GB)',
      dataIndex: 'total_memory',
      key: 'total_memory',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'total_memory' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '内存使用率 (%)',
      key: 'memory_usage',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'memory_usage' && sortedInfo.order,
      render: (_, record) => {
        const usage = getPercentageValue(record, 'used_memory', 'total_memory');
        return `${usage.toFixed(2)}%`;
      },
    },
    {
      title: '已用磁盘 (GB)',
      dataIndex: 'used_disk',
      key: 'used_disk',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'used_disk' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '总磁盘 (GB)',
      dataIndex: 'total_disk',
      key: 'total_disk',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'total_disk' && sortedInfo.order,
      render: (value) => `${(Number(value) || 0).toFixed(2)} GB`,
    },
    {
      title: '磁盘使用率 (%)',
      key: 'disk_usage',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'disk_usage' && sortedInfo.order,
      render: (_, record) => {
        const usage = getPercentageValue(record, 'used_disk', 'total_disk');
        return `${usage.toFixed(2)}%`;
      },
    },
    {
      title: '时间戳',
      dataIndex: 'date_time',
      key: 'date_time',
      sorter: true,
      sortOrder: sortedInfo.columnKey === 'date_time' && sortedInfo.order,
      render: (value) => {
        if (!value) return 'N/A';
        const date = new Date(value);
        return isNaN(date.getTime()) ? value : date.toLocaleString();
      },
    },
  ];

  // 客户端排序函数
  const sortData = (data, sorter) => {
    // 如果没有排序器、没有列键或没有排序方向，返回原始数据
    if (!sorter || !sorter.columnKey || !sorter.order) {
      console.log('No sorting applied, returning original data');
      return [...data]; // 返回数组副本避免引用问题
    }

    return [...data].sort((a, b) => {
      let aVal, bVal;
      
      // 根据不同的列类型处理排序值
      switch (sorter.columnKey) {
        case 'memory_usage':
          aVal = getPercentageValue(a, 'used_memory', 'total_memory');
          bVal = getPercentageValue(b, 'used_memory', 'total_memory');
          break;
        case 'disk_usage':
          aVal = getPercentageValue(a, 'used_disk', 'total_disk');
          bVal = getPercentageValue(b, 'used_disk', 'total_disk');
          break;
        case 'date_time':
          aVal = new Date(a.date_time || 0).getTime();
          bVal = new Date(b.date_time || 0).getTime();
          break;
        case 'cluster_name':
        case 'host_name':
        case 'ip':
          // 文本字段
          aVal = String(a[sorter.columnKey] || '').toLowerCase();
          bVal = String(b[sorter.columnKey] || '').toLowerCase();
          return sorter.order === 'ascend' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
        default:
          // 数值字段
          aVal = Number(a[sorter.columnKey]) || 0;
          bVal = Number(b[sorter.columnKey]) || 0;
          break;
      }

      if (sorter.order === 'ascend') {
        return aVal - bVal;
      } else {
        return bVal - aVal;
      }
    });
  };

  const handleTableChange = (paginationConfig, filters, sorter) => {
    // console.log('=== ClusterDetailsModal Table Change Event ===');
    // console.log('Pagination:', paginationConfig);
    // console.log('Filters:', filters);
    // console.log('Sorter:', sorter);
    // console.log('Original data length:', originalData.length);
    // console.log('Current cluster data length:', clusterData.length);
    
    // 更新排序状态
    setSortedInfo(sorter || {});
    
    // 应用排序
    const sortedData = sortData(originalData, sorter);
    // console.log('Sorted data length:', sortedData.length);
    setClusterData(sortedData);
    
    // 更新分页信息
    setPagination(prev => ({
      ...prev,
      current: paginationConfig.current,
      pageSize: paginationConfig.pageSize,
    }));
    
    // console.log('=== End Table Change Event ===');
  };

  return (
    <Modal
      title={`集群 ${clusterName} 的详细数据源`}
      visible={visible}
      onCancel={onCancel}
      footer={[
        <Button key="close" onClick={onCancel}>
          关闭
        </Button>
      ]}
      width={1400}
      destroyOnClose
    >
      <Table
        columns={columns}
        dataSource={clusterData}
        loading={loading}
        sortDirections={['ascend', 'descend']}
        showSorterTooltip={false}
        pagination={{
          ...pagination,
          showSizeChanger: true,
          showQuickJumper: true,
          pageSizeOptions: ['10', '20', '50', '100'],
          showTotal: (total, range) => `第 ${range[0]}-${range[1]} 条，共 ${total} 条记录`,
        }}
        onChange={handleTableChange}
        rowKey={generateRowKey}
        scroll={{ x: 1200 }}
      />
    </Modal>
  );
};

// 添加列定义导出函数
export const getClusterResourceColumns = (onClusterClick) => [
  {
    title: '集群名称',
    dataIndex: 'clusterName',
    ...getTextColumnSearchProps('clusterName', '集群名称'),
    ...getColumnSorter('clusterName'),
    render: (value) => (
      <Button 
        type="link" 
        style={{ padding: 0, height: 'auto' }}
        onClick={() => onClusterClick && onClusterClick(value)}
      >
        {value}
      </Button>
    ),
  },
  {
    title: '组名',
    dataIndex: 'groupName',
    ...getTextColumnSearchProps('groupName', '组名'),
    ...getColumnSorter('groupName'),
  },
  {
    title: 'CPU使用率(平均)',
    dataIndex: 'cpu',
    ...getNumberRangeFilterProps('cpu', '%', (record) => {
      const value = Number(record.cpu);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('cpu', (record) => {
      const value = Number(record.cpu);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  },
  {
    title: 'CPU使用率(最大)',
    dataIndex: 'maxCPU',
    ...getNumberRangeFilterProps('maxCPU', '%', (record) => {
      const value = Number(record.maxCPU);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('maxCPU', (record) => {
      const value = Number(record.maxCPU);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  },
  {
    title: '内存使用率(平均)',
    dataIndex: 'memory',
    ...getNumberRangeFilterProps('memory', '%', (record) => {
      const value = Number(record.memory);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('memory', (record) => {
      const value = Number(record.memory);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  },
  {
    title: '内存使用率(最大)',
    dataIndex: 'maxMemory',
    ...getNumberRangeFilterProps('maxMemory', '%', (record) => {
      const value = Number(record.maxMemory);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('maxMemory', (record) => {
      const value = Number(record.maxMemory);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  },
  {
    title: '磁盘使用率(平均)',
    dataIndex: 'disk',
    ...getNumberRangeFilterProps('disk', '%', (record) => {
      const value = Number(record.disk);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('disk', (record) => {
      const value = Number(record.disk);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  },
  {
    title: '磁盘使用率(最大)',
    dataIndex: 'maxDisk',
    ...getNumberRangeFilterProps('maxDisk', '%', (record) => {
      const value = Number(record.maxDisk);
      return isNaN(value) ? 0 : value;
    }),
    ...getColumnSorter('maxDisk', (record) => {
      const value = Number(record.maxDisk);
      return isNaN(value) ? 0 : value;
    }),
    render: (value) => `${(Number(value) || 0).toFixed(2)}%`,
  }
];

const ClusterResourceUsage = ({ dateRange }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedCluster, setSelectedCluster] = useState(null);
  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8888';

  const handleClusterClick = (clusterName) => {
    setSelectedCluster(clusterName);
    setModalVisible(true);
  };

  const handleModalClose = () => {
    setModalVisible(false);
    setSelectedCluster(null);
  };

  // 获取集群资源数据
  const fetchClusterResourceData = async (startDate, endDate) => {
    setLoading(true);
    const params = {};
    
    if (startDate && endDate) {
      params.startDate = startDate.format('YYYY-MM-DD');
      params.endDate = endDate.format('YYYY-MM-DD');
    } else {
      params.startDate = moment().subtract(3, 'months').format('YYYY-MM-DD');
      params.endDate = moment().add(1, 'day').format('YYYY-MM-DD');
    }

    try {
      const response = await axios.get(`${backendUrl}/api/cmdb/v1/server-resources`, { params });
      // console.log('集群资源数据响应:', response.data);
      
      const serverResourcesList = Array.isArray(response.data) 
        ? response.data 
        : (response.data.list || []);
      
      // 按集群分组并计算统计数据
      const clusterData = processClusterData(serverResourcesList);
      setData(clusterData);
      setLoading(false);
    } catch (error) {
      console.error('获取集群资源数据失败:', error);
      message.error('获取集群资源数据失败');
      setLoading(false);
    }
  };

  // 处理服务器资源数据，按集群分组并计算统计数据
  const processClusterData = (resources) => {
    // 按集群名称和组名分组
    const clusterGroups = {};
    
    resources.forEach(resource => {
      const clusterName = resource.cluster_name || '未知集群';
      const groupName = resource.group_name || '未知组';
      const key = `${groupName}-${clusterName}`;
      
      if (!clusterGroups[key]) {
        clusterGroups[key] = {
          clusterName,
          groupName,
          cpuValues: [],
          memoryValues: [],
          diskValues: []
        };
      }
      
      // 计算CPU、内存和磁盘使用率
      const cpuUsage = Number(resource.cpu_load) || 0;
      
      const totalMemory = Number(resource.total_memory) || 1; // 避免除以0
      const usedMemory = Number(resource.used_memory) || 0;
      const memoryUsage = (usedMemory / totalMemory) * 100;
      
      const totalDisk = Number(resource.total_disk) || 1; // 避免除以0
      const usedDisk = Number(resource.used_disk) || 0;
      const diskUsage = (usedDisk / totalDisk) * 100;
      
      clusterGroups[key].cpuValues.push(cpuUsage);
      clusterGroups[key].memoryValues.push(memoryUsage);
      clusterGroups[key].diskValues.push(diskUsage);
    });
    
    // 计算每个集群的统计数据
    return Object.values(clusterGroups).map(cluster => {
      const calculateStats = (values) => {
        if (values.length === 0) return { avg: 0, max: 0, min: 0 };
        const sum = values.reduce((a, b) => a + b, 0);
        return {
          avg: sum / values.length,
          max: Math.max(...values),
          min: Math.min(...values)
        };
      };
      
      const cpuStats = calculateStats(cluster.cpuValues);
      const memoryStats = calculateStats(cluster.memoryValues);
      const diskStats = calculateStats(cluster.diskValues);
      
      return {
        clusterName: cluster.clusterName,
        groupName: cluster.groupName,
        cpu: cpuStats.avg,
        maxCPU: cpuStats.max,
        minCPU: cpuStats.min,
        memory: memoryStats.avg,
        maxMemory: memoryStats.max,
        minMemory: memoryStats.min,
        disk: diskStats.avg,
        maxDisk: diskStats.max,
        minDisk: diskStats.min
      };
    });
  };

  // 监听日期范围变化
  useEffect(() => {
    const startDate = dateRange && dateRange[0] ? dateRange[0] : null;
    const endDate = dateRange && dateRange[1] ? dateRange[1] : null;
    fetchClusterResourceData(startDate, endDate);
  }, [dateRange]);

  const renderClusterChart = (cluster, index) => {
    const roundToTwoDecimals = (value) => Math.round(value * 100) / 100;

    const chartData = [
      { 
        name: 'CPU', 
        平均: roundToTwoDecimals(cluster.cpu),
        最大: roundToTwoDecimals(cluster.maxCPU),
        最小: roundToTwoDecimals(cluster.minCPU)
      },
      { 
        name: '内存', 
        平均: roundToTwoDecimals(cluster.memory),
        最大: roundToTwoDecimals(cluster.maxMemory),
        最小: roundToTwoDecimals(cluster.minMemory)
      },
      { 
        name: '磁盘', 
        平均: roundToTwoDecimals(cluster.disk),
        最大: roundToTwoDecimals(cluster.maxDisk),
        最小: roundToTwoDecimals(cluster.minDisk)
      },
    ];

    return (
      <Col 
        key={`${cluster.groupName}-${cluster.clusterName}`}
        xs={24} 
        sm={12} 
        md={8} 
        lg={6} 
        xl={4} 
        xxl={4} 
        style={{ marginBottom: '20px' }}
      >
        <Card title={`${cluster.groupName}-${cluster.clusterName}`} style={{ height: 400 }}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData} barSize={30}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 100]} tickFormatter={(value) => `${value}%`} />
              <Tooltip formatter={(value) => `${value}%`} />
              <Legend />
              <Bar dataKey="平均" fill="#8884d8" name="平均使用率 (%)" />
              <Bar dataKey="最大" fill="#82ca9d" name="最大使用率 (%)" />
              <Bar dataKey="最小" fill="#ffc658" name="最小使用率 (%)" />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </Col>
    );
  };

  const sortedData = [...data].sort((a, b) => {
    const aKey = `${a.groupName}-${a.clusterName}`;
    const bKey = `${b.groupName}-${b.clusterName}`;
    return aKey.localeCompare(bKey);
  });

  const currentPageData = sortedData.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleTableChange = (pagination) => {
    setCurrentPage(pagination.current);
    setPageSize(pagination.pageSize);
  };

  return (
    <div>
      <Row gutter={[16, 16]}>
        {currentPageData.map((cluster, index) => renderClusterChart(cluster, index))}
      </Row>
      <Row gutter={[16, 16]}>
        <Col span={24}>
          <Table
            columns={getClusterResourceColumns(handleClusterClick)}
            dataSource={sortedData}
            rowKey={(record) => `${record.groupName}-${record.clusterName}`}
            pagination={{
              current: currentPage,
              pageSize: pageSize,
              total: sortedData.length,
              showSizeChanger: true,
              showQuickJumper: true,
              pageSizeOptions: ['5', '10', '20', '50'],
              onChange: (page, pageSize) => {
                setCurrentPage(page);
                setPageSize(pageSize || 5);
              },
            }}
            onChange={handleTableChange}
            loading={loading}
          />
        </Col>
      </Row>

      <ClusterDetailsModal
        visible={modalVisible}
        onCancel={handleModalClose}
        clusterName={selectedCluster}
        dateRange={dateRange}
      />
    </div>
  );
};

export default ClusterResourceUsage;