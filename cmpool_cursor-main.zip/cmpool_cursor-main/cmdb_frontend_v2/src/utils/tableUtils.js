import React, { useState, Component } from 'react';
import { Input, Button, InputNumber, Icon, DatePicker } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;

// 数值范围筛选器组件
class NumberRangeFilter extends Component {
  constructor(props) {
    super(props);
    // 从 selectedKeys 中恢复范围筛选值
    const existingFilter = props.selectedKeys && props.selectedKeys[0] && typeof props.selectedKeys[0] === 'object' 
      ? props.selectedKeys[0] 
      : { min: null, max: null };
    
    this.state = {
      minValue: existingFilter.min,
      maxValue: existingFilter.max,
    };
  }

  handleSearch = () => {
    const { minValue, maxValue } = this.state;
    const { setSelectedKeys, confirm } = this.props;
    
    // 创建一个包含范围信息的对象，然后将其作为单个键传递
    const rangeFilter = {
      min: (minValue !== null && minValue !== '' && minValue !== undefined && !isNaN(minValue)) ? minValue : null,
      max: (maxValue !== null && maxValue !== '' && maxValue !== undefined && !isNaN(maxValue)) ? maxValue : null
    };
    
    // 只有当至少有一个值时才设置筛选
    if (rangeFilter.min !== null || rangeFilter.max !== null) {
      setSelectedKeys([rangeFilter]);
    } else {
      setSelectedKeys([]);
    }
    confirm();
  };

  handleReset = () => {
    const { clearFilters, confirm, setSelectedKeys } = this.props;
    this.setState({
      minValue: null,
      maxValue: null,
    });
    // 确保清除筛选键
    setSelectedKeys([]);
    clearFilters();
    confirm();
  };

  render() {
    const { unit } = this.props;
    const { minValue, maxValue } = this.state;

    return (
      <div style={{ padding: 8 }}>
        <div style={{ marginBottom: 8 }}>
          <InputNumber
            placeholder={`最小值${unit}`}
            value={minValue}
            onChange={(value) => this.setState({ minValue: value })}
            style={{ width: '100%' }}
          />
        </div>
        <div style={{ marginBottom: 8 }}>
          <InputNumber
            placeholder={`最大值${unit}`}
            value={maxValue}
            onChange={(value) => this.setState({ maxValue: value })}
            style={{ width: '100%' }}
          />
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <Button
            type="primary"
            onClick={this.handleSearch}
            size="small"
            style={{ width: 90 }}
          >
            筛选
          </Button>
          <Button
            onClick={this.handleReset}
            size="small"
            style={{ width: 90 }}
          >
            重置
          </Button>
        </div>
      </div>
    );
  }
}

// 文本筛选组件
export const getTextColumnSearchProps = (dataIndex, placeholder = '搜索') => ({
  filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
    <div style={{ padding: 8 }}>
      <Input
        placeholder={`搜索 ${placeholder}`}
        value={selectedKeys[0]}
        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
        onPressEnter={() => confirm()}
        style={{ marginBottom: 8, display: 'block' }}
      />
      <div style={{ display: 'flex', gap: '8px' }}>
        <Button
          type="primary"
          onClick={() => confirm()}
          icon="search"
          size="small"
          style={{ width: 90 }}
        >
          搜索
        </Button>
        <Button
          onClick={() => {
            clearFilters();
            confirm();
          }}
          size="small"
          style={{ width: 90 }}
        >
          重置
        </Button>
      </div>
    </div>
  ),
  filterIcon: filtered => <Icon type="search" style={{ color: filtered ? '#1890ff' : undefined }} />,
  onFilter: (value, record) => {
    const cellValue = dataIndex.includes('.') 
      ? dataIndex.split('.').reduce((obj, key) => obj?.[key], record)
      : record[dataIndex];
    return cellValue
      ? cellValue.toString().toLowerCase().includes(value.toLowerCase())
      : false;
  },
});

// 数值范围筛选组件
export const getNumberRangeFilterProps = (dataIndex, unit = '', getValue = null) => ({
  filterDropdown: (props) => (
    <NumberRangeFilter 
      {...props} 
      unit={unit} 
    />
  ),
  filterIcon: filtered => <Icon type="search" style={{ color: filtered ? '#1890ff' : undefined }} />,
  onFilter: (value, record) => {
    // 检查 value 是否存在
    if (!value) {
      return true;
    }
    
    // 处理范围筛选对象
    let minFilter = null;
    let maxFilter = null;
    
    if (typeof value === 'object' && !Array.isArray(value)) {
      // 新的对象格式 {min: x, max: y}
      minFilter = value.min;
      maxFilter = value.max;
    } else if (Array.isArray(value) && value.length > 0) {
      // 兼容数组格式 [min, max]
      minFilter = value[0];
      maxFilter = value[1];
    } else {
      // 如果都不是，返回 true（显示所有）
      return true;
    }
    
    // 如果没有有效的筛选条件，显示所有
    if (minFilter === null && maxFilter === null) {
      return true;
    }
    
    const cellValue = getValue 
      ? getValue(record)
      : (dataIndex.includes('.') 
          ? dataIndex.split('.').reduce((obj, key) => obj?.[key], record)
          : record[dataIndex]);
    
    // 临时调试信息
    if (dataIndex === 'memory_usage' || dataIndex === 'disk_usage') {
      console.log(`筛选调试 ${dataIndex}:`, {
        getValue: !!getValue,
        cellValue,
        record: { used_memory: record.used_memory, total_memory: record.total_memory, used_disk: record.used_disk, total_disk: record.total_disk }
      });
    }
    
    const numValue = typeof cellValue === 'number' ? cellValue : parseFloat(cellValue);
    if (isNaN(numValue)) return false;
    
    // 应用筛选条件
    if (minFilter !== null && maxFilter !== null) {
      return numValue >= minFilter && numValue <= maxFilter;
    } else if (minFilter !== null) {
      return numValue >= minFilter;
    } else if (maxFilter !== null) {
      return numValue <= maxFilter;
    }
    return true;
  },
});

// 通用排序函数
export const getColumnSorter = (dataIndex, getValue = null) => {
  return {
    sorter: (a, b) => {
      const aValue = getValue 
        ? getValue(a)
        : (dataIndex.includes('.') 
            ? dataIndex.split('.').reduce((obj, key) => obj?.[key], a)
            : a[dataIndex]);
      const bValue = getValue 
        ? getValue(b)
        : (dataIndex.includes('.') 
            ? dataIndex.split('.').reduce((obj, key) => obj?.[key], b)
            : b[dataIndex]);
      
      // 数值排序
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return aValue - bValue;
      }
      
      // 字符串排序
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return aValue.localeCompare(bValue);
      }
      
      // 日期排序
      if (aValue instanceof Date && bValue instanceof Date) {
        return aValue.getTime() - bValue.getTime();
      }
      
      // 转换为字符串后排序
      return String(aValue).localeCompare(String(bValue));
    },
    sortDirections: ['descend', 'ascend'],
  };
};

// 百分比值的获取函数
export const getPercentageValue = (record, usedField, totalField) => {
  const used = record[usedField];
  const total = record[totalField];
  return total > 0 ? (used / total) * 100 : 0;
};

// 日期范围筛选器组件
class DateRangeFilter extends Component {
  constructor(props) {
    super(props);
    // 从 selectedKeys 中恢复日期范围筛选值
    const existingFilter = props.selectedKeys && props.selectedKeys[0] && typeof props.selectedKeys[0] === 'object' 
      ? props.selectedKeys[0] 
      : { startDate: null, endDate: null };
    
    this.state = {
      startDate: existingFilter.startDate ? moment(existingFilter.startDate) : null,
      endDate: existingFilter.endDate ? moment(existingFilter.endDate) : null,
    };
  }

  handleSearch = () => {
    const { startDate, endDate } = this.state;
    const { setSelectedKeys, confirm } = this.props;
    
    // 创建一个包含日期范围信息的对象
    const dateRangeFilter = {
      startDate: startDate ? startDate.format('YYYY-MM-DD') : null,
      endDate: endDate ? endDate.format('YYYY-MM-DD') : null
    };
    
    // 只有当至少有一个日期时才设置筛选
    if (dateRangeFilter.startDate || dateRangeFilter.endDate) {
      setSelectedKeys([dateRangeFilter]);
    } else {
      setSelectedKeys([]);
    }
    confirm();
  };

  handleReset = () => {
    const { clearFilters, confirm, setSelectedKeys } = this.props;
    this.setState({
      startDate: null,
      endDate: null,
    });
    // 确保清除筛选键
    setSelectedKeys([]);
    clearFilters();
    confirm();
  };

  handleRangeChange = (dates) => {
    this.setState({
      startDate: dates && dates[0] ? dates[0] : null,
      endDate: dates && dates[1] ? dates[1] : null,
    });
  };

  render() {
    const { startDate, endDate } = this.state;

    return (
      <div style={{ padding: 8 }}>
        <div style={{ marginBottom: 8 }}>
          <RangePicker
            value={[startDate, endDate]}
            onChange={this.handleRangeChange}
            style={{ width: '100%' }}
            placeholder={['开始日期', '结束日期']}
            format="YYYY-MM-DD"
          />
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <Button
            type="primary"
            onClick={this.handleSearch}
            size="small"
            style={{ width: 90 }}
          >
            筛选
          </Button>
          <Button
            onClick={this.handleReset}
            size="small"
            style={{ width: 90 }}
          >
            重置
          </Button>
        </div>
      </div>
    );
  }
}

// 日期范围筛选组件
export const getDateRangeFilterProps = (dataIndex, getValue = null) => ({
  filterDropdown: (props) => (
    <DateRangeFilter 
      {...props} 
    />
  ),
  filterIcon: filtered => <Icon type="calendar" style={{ color: filtered ? '#1890ff' : undefined }} />,
  onFilter: (value, record) => {
    // 检查 value 是否存在
    if (!value) {
      return true;
    }
    
    // 处理日期范围筛选对象
    let startDateFilter = null;
    let endDateFilter = null;
    
    if (typeof value === 'object' && !Array.isArray(value)) {
      // 对象格式 {startDate: 'YYYY-MM-DD', endDate: 'YYYY-MM-DD'}
      startDateFilter = value.startDate;
      endDateFilter = value.endDate;
    } else {
      // 如果不是对象，返回 true（显示所有）
      return true;
    }
    
    // 如果没有有效的筛选条件，显示所有
    if (!startDateFilter && !endDateFilter) {
      return true;
    }
    
    // 获取记录中的日期值
    const cellValue = getValue 
      ? getValue(record)
      : (dataIndex.includes('.') 
          ? dataIndex.split('.').reduce((obj, key) => obj?.[key], record)
          : record[dataIndex]);
    
    if (!cellValue) return false;
    
    // 将日期值转换为Date对象
    let recordDate;
    if (cellValue instanceof Date) {
      recordDate = cellValue;
    } else if (typeof cellValue === 'string') {
      recordDate = new Date(cellValue);
    } else {
      return false;
    }
    
    // 检查日期是否有效
    if (isNaN(recordDate.getTime())) return false;
    
    const recordDateStr = recordDate.toISOString().split('T')[0]; // 格式化为 YYYY-MM-DD
    
    // 应用筛选条件
    if (startDateFilter && endDateFilter) {
      return recordDateStr >= startDateFilter && recordDateStr <= endDateFilter;
    } else if (startDateFilter) {
      return recordDateStr >= startDateFilter;
    } else if (endDateFilter) {
      return recordDateStr <= endDateFilter;
    }
    return true;
  },
}); 