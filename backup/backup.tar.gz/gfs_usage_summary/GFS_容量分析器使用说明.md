# GFS 容量分析器使用说明

## 概述

GFS 容量分析器是一个 Python 程序，用于分析 GFS 目录的容量使用情况，提供多维度的详细统计报告。相比原有的 shell 脚本，Python 版本提供了更强大的分析功能和更友好的输出格式。

## 主要功能

### 1. 文件信息收集
- 扫描指定的 GFS 目录
- 收集每个文件的完整路径、大小、修改时间
- 解析备份文件命名模式，提取集群信息

### 2. 多维度分析
- **月度统计**：按月统计数据量和增量
- **备份类型分析**：按 clone、xtrabackup 等备份方式分析
- **集群维度分析**：按集群统计容量和增量情况
- **TOP 文件分析**：找出最大的文件

### 3. 输出格式
- **Excel 文件**：包含多个工作表的详细分析数据
- **文本报告**：简洁的汇总分析报告
- **日志文件**：详细的处理过程记录

## 安装依赖

```bash
pip3 install -r requirements.txt
```

或者手动安装：

```bash
pip3 install pandas numpy openpyxl tqdm
```

## 使用方法

### 基本用法

```bash
python3 gfs_capacity_analyzer.py /path/to/gfs/mount/point
```

### 高级选项

```bash
# 指定输出目录
python3 gfs_capacity_analyzer.py /mnt/gfs --output ./reports

# 启用调试模式
python3 gfs_capacity_analyzer.py /mnt/gfs --debug

# 不导出 Excel 文件（只生成文本报告）
python3 gfs_capacity_analyzer.py /mnt/gfs --no-excel

# 只运行增量分析和容量预测（快速模式，类似原 shell 脚本）
python3 gfs_capacity_analyzer.py /mnt/gfs --incremental-only

# 查看帮助信息
python3 gfs_capacity_analyzer.py --help
```

## 文件命名模式解析

程序能够解析以下格式的备份文件名：
- `ip_机器名_full_日期.数字串.tar.gz`
- 例如：`192.168.1.1_jp1-db-mdbp99_full_20240101.3223432324234.tar.gz`

### 集群名称提取规则

从主机名中提取集群名称：
- `jp1-db-mdbp99` → `mdbp99`
- `jp1-db-mdbp0101` → `mdbp01`
- `jp1-db-mdbp01-0101` → `mdbp01`

## 输出文件说明

### Excel 文件包含以下工作表：

1. **文件详情**：所有扫描文件的完整信息
2. **月度统计**：按月的容量统计和增量分析
3. **备份类型月度分析**：按备份类型的月度统计
4. **集群月度分析**：按集群的月度统计和主机数量
5. **TOP50最大文件**：最大的 50 个文件列表

### 文本报告包含：

- 基本统计信息
- 月度容量趋势
- 备份类型分析
- 集群容量排行

## 配置说明

程序中的活跃目录列表可以根据实际情况修改：

```python
self.active_dirs = [
    "pubzoo",
    "cmpool_cursor", 
    "backups",
    "temp_files",
    "user_uploads"
]
```

## 使用示例

### 1. 基本分析

```bash
python3 gfs_capacity_analyzer.py /mnt/gfs
```

输出：
```
GFS 容量分析器
分析时间: 2024-12-12 14:30:00
GFS 路径: /mnt/gfs

基本统计:
  总文件数: 15,234
  总大小: 2.5TB
  备份文件数: 12,089
  备份文件大小: 2.3TB

月度容量趋势 (最近6个月):
  2024-07: 350.2GB
  2024-08: 412.5GB
  2024-09: 489.1GB
  2024-10: 567.8GB
  2024-11: 634.2GB
  2024-12: 712.5GB

备份类型分析:
  xtrabackup: 1.8TB (8,345 文件)
  clone: 512.3GB (3,744 文件)

集群容量排行 (TOP 10):
  mdbp01: 856.7GB (12 主机)
  mdbp02: 634.2GB (8 主机)
  mdbp03: 423.8GB (6 主机)
```

### 2. 调试模式

```bash
python3 gfs_capacity_analyzer.py /mnt/gfs --debug
```

调试模式会显示详细的处理过程，包括文件解析、集群名称提取等信息。

## 性能优化建议

1. **大型目录**：对于包含大量文件的目录，建议使用调试模式监控进度
2. **网络存储**：如果 GFS 是网络挂载，建议在低峰期运行以减少网络负载
3. **内存使用**：程序会将所有文件信息加载到内存，大量文件时需要足够的内存

## 故障排除

### 常见问题

1. **权限错误**：确保对 GFS 目录有读取权限
2. **依赖包缺失**：运行 `pip3 install -r requirements.txt` 安装依赖
3. **内存不足**：对于超大目录，可以考虑分批处理

### 日志查看

程序会在输出目录中生成详细的日志文件：
- `gfs_analyzer_YYYYMMDD_HHMMSS.log`

## 与原 Shell 脚本的对比

| 功能 | Shell 脚本 | Python 分析器 |
|------|------------|---------------|
| 基本统计 | ✓ | ✓ |
| 月度分析 | ✗ | ✓ |
| 集群分析 | ✗ | ✓ |
| Excel 导出 | ✗ | ✓ |
| 文件名解析 | ✗ | ✓ |
| 进度显示 | ✗ | ✓ |
| 详细日志 | ✗ | ✓ |
| 性能 | 较慢 | 较快 |

## 扩展功能

程序设计为可扩展的，您可以：

1. 添加新的文件命名模式解析
2. 增加新的分析维度
3. 自定义输出格式
4. 集成到监控系统中

## 技术支持

如果遇到问题或需要新功能，请提供以下信息：
- 错误信息和日志
- GFS 目录结构
- 运行环境信息
- 具体需求描述 