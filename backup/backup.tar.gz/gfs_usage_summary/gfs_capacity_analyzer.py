#!/opt/anaconda3/envs/python_tools/bin/python
# -*- coding: utf-8 -*-
"""
GFS 容量分析器
用于分析 GFS 目录的容量使用情况，生成详细的统计报告

主要功能：
1. 扫描目录收集文件信息
2. 导出到 Excel 文件
3. 按月统计数据量
4. 按备份类型分析
5. 按集群维度分析增量情况
"""

import os
import sys
import argparse
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import re
from pathlib import Path
import logging
from tqdm import tqdm
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
import hashlib
import json

class GFSCapacityAnalyzer:
    def __init__(self, gfs_path, output_dir="./output", debug=False):
        """
        初始化 GFS 容量分析器
        
        Args:
            gfs_path (str): GFS 挂载点路径
            output_dir (str): 输出目录
            debug (bool): 是否启用调试模式
        """
        self.gfs_path = Path(gfs_path)
        self.output_dir = Path(output_dir)
        self.debug = debug
        
        # 创建输出目录
        self.output_dir.mkdir(exist_ok=True)
        
        # 配置日志
        self._setup_logging()
        
        # 监控的活跃目录列表
        self.active_dirs = [
            "clone",
        ]
        
        # 文件数据存储
        self.file_data = []
        
        self.logger.info(f"GFS 容量分析器初始化完成")
        self.logger.info(f"GFS 路径: {self.gfs_path}")
        self.logger.info(f"输出目录: {self.output_dir}")
    
    def _setup_logging(self):
        """设置日志配置"""
        log_level = logging.DEBUG if self.debug else logging.INFO
        
        # 创建日志文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = self.output_dir / f"gfs_analyzer_{timestamp}.log"
        
        # 配置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # 文件处理器
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(log_level)
        
        # 配置根日志器
        self.logger = logging.getLogger('GFSAnalyzer')
        self.logger.setLevel(log_level)
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
    
    def extract_cluster_name(self, hostname):
        """
        从主机名提取集群名称
        
        支持的模式：
        - jp1-db-mdbp99 -> mdbp99
        - jp1-db-mdbp0101 -> mdbp01
        - jp1-db-mdbp01-0101 -> mdbp01
        
        Args:
            hostname (str): 主机名
            
        Returns:
            str: 集群名称
        """
        if not hostname:
            return "unknown"
        
        # 模式1: jp1-db-mdbp99 -> mdbp99 (直接以数字结尾)
        pattern1 = r'([^-]+)-([^-]+)-([a-zA-Z]+\d+)$'
        match1 = re.match(pattern1, hostname)
        if match1:
            cluster_part = match1.group(3)  # 例如: mdbp99
            # 如果是类似 mdbp0101 的格式，提取前面的部分 mdbp01
            cluster_match = re.match(r'([a-zA-Z]+)(\d+)', cluster_part)
            if cluster_match:
                prefix = cluster_match.group(1)  # mdbp
                numbers = cluster_match.group(2)  # 99 或 0101
                if len(numbers) > 2:
                    # 如果数字超过2位，只取前2位
                    return prefix + numbers[:2]
                else:
                    # 如果数字是2位或更少，直接返回
                    return cluster_part
        
        # 模式2: jp1-db-mdbp01-0101 -> mdbp01 (有额外的数字部分)
        pattern2 = r'([^-]+)-([^-]+)-([a-zA-Z]+\d{2})-\d+'
        match2 = re.match(pattern2, hostname)
        if match2:
            return match2.group(3)
        
        # 如果都不匹配，返回原始主机名
        self.logger.warning(f"无法解析集群名称: {hostname}")
        return hostname
    
    def parse_filename(self, filepath):
        """
        解析文件名以提取相关信息
        
        文件命名模式: ip_机器名_full_日期.数字串.tar.gz
        例如: 192.168.1.1_jp1-db-mdbp99_full_20240101.3223432324234.tar.gz
        
        Args:
            filepath (Path): 文件路径
            
        Returns:
            dict: 解析结果
        """
        filename = filepath.name
        parent_dir = filepath.parent.name
        
        result = {
            'backup_type': parent_dir,
            'ip': None,
            'hostname': None,
            'cluster': None,
            'backup_time': None,
            'is_backup_file': False
        }
        
        # 解析备份文件名模式: ip_机器名_full_日期.数字串.tar.gz
        backup_pattern = r'^(\d+\.\d+\.\d+\.\d+)_([^_]+)_full_(\d{8})\.(\d+)\.tar\.gz$'
        match = re.match(backup_pattern, filename)
        
        if match:
            result['is_backup_file'] = True
            result['ip'] = match.group(1)
            result['hostname'] = match.group(2)
            result['cluster'] = self.extract_cluster_name(match.group(2))
            
            # 解析时间（只有日期）
            date_str = match.group(3)
            try:
                result['backup_time'] = datetime.strptime(date_str, '%Y%m%d')
            except ValueError:
                self.logger.warning(f"无法解析日期: {date_str}")
                
            if self.debug:
                self.logger.debug(f"解析文件名成功: {filename}")
                self.logger.debug(f"  IP: {result['ip']}")
                self.logger.debug(f"  主机名: {result['hostname']}")
                self.logger.debug(f"  集群: {result['cluster']}")
                self.logger.debug(f"  备份时间: {result['backup_time']}")
        else:
            # 如果不匹配主要模式，尝试其他可能的模式
            if self.debug:
                self.logger.debug(f"文件名不匹配备份模式: {filename}")
        
        return result
    
    def get_file_size(self, filepath):
        """
        获取文件大小（字节）
        
        Args:
            filepath (Path): 文件路径
            
        Returns:
            int: 文件大小
        """
        try:
            return filepath.stat().st_size
        except (OSError, IOError) as e:
            self.logger.error(f"无法获取文件大小 {filepath}: {e}")
            return 0
    
    def get_file_mtime(self, filepath):
        """
        获取文件修改时间
        
        Args:
            filepath (Path): 文件路径
            
        Returns:
            datetime: 修改时间
        """
        try:
            timestamp = filepath.stat().st_mtime
            return datetime.fromtimestamp(timestamp)
        except (OSError, IOError) as e:
            self.logger.error(f"无法获取文件时间 {filepath}: {e}")
            return datetime.now()
    
    def get_filesystem_info(self, path):
        """
        获取文件系统信息
        
        Args:
            path (Path): 文件系统路径
            
        Returns:
            dict: 包含总容量、已使用、可用空间的字典（单位：字节）
        """
        import shutil
        
        try:
            # 使用 shutil.disk_usage 获取磁盘使用情况
            total, used, free = shutil.disk_usage(path)
            
            return {
                'total': total,
                'used': used,
                'available': free,
                'usage_percent': round((used / total) * 100, 2) if total > 0 else 0
            }
        except Exception as e:
            self.logger.error(f"无法获取文件系统信息 {path}: {e}")
            return {
                'total': 0,
                'used': 0,
                'available': 0,
                'usage_percent': 0
            }
    
    def get_directory_size(self, dir_path):
        """
        获取目录大小（递归计算）
        
        Args:
            dir_path (Path): 目录路径
            
        Returns:
            int: 目录总大小（字节）
        """
        total_size = 0
        try:
            for item in dir_path.rglob('*'):
                if item.is_file():
                    try:
                        total_size += item.stat().st_size
                    except (OSError, IOError):
                        continue
            return total_size
        except Exception as e:
            self.logger.error(f"无法计算目录大小 {dir_path}: {e}")
            return 0
    
    def get_incremental_size(self, dir_path, days):
        """
        获取指定天数内修改文件的总大小
        
        Args:
            dir_path (Path): 目录路径
            days (int): 天数
            
        Returns:
            dict: 包含总大小和文件数量的字典
        """
        if not dir_path.exists():
            return {'size': 0, 'count': 0}
        
        cutoff_time = datetime.now() - timedelta(days=days)
        total_size = 0
        file_count = 0
        
        try:
            for item in dir_path.rglob('*'):
                if item.is_file():
                    try:
                        file_mtime = datetime.fromtimestamp(item.stat().st_mtime)
                        if file_mtime >= cutoff_time:
                            total_size += item.stat().st_size
                            file_count += 1
                    except (OSError, IOError):
                        continue
            
            return {'size': total_size, 'count': file_count}
        except Exception as e:
            self.logger.error(f"无法计算增量大小 {dir_path}: {e}")
            return {'size': 0, 'count': 0}
    
    def scan_directories(self):
        """
        扫描目录收集文件信息
        """
        self.logger.info("开始扫描目录...")
        
        total_files = 0
        total_size = 0
        
        for dir_name in self.active_dirs:
            dir_path = self.gfs_path / dir_name
            
            if not dir_path.exists():
                self.logger.warning(f"目录不存在: {dir_path}")
                continue
            
            self.logger.info(f"扫描目录: {dir_path}")
            
            try:
                # 递归扫描所有文件
                files = list(dir_path.rglob('*'))
                files = [f for f in files if f.is_file()]
                
                self.logger.info(f"目录 {dir_name} 中找到 {len(files)} 个文件")
                
                # 处理文件
                for filepath in tqdm(files, desc=f"处理 {dir_name}"):
                    try:
                        file_size = self.get_file_size(filepath)
                        file_mtime = self.get_file_mtime(filepath)
                        
                        # 解析文件名
                        parse_info = self.parse_filename(filepath)
                        
                        file_info = {
                            'file_path': str(filepath),
                            'relative_path': str(filepath.relative_to(self.gfs_path)),
                            'file_name': filepath.name,
                            'directory': dir_name,
                            'parent_dir': filepath.parent.name,
                            'file_size': file_size,
                            'file_size_mb': round(file_size / (1024 * 1024), 2),
                            'file_size_gb': round(file_size / (1024 * 1024 * 1024), 4),
                            'modification_time': file_mtime,
                            'modification_date': file_mtime.date(),
                            'year_month': file_mtime.strftime('%Y-%m'),
                            'backup_type': parse_info['backup_type'],
                            'ip': parse_info['ip'],
                            'hostname': parse_info['hostname'],
                            'cluster': parse_info['cluster'],
                            'backup_time': parse_info['backup_time'],
                            'is_backup_file': parse_info['is_backup_file']
                        }
                        
                        self.file_data.append(file_info)
                        total_files += 1
                        total_size += file_size
                        
                    except Exception as e:
                        self.logger.error(f"处理文件失败 {filepath}: {e}")
                        
            except Exception as e:
                self.logger.error(f"扫描目录失败 {dir_path}: {e}")
        
        self.logger.info(f"扫描完成！共找到 {total_files} 个文件，总大小: {self.format_size(total_size)}")
    
    @staticmethod
    def format_size(size_bytes):
        """
        将字节转换为人类可读格式
        
        Args:
            size_bytes (int): 字节数
            
        Returns:
            str: 格式化的大小
        """
        if size_bytes == 0:
            return "0B"
        
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        size = float(size_bytes)
        
        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1
        
        return f"{size:.2f}{units[unit_index]}"
    
    def export_to_excel(self, filename=None):
        """
        导出数据到 Excel 文件
        
        Args:
            filename (str): 输出文件名
            
        Returns:
            str: 输出文件路径
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"gfs_file_data_{timestamp}.xlsx"
        
        output_file = self.output_dir / filename
        
        self.logger.info(f"导出数据到 Excel: {output_file}")
        
        # 创建 DataFrame
        df = pd.DataFrame(self.file_data)
        
        if df.empty:
            self.logger.warning("没有数据可导出")
            return None
        
        # 创建 Excel 写入器
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # 写入原始数据
            df.to_excel(writer, sheet_name='文件详情', index=False)
            
            # 格式化工作表
            self._format_excel_sheet(writer.book['文件详情'], df)
            
            # 创建汇总分析
            self._create_summary_sheets(writer, df)
        
        self.logger.info(f"Excel 文件导出完成: {output_file}")
        return str(output_file)
    
    def _format_excel_sheet(self, worksheet, df):
        """
        格式化 Excel 工作表
        
        Args:
            worksheet: openpyxl 工作表对象
            df: DataFrame 数据
        """
        # 设置标题行样式
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        for cell in worksheet[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 调整列宽
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 50)
            worksheet.column_dimensions[column_letter].width = adjusted_width
        
        # 冻结首行
        worksheet.freeze_panes = "A2"
    
    def _create_summary_sheets(self, writer, df):
        """
        创建汇总分析工作表
        
        Args:
            writer: Excel 写入器
            df: 原始数据 DataFrame
        """
        # 1. 月度统计
        self._create_monthly_summary(writer, df)
        
        # 2. 备份类型分析
        self._create_backup_type_summary(writer, df)
        
        # 3. 集群分析
        self._create_cluster_summary(writer, df)
        
        # 4. 集群增长率分析
        self._create_cluster_growth_analysis(writer, df)
        
        # 5. 集群对比分析
        self._create_cluster_comparison_analysis(writer, df)
        
        # 6. 集群容量预测
        self._create_cluster_capacity_prediction(writer, df)
        
        # 7. TOP 文件分析
        self._create_top_files_summary(writer, df)
        
        # 8. 增量分析
        self._create_incremental_summary(writer, df)
    
    def _create_monthly_summary(self, writer, df):
        """
        创建月度统计工作表
        """
        # 按年月统计
        monthly_stats = df.groupby('year_month').agg({
            'file_size': ['count', 'sum'],
            'file_size_gb': 'sum'
        }).round(2)
        
        monthly_stats.columns = ['文件数量', '总大小_字节', '总大小_GB']
        monthly_stats['总大小_格式化'] = monthly_stats['总大小_字节'].apply(self.format_size)
        monthly_stats = monthly_stats.reset_index()
        monthly_stats.rename(columns={'year_month': '年月'}, inplace=True)
        
        # 计算月度增量
        monthly_stats['月度增量_GB'] = monthly_stats['总大小_GB'].diff()
        monthly_stats['月度增量_格式化'] = monthly_stats['月度增量_GB'].apply(
            lambda x: self.format_size(x * 1024 * 1024 * 1024) if pd.notna(x) else "N/A"
        )
        
        monthly_stats.to_excel(writer, sheet_name='月度统计', index=False)
    
    def _create_backup_type_summary(self, writer, df):
        """
        创建备份类型分析工作表
        """
        # 只分析备份文件
        backup_df = df[df['is_backup_file'] == True]
        
        if not backup_df.empty:
            # 按备份类型和年月统计
            backup_monthly = backup_df.groupby(['backup_type', 'year_month']).agg({
                'file_size_gb': 'sum',
                'file_size': 'count'
            }).round(2)
            
            backup_monthly.columns = ['大小_GB', '文件数量']
            backup_monthly = backup_monthly.reset_index()
            backup_monthly.rename(columns={
                'backup_type': '备份类型',
                'year_month': '年月'
            }, inplace=True)
            
            backup_monthly.to_excel(writer, sheet_name='备份类型月度分析', index=False)
            
            # 备份类型总计
            backup_total = backup_df.groupby('backup_type').agg({
                'file_size_gb': 'sum',
                'file_size': 'count'
            }).round(2)
            
            backup_total.columns = ['总大小_GB', '文件数量']
            backup_total['总大小_格式化'] = (backup_total['总大小_GB'] * 1024 * 1024 * 1024).apply(self.format_size)
            backup_total = backup_total.reset_index()
            backup_total.rename(columns={'backup_type': '备份类型'}, inplace=True)
            
            # 写入到同一个工作表的不同位置
            workbook = writer.book
            worksheet = workbook['备份类型月度分析']
            
            # 添加总计表
            start_row = len(backup_monthly) + 4
            worksheet.cell(row=start_row, column=1, value="备份类型总计")
            
            for r_idx, row in enumerate(dataframe_to_rows(backup_total, index=False, header=True)):
                for c_idx, value in enumerate(row):
                    worksheet.cell(row=start_row + 1 + r_idx, column=c_idx + 1, value=value)
    
    def _create_cluster_summary(self, writer, df):
        """
        创建集群分析工作表
        """
        # 只分析备份文件且有集群信息的
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if not cluster_df.empty:
            # 按集群和年月统计
            cluster_monthly = cluster_df.groupby(['cluster', 'year_month']).agg({
                'file_size_gb': 'sum',
                'file_size': 'count'
            }).round(2)
            
            cluster_monthly.columns = ['大小_GB', '文件数量']
            cluster_monthly = cluster_monthly.reset_index()
            cluster_monthly.rename(columns={
                'cluster': '集群',
                'year_month': '年月'
            }, inplace=True)
            
            cluster_monthly.to_excel(writer, sheet_name='集群月度分析', index=False)
            
            # 集群总计
            cluster_total = cluster_df.groupby('cluster').agg({
                'file_size_gb': 'sum',
                'file_size': 'count',
                'hostname': 'nunique'
            }).round(2)
            
            cluster_total.columns = ['总大小_GB', '文件数量', '主机数量']
            cluster_total['总大小_格式化'] = (cluster_total['总大小_GB'] * 1024 * 1024 * 1024).apply(self.format_size)
            cluster_total = cluster_total.reset_index()
            cluster_total.rename(columns={'cluster': '集群'}, inplace=True)
            
            # 写入到同一个工作表的不同位置
            workbook = writer.book
            worksheet = workbook['集群月度分析']
            
            # 添加总计表
            start_row = len(cluster_monthly) + 4
            worksheet.cell(row=start_row, column=1, value="集群总计")
            
            for r_idx, row in enumerate(dataframe_to_rows(cluster_total, index=False, header=True)):
                for c_idx, value in enumerate(row):
                    worksheet.cell(row=start_row + 1 + r_idx, column=c_idx + 1, value=value)
    
    def _create_cluster_growth_analysis(self, writer, df):
        """
        创建集群增长率和变化率分析工作表
        """
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if cluster_df.empty:
            return
        
        # 按集群和年月统计
        cluster_monthly = cluster_df.groupby(['cluster', 'year_month']).agg({
            'file_size_gb': 'sum',
            'file_size': 'count'
        }).reset_index()
        
        # 计算增长率数据
        growth_data = []
        
        for cluster in cluster_monthly['cluster'].unique():
            cluster_data = cluster_monthly[cluster_monthly['cluster'] == cluster].sort_values('year_month')
            
            if len(cluster_data) < 2:
                continue
            
            # 计算各种指标
            first_month = cluster_data.iloc[0]
            last_month = cluster_data.iloc[-1]
            
            total_months = len(cluster_data)
            total_growth = last_month['file_size_gb'] - first_month['file_size_gb']
            total_growth_percent = (total_growth / first_month['file_size_gb'] * 100) if first_month['file_size_gb'] > 0 else 0
            
            # 月平均增长
            avg_monthly_growth = total_growth / (total_months - 1) if total_months > 1 else 0
            avg_monthly_growth_percent = total_growth_percent / (total_months - 1) if total_months > 1 else 0
            
            # 计算最近3个月的趋势（如果有的话）
            recent_trend = "稳定"
            if len(cluster_data) >= 3:
                recent_data = cluster_data.tail(3)
                recent_growth = recent_data.iloc[-1]['file_size_gb'] - recent_data.iloc[0]['file_size_gb']
                if recent_growth > avg_monthly_growth * 1.5:
                    recent_trend = "加速增长"
                elif recent_growth < avg_monthly_growth * 0.5:
                    recent_trend = "减缓增长"
                elif recent_growth < 0:
                    recent_trend = "下降"
            
            # 预测下个月的数据量
            predicted_next_month = last_month['file_size_gb'] + avg_monthly_growth
            
            growth_data.append({
                '集群': cluster,
                '数据周期_月数': total_months,
                '首月数据量_GB': round(first_month['file_size_gb'], 2),
                '最新数据量_GB': round(last_month['file_size_gb'], 2),
                '总增长量_GB': round(total_growth, 2),
                '总增长率_%': round(total_growth_percent, 2),
                '月均增长_GB': round(avg_monthly_growth, 2),
                '月均增长率_%': round(avg_monthly_growth_percent, 2),
                '最近趋势': recent_trend,
                '预测下月_GB': round(predicted_next_month, 2),
                '数据起始月': first_month['year_month'],
                '数据截止月': last_month['year_month']
            })
        
        if growth_data:
            growth_df = pd.DataFrame(growth_data)
            # 按总数据量排序
            growth_df = growth_df.sort_values('最新数据量_GB', ascending=False)
            growth_df.to_excel(writer, sheet_name='集群增长分析', index=False)
        
        return growth_data
    
    def _create_cluster_comparison_analysis(self, writer, df):
        """
        创建集群对比分析工作表
        """
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if cluster_df.empty:
            return
        
        # 集群对比统计
        cluster_stats = cluster_df.groupby('cluster').agg({
            'file_size_gb': ['sum', 'mean', 'count'],
            'hostname': 'nunique',
            'backup_time': ['min', 'max']
        }).round(2)
        
        # 展平多级索引
        cluster_stats.columns = ['总大小_GB', '平均文件大小_GB', '文件数量', '主机数量', '最早备份', '最新备份']
        cluster_stats = cluster_stats.reset_index()
        
        # 计算排名和占比
        total_size = cluster_stats['总大小_GB'].sum()
        cluster_stats['数据占比_%'] = (cluster_stats['总大小_GB'] / total_size * 100).round(2)
        cluster_stats['大小排名'] = cluster_stats['总大小_GB'].rank(method='dense', ascending=False).astype(int)
        cluster_stats['文件数排名'] = cluster_stats['文件数量'].rank(method='dense', ascending=False).astype(int)
        
        # 计算效率指标
        cluster_stats['单机平均_GB'] = (cluster_stats['总大小_GB'] / cluster_stats['主机数量']).round(2)
        cluster_stats['单文件平均_MB'] = (cluster_stats['总大小_GB'] * 1024 / cluster_stats['文件数量']).round(2)
        
        # 按总大小排序
        cluster_stats = cluster_stats.sort_values('总大小_GB', ascending=False)
        
        # 重新排列列的顺序
        column_order = ['cluster', '大小排名', '总大小_GB', '数据占比_%', '文件数量', '文件数排名', 
                       '主机数量', '单机平均_GB', '平均文件大小_GB', '单文件平均_MB', 
                       '最早备份', '最新备份']
        cluster_stats = cluster_stats[column_order]
        cluster_stats.rename(columns={'cluster': '集群'}, inplace=True)
        
        cluster_stats.to_excel(writer, sheet_name='集群对比分析', index=False)
        
        return cluster_stats
    
    def _create_cluster_capacity_prediction(self, writer, df):
        """
        创建集群容量预测分析工作表
        """
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if cluster_df.empty:
            return
        
        # 获取文件系统信息
        fs_info = self.get_filesystem_info(self.gfs_path)
        
        # 按集群和年月统计
        cluster_monthly = cluster_df.groupby(['cluster', 'year_month']).agg({
            'file_size_gb': 'sum'
        }).reset_index()
        
        prediction_data = []
        
        for cluster in cluster_monthly['cluster'].unique():
            cluster_data = cluster_monthly[cluster_monthly['cluster'] == cluster].sort_values('year_month')
            
            if len(cluster_data) < 2:
                continue
            
            # 计算增长趋势
            current_size = cluster_data.iloc[-1]['file_size_gb']
            total_months = len(cluster_data)
            
            # 线性回归计算增长率
            x = np.arange(len(cluster_data))
            y = cluster_data['file_size_gb'].values
            
            if len(x) > 1 and np.std(y) > 0:
                # 计算线性回归
                z = np.polyfit(x, y, 1)
                monthly_growth_trend = z[0]  # 斜率就是月增长趋势
                
                # R² 相关系数（衡量预测可靠性）
                y_pred = np.polyval(z, x)
                ss_res = np.sum((y - y_pred) ** 2)
                ss_tot = np.sum((y - np.mean(y)) ** 2)
                r_squared = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
                
                # 预测未来几个月
                predict_3_months = current_size + monthly_growth_trend * 3
                predict_6_months = current_size + monthly_growth_trend * 6
                predict_12_months = current_size + monthly_growth_trend * 12
                
                # 计算集群在总容量中的占比
                cluster_percent = (current_size * 1024 * 1024 * 1024) / fs_info['total'] * 100 if fs_info['total'] > 0 else 0
                
                # 预测达到预警阈值的时间（假设单个集群不应超过总容量的10%）
                warning_threshold_gb = fs_info['total'] / (1024**3) * 0.1  # 10%阈值
                months_to_warning = (warning_threshold_gb - current_size) / monthly_growth_trend if monthly_growth_trend > 0 else float('inf')
                
                reliability = "高" if r_squared > 0.8 else "中" if r_squared > 0.5 else "低"
                
                prediction_data.append({
                    '集群': cluster,
                    '当前大小_GB': round(current_size, 2),
                    '当前占比_%': round(cluster_percent, 2),
                    '月增长趋势_GB': round(monthly_growth_trend, 2),
                    '预测可靠性': reliability,
                    'R²系数': round(r_squared, 3),
                    '3月后预测_GB': round(predict_3_months, 2),
                    '6月后预测_GB': round(predict_6_months, 2),
                    '12月后预测_GB': round(predict_12_months, 2),
                    '预警阈值_GB': round(warning_threshold_gb, 2),
                    '达到预警_月数': round(months_to_warning, 1) if months_to_warning != float('inf') else '不会达到',
                    '数据样本_月数': total_months
                })
        
        if prediction_data:
            prediction_df = pd.DataFrame(prediction_data)
            # 按当前大小排序
            prediction_df = prediction_df.sort_values('当前大小_GB', ascending=False)
            prediction_df.to_excel(writer, sheet_name='集群容量预测', index=False)
        
        return prediction_data
    
    def _create_top_files_summary(self, writer, df):
        """
        创建 TOP 文件分析工作表
        """
        # TOP 50 最大文件
        top_files = df.nlargest(50, 'file_size')[
            ['relative_path', 'file_size_gb', 'modification_time', 'backup_type', 'cluster']
        ].copy()
        
        top_files['文件大小_格式化'] = (top_files['file_size_gb'] * 1024 * 1024 * 1024).apply(self.format_size)
        top_files.rename(columns={
            'relative_path': '文件路径',
            'file_size_gb': '大小_GB',
            'modification_time': '修改时间',
            'backup_type': '备份类型',
            'cluster': '集群'
        }, inplace=True)
        
        top_files.to_excel(writer, sheet_name='TOP50最大文件', index=False)
    
    def _create_incremental_summary(self, writer, df):
        """
        创建增量分析工作表
        """
        # 获取文件系统信息
        fs_info = self.get_filesystem_info(self.gfs_path)
        
        # 创建增量分析数据
        incremental_data = []
        
        for dir_name in self.active_dirs:
            dir_path = self.gfs_path / dir_name
            
            if dir_path.exists():
                # 获取当前容量
                current_size = self.get_directory_size(dir_path)
                
                # 获取增量信息
                daily_info = self.get_incremental_size(dir_path, 1)
                monthly_info = self.get_incremental_size(dir_path, 30)
                
                incremental_data.append({
                    '目录名称': dir_name,
                    '当前容量_字节': current_size,
                    '当前容量_GB': round(current_size / (1024**3), 2),
                    '当前容量_格式化': self.format_size(current_size),
                    '日增量_字节': daily_info['size'],
                    '日增量_GB': round(daily_info['size'] / (1024**3), 2),
                    '日增量_格式化': self.format_size(daily_info['size']),
                    '日增量_文件数': daily_info['count'],
                    '月增量_字节': monthly_info['size'],
                    '月增量_GB': round(monthly_info['size'] / (1024**3), 2),
                    '月增量_格式化': self.format_size(monthly_info['size']),
                    '月增量_文件数': monthly_info['count'],
                })
            else:
                incremental_data.append({
                    '目录名称': dir_name,
                    '当前容量_字节': 0,
                    '当前容量_GB': 0,
                    '当前容量_格式化': '目录不存在',
                    '日增量_字节': 0,
                    '日增量_GB': 0,
                    '日增量_格式化': '-',
                    '日增量_文件数': 0,
                    '月增量_字节': 0,
                    '月增量_GB': 0,
                    '月增量_格式化': '-',
                    '月增量_文件数': 0,
                })
        
        # 创建DataFrame
        incremental_df = pd.DataFrame(incremental_data)
        incremental_df.to_excel(writer, sheet_name='增量分析', index=False)
        
        # 在同一工作表中添加文件系统信息
        workbook = writer.book
        worksheet = workbook['增量分析']
        
        # 添加文件系统信息
        start_row = len(incremental_data) + 4
        
        fs_data = [
            ['文件系统信息', ''],
            ['总容量', self.format_size(fs_info['total'])],
            ['已使用', f"{self.format_size(fs_info['used'])} ({fs_info['usage_percent']}%)"],
            ['可用空间', self.format_size(fs_info['available'])],
            ['', ''],
            ['容量预测', ''],
        ]
        
        # 计算预测
        total_daily = sum(item['日增量_字节'] for item in incremental_data)
        total_monthly = sum(item['月增量_字节'] for item in incremental_data)
        
        if total_daily > 0 and fs_info['available'] > 0:
            days_remaining = fs_info['available'] // total_daily
            years = days_remaining // 365
            remaining_days = days_remaining % 365
            if years > 0:
                prediction_text = f"{days_remaining} 天 ({years} 年 {remaining_days} 天)"
            else:
                prediction_text = f"{days_remaining} 天"
            fs_data.append(['按日增量预计', prediction_text])
        else:
            fs_data.append(['按日增量预计', '无有效增量数据'])
        
        if total_monthly > 0 and fs_info['available'] > 0:
            monthly_avg = total_monthly // 30
            if monthly_avg > 0:
                days_remaining_monthly = fs_info['available'] // monthly_avg
                fs_data.append(['按月均增量预计', f"{days_remaining_monthly} 天"])
            else:
                fs_data.append(['按月均增量预计', '无有效增量数据'])
        else:
            fs_data.append(['按月均增量预计', '无有效增量数据'])
        
        # 写入文件系统信息
        for i, (key, value) in enumerate(fs_data):
            worksheet.cell(row=start_row + i, column=1, value=key)
            worksheet.cell(row=start_row + i, column=2, value=value)
    
    def generate_report(self):
        """
        生成完整的分析报告
        """
        if not self.file_data:
            self.logger.error("没有数据可分析，请先扫描目录")
            return None
        
        df = pd.DataFrame(self.file_data)
        
        # 生成文本报告
        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append("GFS 容量分析报告")
        report_lines.append("=" * 60)
        report_lines.append(f"分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"GFS 路径: {self.gfs_path}")
        report_lines.append("")
        
        # 基本统计
        total_files = len(df)
        total_size = df['file_size'].sum()
        backup_files = df[df['is_backup_file'] == True]
        
        report_lines.append("基本统计:")
        report_lines.append(f"  总文件数: {total_files:,}")
        report_lines.append(f"  总大小: {self.format_size(total_size)}")
        report_lines.append(f"  备份文件数: {len(backup_files):,}")
        report_lines.append(f"  备份文件大小: {self.format_size(backup_files['file_size'].sum())}")
        report_lines.append("")
        
        # 月度趋势
        monthly_stats = df.groupby('year_month')['file_size'].sum()
        report_lines.append("月度容量趋势 (最近6个月):")
        for month, size in monthly_stats.tail(6).items():
            report_lines.append(f"  {month}: {self.format_size(size)}")
        report_lines.append("")
        
        # 备份类型分析
        if not backup_files.empty:
            backup_types = backup_files.groupby('backup_type')['file_size'].sum().sort_values(ascending=False)
            report_lines.append("备份类型分析:")
            for backup_type, size in backup_types.items():
                count = backup_files[backup_files['backup_type'] == backup_type]['file_size'].count()
                report_lines.append(f"  {backup_type}: {self.format_size(size)} ({count:,} 文件)")
            report_lines.append("")
        
        # 集群分析
        cluster_df = backup_files[(backup_files['cluster'].notna()) & (backup_files['cluster'] != 'unknown')]
        if not cluster_df.empty:
            # 集群容量排行
            clusters = cluster_df.groupby('cluster')['file_size'].sum().sort_values(ascending=False)
            report_lines.append("集群容量排行 (TOP 10):")
            for cluster, size in clusters.head(10).items():
                host_count = cluster_df[cluster_df['cluster'] == cluster]['hostname'].nunique()
                report_lines.append(f"  {cluster}: {self.format_size(size)} ({host_count} 主机)")
            report_lines.append("")
            
            # 集群增长率分析
            self._add_cluster_growth_report(report_lines, df)
            
            # 集群对比统计
            self._add_cluster_comparison_report(report_lines, cluster_df)
            
            # 集群容量预测
            self._add_cluster_prediction_report(report_lines, df)
        
        # 保存报告
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.output_dir / f"gfs_analysis_report_{timestamp}.txt"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_lines))
        
        # 输出到控制台
        for line in report_lines:
            print(line)
        
        self.logger.info(f"分析报告已保存到: {report_file}")
        return str(report_file)
    
    def generate_incremental_report(self):
        """
        生成增量分析和容量预测报告
        """
        self.logger.info("生成增量分析和容量预测报告...")
        
        # 获取文件系统信息
        fs_info = self.get_filesystem_info(self.gfs_path)
        
        report_lines = []
        report_lines.append("=" * 60)
        report_lines.append("GFS 增量分析和容量预测报告")
        report_lines.append("=" * 60)
        report_lines.append(f"分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"GFS 路径: {self.gfs_path}")
        report_lines.append("")
        
        # 文件系统容量信息
        report_lines.append("文件系统容量信息:")
        report_lines.append(f"  总容量: {self.format_size(fs_info['total'])}")
        report_lines.append(f"  已使用: {self.format_size(fs_info['used'])} ({fs_info['usage_percent']}%)")
        report_lines.append(f"  可用空间: {self.format_size(fs_info['available'])}")
        report_lines.append("")
        
        # 目录维度增量分析
        report_lines.append("目录维度增量分析:")
        report_lines.append(f"{'目录名称':<20} {'当前容量':<12} {'日增量':<12} {'月增量':<12}")
        report_lines.append("-" * 60)
        
        total_current = 0
        total_daily = 0
        total_monthly = 0
        
        for dir_name in self.active_dirs:
            dir_path = self.gfs_path / dir_name
            
            if dir_path.exists():
                # 获取当前容量
                current_size = self.get_directory_size(dir_path)
                
                # 获取增量信息
                daily_info = self.get_incremental_size(dir_path, 1)
                monthly_info = self.get_incremental_size(dir_path, 30)
                
                daily_size = daily_info['size']
                monthly_size = monthly_info['size']
                
                report_lines.append(
                    f"{dir_name:<20} {self.format_size(current_size):<12} "
                    f"{self.format_size(daily_size):<12} {self.format_size(monthly_size):<12}"
                )
                
                total_current += current_size
                total_daily += daily_size
                total_monthly += monthly_size
                
                if self.debug:
                    self.logger.debug(f"目录 {dir_name}: 当前={current_size}, 日增量={daily_size}, 月增量={monthly_size}")
            else:
                report_lines.append(f"{dir_name:<20} {'目录不存在':<12} {'-':<12} {'-':<12}")
        
        report_lines.append("-" * 60)
        report_lines.append(
            f"{'总计':<20} {self.format_size(total_current):<12} "
            f"{self.format_size(total_daily):<12} {self.format_size(total_monthly):<12}"
        )
        report_lines.append("")
        
        # 容量预测
        report_lines.append("容量预测分析:")
        
        if total_daily > 0 and fs_info['available'] > 0:
            days_remaining = fs_info['available'] // total_daily
            years = days_remaining // 365
            remaining_days = days_remaining % 365
            
            report_lines.append(f"  按日增量预计剩余时间: {days_remaining} 天")
            if years > 0:
                report_lines.append(f"                          ({years} 年 {remaining_days} 天)")
        else:
            report_lines.append("  按日增量预计: 无有效增量数据或空间充足")
        
        if total_monthly > 0 and fs_info['available'] > 0:
            monthly_avg = total_monthly // 30  # 平均每日增量
            if monthly_avg > 0:
                days_remaining_monthly = fs_info['available'] // monthly_avg
                report_lines.append(f"  按月均增量预计剩余时间: {days_remaining_monthly} 天")
        else:
            report_lines.append("  按月均增量预计: 无有效增量数据或空间充足")
        
        report_lines.append("")
        
        # TOP10 最大目录
        report_lines.append("TOP10 最大目录:")
        dir_sizes = []
        for dir_name in self.active_dirs:
            dir_path = self.gfs_path / dir_name
            if dir_path.exists():
                size = self.get_directory_size(dir_path)
                if size > 0:
                    dir_sizes.append((size, dir_name))
        
        # 排序并显示 TOP10
        dir_sizes.sort(reverse=True)
        for i, (size, dir_name) in enumerate(dir_sizes[:10], 1):
            report_lines.append(f"  {i:2d}. {dir_name:<20} {self.format_size(size)}")
        
        report_lines.append("")
        
        # 增量分析建议
        report_lines.append("分析建议:")
        if total_daily > 0:
            daily_percent = (total_daily / fs_info['available']) * 100 if fs_info['available'] > 0 else 0
            if daily_percent > 1:
                report_lines.append("  ⚠️  日增量较大，建议密切监控存储空间")
            elif daily_percent > 0.1:
                report_lines.append("  📊 日增量正常，建议定期清理和备份")
            else:
                report_lines.append("  ✅ 日增量较小，存储空间使用健康")
        
        if fs_info['usage_percent'] > 85:
            report_lines.append("  🚨 存储使用率超过85%，建议立即释放空间")
        elif fs_info['usage_percent'] > 70:
            report_lines.append("  ⚠️  存储使用率超过70%，建议计划扩容")
        else:
            report_lines.append("  ✅ 存储使用率正常")
        
        # 保存增量报告
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = self.output_dir / f"gfs_incremental_report_{timestamp}.txt"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_lines))
        
        # 输出到控制台
        for line in report_lines:
            print(line)
        
        self.logger.info(f"增量分析报告已保存到: {report_file}")
        return str(report_file)
    
    def analyze(self, export_excel=True):
        """
        执行完整的分析流程
        
        Args:
            export_excel (bool): 是否导出 Excel 文件
            
        Returns:
            dict: 分析结果文件路径
        """
        result = {}
        
        # 扫描目录
        self.scan_directories()
        
        if not self.file_data:
            self.logger.error("没有找到任何文件数据")
            return result
        
        # 导出 Excel
        if export_excel:
            excel_file = self.export_to_excel()
            if excel_file:
                result['excel_file'] = excel_file
        
        # 生成报告
        report_file = self.generate_report()
        if report_file:
            result['report_file'] = report_file
        
        # 生成增量分析报告
        incremental_file = self.generate_incremental_report()
        if incremental_file:
            result['incremental_report'] = incremental_file
        
        return result
    
    def _add_cluster_growth_report(self, report_lines, df):
        """
        在文本报告中添加集群增长率分析
        """
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if cluster_df.empty:
            return
        
        # 按集群和年月统计
        cluster_monthly = cluster_df.groupby(['cluster', 'year_month']).agg({
            'file_size_gb': 'sum'
        }).reset_index()
        
        report_lines.append("集群增长率分析:")
        report_lines.append(f"{'集群':<15} {'当前容量':<12} {'月均增长':<12} {'增长率%':<10} {'趋势':<10}")
        report_lines.append("-" * 65)
        
        growth_summary = []
        
        for cluster in cluster_monthly['cluster'].unique():
            cluster_data = cluster_monthly[cluster_monthly['cluster'] == cluster].sort_values('year_month')
            
            if len(cluster_data) < 2:
                continue
            
            first_month = cluster_data.iloc[0]
            last_month = cluster_data.iloc[-1]
            total_months = len(cluster_data)
            
            total_growth = last_month['file_size_gb'] - first_month['file_size_gb']
            avg_monthly_growth = total_growth / (total_months - 1) if total_months > 1 else 0
            total_growth_percent = (total_growth / first_month['file_size_gb'] * 100) if first_month['file_size_gb'] > 0 else 0
            
            # 判断趋势
            recent_trend = "稳定"
            if len(cluster_data) >= 3:
                recent_data = cluster_data.tail(3)
                recent_growth = recent_data.iloc[-1]['file_size_gb'] - recent_data.iloc[0]['file_size_gb']
                if recent_growth > avg_monthly_growth * 1.5:
                    recent_trend = "加速"
                elif recent_growth < avg_monthly_growth * 0.5:
                    recent_trend = "减缓"
                elif recent_growth < 0:
                    recent_trend = "下降"
            
            current_size_bytes = last_month['file_size_gb'] * 1024 * 1024 * 1024
            growth_size_bytes = avg_monthly_growth * 1024 * 1024 * 1024
            
            report_lines.append(
                f"{cluster:<15} {self.format_size(current_size_bytes):<12} "
                f"{self.format_size(growth_size_bytes):<12} {total_growth_percent:<10.1f} {recent_trend:<10}"
            )
            
            growth_summary.append((cluster, avg_monthly_growth, total_growth_percent, recent_trend))
        
        report_lines.append("")
        
        # 添加增长率统计摘要
        if growth_summary:
            growth_rates = [rate for _, _, rate, _ in growth_summary]
            avg_growth_rate = np.mean(growth_rates)
            report_lines.append(f"集群平均增长率: {avg_growth_rate:.1f}%")
            
            fast_growing = [name for name, _, rate, _ in growth_summary if rate > avg_growth_rate * 1.5]
            if fast_growing:
                report_lines.append(f"快速增长集群: {', '.join(fast_growing)}")
            
            declining = [name for name, _, _, trend in growth_summary if trend == "下降"]
            if declining:
                report_lines.append(f"数据量下降集群: {', '.join(declining)}")
        
        report_lines.append("")
    
    def _add_cluster_comparison_report(self, report_lines, cluster_df):
        """
        在文本报告中添加集群对比分析
        """
        report_lines.append("集群对比分析:")
        
        # 计算统计数据
        cluster_stats = cluster_df.groupby('cluster').agg({
            'file_size': ['sum', 'count'],
            'hostname': 'nunique'
        })
        
        cluster_stats.columns = ['总大小_字节', '文件数量', '主机数量']
        cluster_stats = cluster_stats.reset_index()
        
        total_size = cluster_stats['总大小_字节'].sum()
        cluster_stats['占比_%'] = (cluster_stats['总大小_字节'] / total_size * 100).round(2)
        cluster_stats['单机平均_字节'] = cluster_stats['总大小_字节'] / cluster_stats['主机数量']
        
        # 按大小排序
        cluster_stats = cluster_stats.sort_values('总大小_字节', ascending=False)
        
        report_lines.append(f"{'排名':<4} {'集群':<15} {'占比%':<8} {'单机平均':<12} {'主机数':<6} {'文件数':<8}")
        report_lines.append("-" * 65)
        
        for idx, row in cluster_stats.head(10).iterrows():
            rank = cluster_stats.index.get_loc(idx) + 1
            report_lines.append(
                f"{rank:<4} {row['cluster']:<15} {row['占比_%']:<8.1f} "
                f"{self.format_size(row['单机平均_字节']):<12} {row['主机数量']:<6} {row['文件数量']:<8}"
            )
        
        report_lines.append("")
        
        # 添加统计摘要
        report_lines.append("集群统计摘要:")
        report_lines.append(f"  总集群数: {len(cluster_stats)}")
        report_lines.append(f"  最大集群: {cluster_stats.iloc[0]['cluster']} ({cluster_stats.iloc[0]['占比_%']:.1f}%)")
        
        # 集中度分析
        top3_percent = cluster_stats.head(3)['占比_%'].sum()
        report_lines.append(f"  TOP3集群占比: {top3_percent:.1f}%")
        
        if top3_percent > 70:
            report_lines.append("  📊 数据集中度较高，建议关注主要集群的容量管理")
        elif top3_percent > 50:
            report_lines.append("  📈 数据分布相对集中，需要均衡考虑")
        else:
            report_lines.append("  📉 数据分布较为分散，各集群发展相对均衡")
        
        report_lines.append("")
    
    def _add_cluster_prediction_report(self, report_lines, df):
        """
        在文本报告中添加集群容量预测分析
        """
        cluster_df = df[(df['is_backup_file'] == True) & (df['cluster'].notna()) & (df['cluster'] != 'unknown')]
        
        if cluster_df.empty:
            return
        
        # 获取文件系统信息
        fs_info = self.get_filesystem_info(self.gfs_path)
        
        # 按集群和年月统计
        cluster_monthly = cluster_df.groupby(['cluster', 'year_month']).agg({
            'file_size_gb': 'sum'
        }).reset_index()
        
        report_lines.append("集群容量预测分析:")
        report_lines.append(f"{'集群':<15} {'当前容量':<12} {'3月后':<12} {'6月后':<12} {'预警状态':<12}")
        report_lines.append("-" * 70)
        
        warning_clusters = []
        rapid_growth_clusters = []
        
        for cluster in cluster_monthly['cluster'].unique():
            cluster_data = cluster_monthly[cluster_monthly['cluster'] == cluster].sort_values('year_month')
            
            if len(cluster_data) < 2:
                continue
            
            current_size = cluster_data.iloc[-1]['file_size_gb']
            
            # 线性回归计算增长趋势
            if len(cluster_data) > 1:
                x = np.arange(len(cluster_data))
                y = cluster_data['file_size_gb'].values
                
                if np.std(y) > 0:
                    z = np.polyfit(x, y, 1)
                    monthly_growth_trend = z[0]
                    
                    # 预测未来容量
                    predict_3_months = current_size + monthly_growth_trend * 3
                    predict_6_months = current_size + monthly_growth_trend * 6
                    
                    # 计算在总容量中的占比
                    current_percent = (current_size * 1024 * 1024 * 1024) / fs_info['total'] * 100
                    
                    # 预警判断（单个集群超过总容量的10%）
                    warning_threshold = 10.0
                    status = "正常"
                    
                    if current_percent > warning_threshold:
                        status = "🚨超限"
                        warning_clusters.append(cluster)
                    elif current_percent > warning_threshold * 0.8:
                        status = "⚠️接近"
                        warning_clusters.append(cluster)
                    elif monthly_growth_trend > current_size * 0.05:  # 月增长超过5%
                        status = "📈快增"
                        rapid_growth_clusters.append(cluster)
                    
                    current_size_bytes = current_size * 1024 * 1024 * 1024
                    predict_3_bytes = predict_3_months * 1024 * 1024 * 1024
                    predict_6_bytes = predict_6_months * 1024 * 1024 * 1024
                    
                    report_lines.append(
                        f"{cluster:<15} {self.format_size(current_size_bytes):<12} "
                        f"{self.format_size(predict_3_bytes):<12} {self.format_size(predict_6_bytes):<12} {status:<12}"
                    )
        
        report_lines.append("")
        
        # 添加预测摘要
        report_lines.append("容量预测摘要:")
        if warning_clusters:
            report_lines.append(f"  ⚠️  需要关注的集群: {', '.join(warning_clusters)}")
        if rapid_growth_clusters:
            report_lines.append(f"  📈 快速增长集群: {', '.join(rapid_growth_clusters)}")
        if not warning_clusters and not rapid_growth_clusters:
            report_lines.append("  ✅ 所有集群容量增长正常")
        
        report_lines.append("")


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='GFS 容量分析器')
    parser.add_argument('gfs_path', help='GFS 挂载点路径')
    parser.add_argument('--output', '-o', default='./output', 
                       help='输出目录 (默认: ./output)')
    parser.add_argument('--debug', action='store_true', 
                       help='启用调试模式')
    parser.add_argument('--no-excel', action='store_true',
                       help='不导出 Excel 文件')
    parser.add_argument('--incremental-only', action='store_true',
                       help='只运行增量分析和容量预测（类似原 shell 脚本功能）')
    
    args = parser.parse_args()
    
    # 检查 GFS 路径
    if not os.path.exists(args.gfs_path):
        print(f"错误: GFS 路径不存在: {args.gfs_path}")
        sys.exit(1)
    
    # 创建分析器
    analyzer = GFSCapacityAnalyzer(
        gfs_path=args.gfs_path,
        output_dir=args.output,
        debug=args.debug
    )
    
    # 执行分析
    try:
        if args.incremental_only:
            # 只运行增量分析
            print("运行增量分析和容量预测模式...")
            incremental_file = analyzer.generate_incremental_report()
            print(f"\n增量分析完成！输出文件: {incremental_file}")
        else:
            # 运行完整分析
            results = analyzer.analyze(export_excel=not args.no_excel)
            
            print("\n分析完成！输出文件:")
            for key, filepath in results.items():
                print(f"  {key}: {filepath}")
            
    except KeyboardInterrupt:
        print("\n用户中断操作")
        sys.exit(1)
    except Exception as e:
        print(f"分析过程中发生错误: {e}")
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main() 