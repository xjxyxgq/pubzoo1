#!/bin/bash

# Extract data from text file and format as required
# Usage: ./extract_data.sh input.txt

input_file="$1"

if [ -z "$input_file" ]; then
    echo "Usage: $0 <input_file>"
    exit 1
fi

# Process the file
while IFS= read -r line; do
    # When we find a cluster line
    if [[ $line =~ 【操作[0-9]*】集群：[[:blank:]]*(.+) ]]; then
        cluster="${BASH_REMATCH[1]}"
        # Remove region prefix (Z1_, Z2_, etc.)
        dbname=$(echo "$cluster" | sed 's/^[A-Z]*[0-9]*_//')
    # When we find an IP line
    elif [[ $line =~ [0-9]+\.[[:blank:]]*业务IP：[[:blank:]]*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+) ]]; then
        ip="${BASH_REMATCH[1]}"
    # When we find a result line
    elif [[ $line =~ .*\[\'([^\']+)\',.*\'([0-9]{8}),.* ]]; then
        table_name="${BASH_REMATCH[1]}"
        timestamp="${BASH_REMATCH[2]}"
        echo "$ip:3306,$dbname,$table_name,$timestamp,0"
    fi
done < "$input_file"

